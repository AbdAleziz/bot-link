import asyncio
import logging
import shutil
import tarfile
import tempfile
from datetime import datetime, timedelta
from pathlib import Path

from config import Config

logger = logging.getLogger("backup")


class BackupManager:
    def __init__(self):
        self.backup_dir = Path(Config.BACKUP_DIR)
        self.keep_last = Config.BACKUP_KEEP_LAST
        self.auto_hour = Config.BACKUP_AUTO_HOUR
        self.auto_send_to = Config.BACKUP_AUTO_SEND_TO
        self.restart_cmd = Config.BACKUP_RESTART_CMD
        self._scheduler_task = None

    def init(self) -> None:
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"Backup directory ready: {self.backup_dir.resolve()}")

    async def create_backup(self, label: str = "manual") -> Path:
        ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        filename = f"backup_{ts}_{label}.tar.gz"
        path = self.backup_dir / filename

        try:
            with tarfile.open(str(path), "w:gz") as tar:
                for src in self._sources():
                    src_path = Path(src)
                    if src_path.exists():
                        tar.add(str(src_path), arcname=src_path.name)
                        logger.debug(f"Added to backup: {src}")
                    else:
                        logger.debug(f"Skipped (not found): {src}")

            logger.info(f"Backup created: {path} ({path.stat().st_size} bytes)")
            await self._cleanup_old()
            return path
        except Exception:
            logger.error(f"Backup failed for label={label}", exc_info=True)
            if path.exists():
                path.unlink()
            raise

    async def restore_backup(self, archive_path: Path, app) -> bool:
        if not archive_path.exists():
            logger.error(f"Restore archive not found: {archive_path}")
            return False
        if not str(archive_path).endswith(".tar.gz"):
            logger.error(f"Invalid archive format: {archive_path}")
            return False
        resolved = archive_path.resolve()
        backup_dir_resolved = self.backup_dir.resolve()
        if not str(resolved).startswith(str(backup_dir_resolved)):
            logger.error(f"Path traversal blocked: {archive_path}")
            return False

        rollback_path = self.backup_dir / f"_pre_restore_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.tar.gz"
        logger.info(f"Creating rollback backup: {rollback_path}")
        try:
            with tarfile.open(str(rollback_path), "w:gz") as tar:
                for src in self._sources():
                    src_path = Path(src)
                    if src_path.exists():
                        tar.add(str(src_path), arcname=src_path.name)
            logger.info(f"Rollback backup created: {rollback_path}")
        except Exception as e:
            logger.error(f"Failed to create rollback backup: {e}")
            return False

        staging_dir = Path(tempfile.mkdtemp(prefix="restore_staging_"))
        try:
            logger.info(f"Extracting {archive_path} to staging: {staging_dir}")
            with tarfile.open(str(archive_path), "r:gz") as tar:
                for member in tar.getmembers():
                    if member.name.startswith("/"):
                        member.name = member.name.lstrip("/")
                    tar.extract(member, path=str(staging_dir))

            for item in staging_dir.iterdir():
                dest = Path.cwd() / item.name
                if item.is_dir():
                    if dest.exists():
                        shutil.rmtree(dest)
                    shutil.copytree(item, dest)
                else:
                    if dest.exists():
                        dest.unlink()
                    shutil.copy2(item, dest)
                logger.info(f"Restored: {dest}")

            logger.info(f"Restore completed from {archive_path.name}")
            return True
        except Exception as e:
            logger.error(f"Restore failed: {e}", exc_info=True)
            return False
        finally:
            shutil.rmtree(staging_dir, ignore_errors=True)

    def list_backups(self) -> list[dict]:
        if not self.backup_dir.exists():
            return []
        items = []
        for f in sorted(self.backup_dir.glob("backup_*.tar.gz"), key=lambda p: p.stat().st_mtime, reverse=True):
            mtime = datetime.utcfromtimestamp(f.stat().st_mtime).isoformat()
            name_no_ext = f.name.replace(".tar.gz", "")
            parts = name_no_ext.split("_", 3)
            label = parts[3] if len(parts) >= 4 else "unknown"
            items.append({
                "id": name_no_ext,
                "filename": f.name,
                "size_bytes": f.stat().st_size,
                "mtime_iso": mtime,
                "label": label,
            })
        return items

    def delete_backup(self, archive_name: str) -> bool:
        resolved = (self.backup_dir / archive_name).resolve()
        backup_dir_resolved = self.backup_dir.resolve()
        if not str(resolved).startswith(str(backup_dir_resolved)):
            logger.error(f"Path traversal blocked on delete: {archive_name}")
            return False
        if not resolved.exists():
            logger.warning(f"Backup not found for delete: {resolved}")
            return False
        resolved.unlink()
        logger.info(f"Deleted backup: {resolved}")
        return True

    async def start_scheduler(self, app) -> None:
        if self._scheduler_task is not None:
            logger.warning("Scheduler already running")
            return
        self._scheduler_task = asyncio.create_task(self._scheduler_loop(app))
        logger.info("Backup scheduler started")

    async def stop_scheduler(self) -> None:
        if self._scheduler_task:
            self._scheduler_task.cancel()
            try:
                await self._scheduler_task
            except asyncio.CancelledError:
                pass
            self._scheduler_task = None
            logger.info("Backup scheduler stopped")

    async def _scheduler_loop(self, app) -> None:
        while True:
            next_run = self._next_run_time()
            wait_seconds = (next_run - datetime.utcnow()).total_seconds()
            await asyncio.sleep(max(0, wait_seconds))
            try:
                path = await self.create_backup(label="auto")
                await self._deliver_to_admin(app, path, kind="auto")
            except Exception as e:
                logger.error(f"Auto backup failed: {e}")

    async def _deliver_to_admin(self, app, path: Path, kind: str) -> None:
        if self.auto_send_to == 0:
            return
        try:
            caption = (
                f"📦 <b>Backup ({kind})</b>\n"
                f"━━━━━━━━━━━━━━\n"
                f"📄 {path.name}\n"
                f"📏 {path.stat().st_size / 1024:.1f} KB\n"
                f"🕐 {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC"
            )
            await app.send_document(
                chat_id=self.auto_send_to,
                document=str(path),
                caption=caption,
            )
            logger.info(f"Backup delivered to {self.auto_send_to}: {path.name}")
        except Exception as e:
            logger.error(f"Backup delivery failed to {self.auto_send_to}: {e}")

    def _next_run_time(self) -> datetime:
        now = datetime.utcnow()
        candidate = now.replace(hour=self.auto_hour, minute=0, second=0, microsecond=0)
        if candidate <= now:
            candidate += timedelta(days=1)
        return candidate

    async def _cleanup_old(self) -> None:
        backups = sorted(
            self.backup_dir.glob("backup_*.tar.gz"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        for old in backups[self.keep_last:]:
            old.unlink()
            logger.info(f"Cleaned up old backup: {old.name}")

    def _sources(self) -> list[str]:
        return [
            "data/bot.db",
            "data/bot.db-shm",
            "data/bot.db-wal",
            "data/bot.session",
            "data/bot.session-journal",
            ".env",
            "static/qr_logo.png",
            "data/bot.log",
        ]
