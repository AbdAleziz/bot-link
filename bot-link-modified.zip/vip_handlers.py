import logging
from datetime import datetime

from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from config import Config
from database import Database
from vip_system import VipSystem

logger = logging.getLogger("vip_handlers")


class VipHandler:
    def __init__(self, db: Database):
        self.db = db
        self.vip = VipSystem(db)

    def register(self, app: Client):
        @app.on_message(filters.command("vip") & filters.private)
        async def vip_cmd(client: Client, message: Message):
            user_id = message.from_user.id
            info = await self.vip.get_vip_info(user_id)

            if info and info.get("is_active"):
                text = (
                    f"⭐ <b>اشتراكك VIP</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"📋 الخطة: {info['plan']}\n"
                    f"📅 يبقى: {info['remaining_days']} يوم\n"
                    f"🔚 ينتهي: {info['expires_at'][:10]}\n\n"
                    f"✨ <b>مميزات VIP:</b>\n"
                    f"• فحص متقدم بالذكاء الاصطناعي\n"
                    f"• فحص الصور والفيديو\n"
                    f"• فحص جماعي\n"
                    f"• مراقبة النطاقات\n"
                    f"• API شخصي\n"
                    f"• أولوية في الفحص"
                )
                await message.reply(text)
            else:
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("⭐ لمدة أسبوع", callback_data="buy_week"),
                     InlineKeyboardButton("⭐ لمدة شهر", callback_data="buy_month")],
                    [InlineKeyboardButton("🌟 مدى الحياة", callback_data="buy_lifetime")],
                ])
                await message.reply(
                    "⭐ <b>الاشتراك في VIP</b>\n\n"
                    "مميزات VIP:\n"
                    "• فحص متقدم بالذكاء الاصطناعي\n"
                    "• فحص الصور والفيديو\n"
                    "• فحص جماعي للروابط\n"
                    "• مراقبة النطاقات\n"
                    "• مفتاح API شخصي\n"
                    "• أولوية في الفحص\n\n"
                    f"💎 الأسبوع: {Config.STAR_PRICE_WEEK} {Config.CURRENCY}\n"
                    f"💎 الشهر: {Config.STAR_PRICE_MONTH} {Config.CURRENCY}\n"
                    f"💎 مدى الحياة: {Config.STAR_PRICE_LIFETIME} {Config.CURRENCY}",
                    reply_markup=keyboard
                )

        @app.on_callback_query(filters.regex(r"^buy_"))
        async def buy_callback(client: Client, callback: CallbackQuery):
            duration = callback.data.replace("buy_", "")
            user_id = callback.from_user.id

            amount = await self.vip.get_price(duration)

            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton(f"💳 دفع {amount} {Config.CURRENCY}",
                                      callback_data=f"pay_{duration}")],
                [InlineKeyboardButton("🔙 رجوع", callback_data="vip_back")]
            ])

            texts = {"week": "أسبوع", "month": "شهر", "lifetime": "مدى الحياة"}
            await callback.message.edit(
                f"⭐ <b>اشتراك {texts.get(duration, duration)}</b>\n\n"
                f"السعر: {amount} {Config.CURRENCY}\n"
                f"اضغط للدفع باستخدام Telegram Stars",
                reply_markup=keyboard
            )
            await callback.answer()

        @app.on_callback_query(filters.regex(r"^pay_"))
        async def pay_callback(client: Client, callback: CallbackQuery):
            duration = callback.data.replace("pay_", "")
            user_id = callback.from_user.id

            # Check if Telegram native payments work
            try:
                amount = await self.vip.get_price(duration)

                # For now, grant directly (in production, use actual payment)
                await self.vip.grant_vip(user_id, duration)
                await callback.message.edit(
                    f"✅ <b>تم التفعيل!</b>\n"
                    f"تم تفعيل اشتراك VIP بنجاح\n"
                    f"استخدم /vip لعرض التفاصيل"
                )
            except Exception as e:
                logger.error(f"Payment error: {e}")
                await callback.message.edit("❌ حدث خطأ في عملية الدفع")

            await callback.answer()

        @app.on_callback_query(filters.regex(r"^vip_back"))
        async def vip_back(client: Client, callback: CallbackQuery):
            user_id = callback.from_user.id
            # Create a fake message with the correct user ID
            msg = callback.message
            msg.from_user.id = user_id
            await vip_cmd(client, msg)
            await callback.answer()

        @app.on_pre_checkout_query()
        async def pre_checkout(client: Client, query):
            await query.answer(ok=True)

        @app.on_message(filters.successful_payment)
        async def successful_payment(client: Client, message: Message):
            user_id = message.from_user.id
            payload = message.successful_payment.invoice_payload
            await self.vip.confirm_payment(payload)
            await message.reply(
                "✅ <b>تم الدفع بنجاح!</b>\n"
                "تم تفعيل اشتراك VIP\n"
                "استخدم /vip لعرض التفاصيل"
            )

        @app.on_message(filters.command("bulkscan") & filters.private)
        async def bulk_scan(client: Client, message: Message):
            user_id = message.from_user.id
            if not await self.vip.is_vip(user_id):
                await message.reply("❌ هذه الميزة لـ VIP فقط\nاستخدم /vip للاشتراك")
                return

            text = message.text.split(maxsplit=1)
            if len(text) < 2:
                await message.reply("❌ أرسل الروابط مفصولة بفواصل\nمثال: /bulkscan https://link1.com,https://link2.com")
                return

            urls = [u.strip() for u in text[1].split(",")]
            if len(urls) > 20:
                await message.reply("❌ الحد الأقصى 20 رابط في الفحص الجماعي")
                return

            sent = await message.reply(f"🔍 جاري فحص {len(urls)} رابط...")
            from scanner import Scanner
            scanner = Scanner(self.db)
            results = []

            for url in urls:
                try:
                    r = await scanner.scan_url(url, user_id, priority=True)
                    status = "✅ آمن" if not r.get("is_threat") else "🚫 تهديد"
                    results.append(f"{status}: {url[:50]}")
                except Exception as e:
                    results.append(f"❌ خطأ: {url[:50]}")

            report = "\n".join(results)
            await sent.edit(
                f"📋 <b>نتائج الفحص الجماعي</b>\n"
                f"━━━━━━━━━━━━━━\n"
                f"{report}"
            )

        @app.on_message(filters.command("domainwatch") & filters.private)
        async def domain_watch(client: Client, message: Message):
            user_id = message.from_user.id
            if not await self.vip.is_vip(user_id):
                await message.reply("❌ هذه الميزة لـ VIP فقط")
                return

            text = message.text.split(maxsplit=1)
            if len(text) < 2:
                # Show watched domains
                rows = await self.db.fetch(
                    "SELECT * FROM domain_watch WHERE user_id = ?", (user_id,))
                if not rows:
                    await message.reply("❌ أرسل النطاق للمراقبة\nمثال: /domainwatch example.com")
                    return
                domains = "\n".join(f"• {r['domain']}" for r in rows)
                await message.reply(f"📋 <b>النطاقات المراقبة:</b>\n{domains}")
                return

            domain = text[1].strip().lower()
            await self.db.execute(
                "INSERT OR IGNORE INTO domain_watch (domain, user_id, added_at) VALUES (?, ?, ?)",
                (domain, user_id, datetime.utcnow().isoformat()))
            await message.reply(f"✅ تمت إضافة {domain} للمراقبة")

        @app.on_message(filters.command("whitelist") & filters.private)
        async def whitelist_domain(client: Client, message: Message):
            user_id = message.from_user.id
            if not await self.vip.is_vip(user_id):
                await message.reply("❌ هذه الميزة لـ VIP فقط")
                return

            text = message.text.split(maxsplit=1)
            if len(text) < 2:
                await message.reply("❌ أرسل النطاق للإضافة\nمثال: /whitelist example.com")
                return

            domain = text[1].strip().lower()
            await self.db.execute(
                "INSERT OR IGNORE INTO whitelist (pattern, added_by, added_at) VALUES (?, ?, ?)",
                (domain, user_id, datetime.utcnow().isoformat()))
            await message.reply(f"✅ تمت إضافة {domain} إلى القائمة البيضاء")
