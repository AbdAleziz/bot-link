import asyncio
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path

import aiohttp.web as web
import aiohttp_jinja2
import jinja2
import humanize

from config import Config
from database import Database

logger = logging.getLogger("web_dashboard")


class WebDashboard:
    def __init__(self, db: Database, bot=None):
        self.db = db
        self.bot = bot
        self.app = web.Application()
        self.runner = None
        self._ws_clients = set()
        self._setup_routes()

    def _setup_routes(self):
        self.app.router.add_get("/", self._handle_index)
        self.app.router.add_get("/health", self._handle_health)
        self.app.router.add_get("/api/stats", self._handle_api_stats)
        self.app.router.add_get("/api/threats", self._handle_api_threats)
        self.app.router.add_post("/api/scan", self._handle_api_scan)
        self.app.router.add_post("/api/upload", self._handle_api_upload)
        self.app.router.add_get("/api/activity", self._handle_api_activity)
        self.app.router.add_get("/ws", self._handle_websocket)
        self.app.router.add_static("/static", Path(__file__).parent / "static")
        aiohttp_jinja2.setup(
            self.app,
            loader=jinja2.FileSystemLoader(Path(__file__).parent / "templates"),
            autoescape=True,
        )

        self.app.on_shutdown.append(self._on_shutdown)

    async def _auth_check(self, request: web.Request) -> bool:
        auth = request.headers.get("Authorization", "")
        import base64
        if auth.startswith("Basic "):
            decoded = base64.b64decode(auth[7:]).decode()
            user, _, passwd = decoded.partition(":")
            return user == Config.DASHBOARD_USER and passwd == Config.DASHBOARD_PASS
        return False

    async def _handle_index(self, request: web.Request):
        if not await self._auth_check(request):
            resp = web.Response(status=401, text="Unauthorized")
            resp.headers["WWW-Authenticate"] = 'Basic realm="Dashboard"'
            return resp

        stats = await self._get_stats()
        stats["dashboard_user"] = Config.DASHBOARD_USER
        # NOTE: never expose the real password in the rendered HTML/JS.
        # The browser handles Basic auth via `credentials: 'include'`
        # and the 401 + WWW-Authenticate challenge.
        try:
            return aiohttp_jinja2.render_template(
                "dashboard.html", request,
                {"stats": stats, "now": datetime.now().isoformat()}
            )
        except Exception:
            return web.json_response({"status": "ok", "stats": stats})

    async def _handle_health(self, request: web.Request):
        status = "healthy"
        db_ok = False
        try:
            await self.db.fetchval("SELECT 1")
            db_ok = True
        except Exception:
            status = "degraded"

        return web.json_response({
            "status": status,
            "timestamp": datetime.utcnow().isoformat(),
            "database": "connected" if db_ok else "disconnected",
            "uptime": humanize.naturaldelta(self._uptime()) if hasattr(self, '_start_time') else "unknown",
            "version": "2.0.0",
        })

    async def _handle_api_stats(self, request: web.Request):
        if not await self._auth_check(request):
            return web.json_response({"error": "unauthorized"}, status=401)
        stats = await self._get_stats()
        return web.json_response(stats)

    async def _handle_api_threats(self, request: web.Request):
        key = request.query.get("key", "")
        if Config.THREAT_API_KEY and key != Config.THREAT_API_KEY:
            return web.json_response({"error": "invalid key"}, status=403)

        url = request.query.get("url", "")
        domain = request.query.get("domain", "")

        if url:
            result = await self.db.fetchrow(
                "SELECT * FROM scan_history WHERE url = ? ORDER BY scanned_at DESC LIMIT 1",
                (url,)
            )
        elif domain:
            result = await self.db.fetchrow(
                "SELECT * FROM scan_history WHERE domain = ? ORDER BY scanned_at DESC LIMIT 1",
                (domain,)
            )
        else:
            results = await self.db.fetch(
                "SELECT * FROM scan_history ORDER BY scanned_at DESC LIMIT 50"
            )
            return web.json_response({"results": [dict(r) for r in results]})

        if result:
            return web.json_response(dict(result))
        return web.json_response({"error": "not found"}, status=404)

    async def _handle_api_scan(self, request: web.Request):
        if not await self._auth_check(request):
            return web.json_response({"error": "unauthorized"}, status=401)

        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "invalid json"}, status=400)

        url = data.get("url", "")
        if not url:
            return web.json_response({"error": "url required"}, status=400)

        # Queue scan via bot
        if self.bot:
            try:
                from scanner import Scanner
                scanner = Scanner(self.db)
                result = await scanner.scan_url(url, priority=True)
                return web.json_response({"result": result})
            except Exception as e:
                logger.error(f"Scan error: {e}")
                return web.json_response({"error": str(e)}, status=500)

        return web.json_response({"error": "scanner not available"}, status=503)

    async def _handle_api_upload(self, request: web.Request):
        if not await self._auth_check(request):
            return web.json_response({"error": "unauthorized"}, status=401)

        reader = await request.multipart()
        field = await reader.next()

        if not field or field.name != "file":
            return web.json_response({"error": "file field required"}, status=400)

        filename = field.filename
        if not filename:
            return web.json_response({"error": "no filename"}, status=400)

        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if ext not in Config.ALLOWED_EXTENSIONS:
            return web.json_response({"error": f"invalid extension {ext}, allowed: {Config.ALLOWED_EXTENSIONS}"},
                                     status=400)

        content = await field.read()
        urls = content.decode().strip().splitlines()
        urls = [u.strip() for u in urls if u.strip()]

        if len(urls) > Config.MAX_BATCH_SIZE:
            urls = urls[:Config.MAX_BATCH_SIZE]

        results = []
        if self.bot:
            from scanner import Scanner
            scanner = Scanner(self.db)
            for u in urls:
                try:
                    r = await scanner.scan_url(u, priority=False)
                    results.append({"url": u, "status": "scanned", "result": r})
                except Exception as e:
                    results.append({"url": u, "status": "error", "error": str(e)})
        else:
            results = [{"url": u, "status": "queued"} for u in urls]

        return web.json_response({
            "total": len(urls),
            "results": results,
            "scanned": len(results),
        })

    async def _handle_api_activity(self, request: web.Request):
        if not await self._auth_check(request):
            return web.json_response({"error": "unauthorized"}, status=401)

        hours = int(request.query.get("hours", "24"))
        since = datetime.utcnow() - timedelta(hours=hours)

        try:
            scans = await self.db.fetch(
                "SELECT COUNT(*) as count, strftime('%Y-%m-%d %H:00', scanned_at) as hour "
                "FROM scan_history WHERE scanned_at >= ? GROUP BY hour ORDER BY hour",
                (since.isoformat(),)
            )
            total_scans = sum(r["count"] for r in scans) if scans else 0

            threat_types = await self.db.fetch(
                "SELECT threat_type, COUNT(*) as count FROM scan_history "
                "WHERE scanned_at >= ? AND threat_type IS NOT NULL GROUP BY threat_type",
                (since.isoformat(),)
            )
        except Exception:
            scans = []
            total_scans = 0
            threat_types = []

        return web.json_response({
            "period_hours": hours,
            "total_scans": total_scans,
            "scans_per_hour": [dict(r) for r in scans] if scans else [],
            "threat_types": [dict(r) for r in threat_types] if threat_types else [],
        })

    async def _handle_websocket(self, request: web.Request):
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        self._ws_clients.add(ws)
        logger.info("WebSocket client connected")

        try:
            async for msg in ws:
                if msg.type == aiohttp.WSMsgType.ERROR:
                    logger.error(f"WebSocket error: {ws.exception()}")
        except asyncio.CancelledError:
            pass
        finally:
            self._ws_clients.discard(ws)
            logger.info("WebSocket client disconnected")

        return ws

    async def broadcast(self, event: str, data: dict):
        msg = json.dumps({"event": event, "data": data})
        dead = set()
        for ws in self._ws_clients:
            try:
                await ws.send_str(msg)
            except Exception:
                dead.add(ws)
        self._ws_clients -= dead

    async def _get_stats(self) -> dict:
        stats = {"users": 0, "vips": 0, "scans_today": 0, "threats_blocked": 0, "total_scans": 0}
        try:
            today = datetime.utcnow().date().isoformat()

            row = await self.db.fetchrow("SELECT COUNT(*) as c FROM users")
            if row:
                stats["users"] = row["c"]

            row = await self.db.fetchrow("SELECT COUNT(*) as c FROM vip_users WHERE expires_at > datetime('now')")
            if row:
                stats["vips"] = row["c"]

            row = await self.db.fetchrow(
                "SELECT COUNT(*) as c FROM scan_history WHERE date(scanned_at) = ?", (today,)
            )
            if row:
                stats["scans_today"] = row["c"]

            row = await self.db.fetchrow("SELECT COUNT(*) as c FROM scan_history WHERE is_threat = 1")
            if row:
                stats["threats_blocked"] = row["c"]

            row = await self.db.fetchrow("SELECT COUNT(*) as c FROM scan_history")
            if row:
                stats["total_scans"] = row["c"]
        except Exception as e:
            logger.error(f"Stats error: {e}")

        stats["uptime"] = humanize.naturaldelta(self._uptime()) if hasattr(self, '_start_time') else "unknown"
        return stats

    def _uptime(self):
        return datetime.utcnow() - self._start_time if hasattr(self, '_start_time') else timedelta(0)

    async def _on_shutdown(self, app):
        for ws in self._ws_clients:
            await ws.close()

    async def start(self):
        self._start_time = datetime.utcnow()
        self.runner = web.AppRunner(self.app)
        await self.runner.setup()
        site = web.TCPSite(self.runner, Config.WEB_HOST, Config.WEB_PORT)
        await site.start()
        logger.info(f"Web dashboard running on http://{Config.WEB_HOST}:{Config.WEB_PORT}")

    async def stop(self):
        if self.runner:
            await self.runner.cleanup()
            logger.info("Web dashboard stopped")
