import logging
import secrets
from datetime import datetime, timedelta

from config import Config
from database import Database

logger = logging.getLogger("vip_system")


class VipSystem:
    def __init__(self, db: Database):
        self.db = db

    async def is_vip(self, user_id: int) -> bool:
        row = await self.db.fetchrow(
            "SELECT expires_at FROM vip_users WHERE user_id = ?", (user_id,))
        if not row:
            return False
        try:
            expires = datetime.fromisoformat(row["expires_at"])
            return expires > datetime.utcnow()
        except Exception:
            return False

    async def grant_vip(self, user_id: int, duration: str, months: int = 1) -> dict:
        if duration == "week":
            delta = timedelta(days=7)
            plan = "week"
        elif duration == "month":
            delta = timedelta(days=Config.VIP_DURATION_DAYS * months)
            plan = f"month_{months}"
        elif duration == "lifetime":
            delta = timedelta(days=365 * 100)
            plan = "lifetime"
        else:
            return {"error": f"invalid duration: {duration}"}

        expires_at = (datetime.utcnow() + delta).isoformat()

        # If user already has VIP, extend it instead of replacing
        existing = await self.db.fetchrow(
            "SELECT expires_at FROM vip_users WHERE user_id = ?", (user_id,))
        if existing:
            try:
                current_expires = datetime.fromisoformat(existing["expires_at"])
                if current_expires > datetime.utcnow():
                    expires_at = (current_expires + delta).isoformat()
            except Exception:
                pass

        await self.db.execute(
            "INSERT OR REPLACE INTO vip_users (user_id, expires_at, plan) VALUES (?, ?, ?)",
            (user_id, expires_at, plan))

        logger.info(f"VIP granted to {user_id} for {duration} (months={months}), expires {expires_at}")
        return {"status": "ok", "user_id": user_id, "plan": plan, "expires_at": expires_at}

    async def revoke_vip(self, user_id: int):
        await self.db.execute("DELETE FROM vip_users WHERE user_id = ?", (user_id,))
        logger.info(f"VIP revoked from {user_id}")

    async def get_vip_info(self, user_id: int) -> dict | None:
        row = await self.db.fetchrow(
            "SELECT * FROM vip_users WHERE user_id = ?", (user_id,))
        if not row:
            return None
        result = dict(row)
        try:
            expires = datetime.fromisoformat(result["expires_at"])
            result["is_active"] = expires > datetime.utcnow()
            result["remaining_days"] = (expires - datetime.utcnow()).days if result["is_active"] else 0
        except Exception:
            result["is_active"] = False
            result["remaining_days"] = 0
        return result

    async def get_price(self, duration: str) -> int:
        prices = {
            "week": Config.STAR_PRICE_WEEK,
            "month": Config.STAR_PRICE_MONTH,
            "lifetime": Config.STAR_PRICE_LIFETIME,
        }
        return prices.get(duration, Config.STAR_PRICE_WEEK)

    async def create_payment(self, user_id: int, duration: str) -> dict:
        plan = duration
        amount = await self.get_price(duration)
        invoice_id = f"inv_{secrets.token_hex(8)}"
        await self.db.execute(
            "INSERT INTO pending_payments (user_id, plan, amount, currency, invoice_id, status, created_at) "
            "VALUES (?, ?, ?, ?, ?, 'pending', ?)",
            (user_id, plan, amount, Config.CURRENCY, invoice_id, datetime.utcnow().isoformat()))
        return {
            "invoice_id": invoice_id,
            "amount": amount,
            "currency": Config.CURRENCY,
            "plan": plan,
        }

    async def confirm_payment(self, invoice_id: str) -> bool:
        payment = await self.db.fetchrow(
            "SELECT * FROM pending_payments WHERE invoice_id = ?", (invoice_id,))
        if not payment:
            return False
        await self.db.execute(
            "UPDATE pending_payments SET status = 'completed' WHERE invoice_id = ?",
            (invoice_id,))
        await self.grant_vip(payment["user_id"], payment["plan"])
        return True
