# scanner_bot — Telegram link scanner

A Telegram bot that scans URLs for threats (VirusTotal, urlscan, WHOIS, SSL,
local blacklist/whitelist), ships with a web dashboard for admins, and
supports VIP subscriptions via Telegram Stars.

## Local development

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
# Edit .env and replace the placeholders with your real values
python fix.py              # creates data/ + uploads/, sanity-checks env
python main.py
```

The bot starts in **polling** mode by default. The web dashboard is
exposed on `http://localhost:8080/` (Basic auth: whatever you put in
`DASHBOARD_USER` / `DASHBOARD_PASS`).

## Deploying to justrunmy.app

The platform reads runtime / port / env from its **web UI**, not from
`justrunmy.yml`. The yml file is shipped as a deployment contract — copy
the values from it into the platform form.

### 1. Build the zip

From the project root:

```bash
zip -r scanner_bot.zip . -x '.venv/*' '__pycache__/*' '*.pyc' 'data/*' '.env'
```

The platform already has Python 3.11, so you don't need to bundle a venv.

### 2. Upload & configure

In the justrunmy.app dashboard:

- **Run Command**: `python main.py`
- **Port**: `8080`  (the web dashboard + health check)
- **OS**: Linux
- **Environment variables**: at minimum, set
  - `BOT_TOKEN`
  - `API_ID`
  - `API_HASH`
  - `SUDO_USERS` (comma-separated Telegram user ids)
  - `DASHBOARD_PASS` (change the default!)
- **Persistent volume**: mount `/app/data` (≥ 256 MB) so the SQLite
  database and `bot.session` survive restarts.

### 3. Verify

- The platform polls `GET /health` every 30s. You should see
  `{"status":"healthy","database":"connected",...}` once the bot is up.
- Open `https://<your-app>.justrunmy.app/` — the browser will prompt for
  Basic auth (`DASHBOARD_USER` / `DASHBOARD_PASS`).

## Project layout

```
scanner_bot/
├── main.py              # entrypoint: wires everything together
├── config.py            # all env-var driven settings
├── database.py          # SQLite (default) + optional Postgres / Redis
├── scanner.py           # URL scanner (VT, urlscan, WHOIS, SSL, redirects)
├── admin.py             # /ban, /broadcast, /stats, /export, ...
├── vip_handlers.py      # /vip, /bulkscan, /domainwatch, /whitelist
├── vip_system.py        # VIP grants via Telegram Stars
├── flood_captcha.py     # group anti-flood + captcha
├── click_tracker.py     # short-link tracking
├── web_dashboard.py     # aiohttp web UI + REST API
├── mcp_server.py        # JSON-RPC MCP server (off by default)
├── fix.py               # startup sanity checks
├── templates/
│   └── dashboard.html   # admin web UI
├── static/              # static assets (empty, ready for use)
├── uploads/             # runtime: bulk-scan files
├── data/                # runtime: bot.db, bot.session, bot.log
├── requirements.txt
├── justrunmy.yml        # deployment manifest (reference only)
├── Dockerfile           # alternative: Docker Image deploy
└── .env                 # placeholders only — fill in for local dev
```

## Security notes

- The shipped `.env` contains **placeholders** only. Real secrets are set
  via the platform's environment variables panel.
- The dashboard's Basic auth credentials are **never** embedded in the
  HTML/JS — the browser handles the auth challenge via 401 +
  `WWW-Authenticate`, so the password never leaks into the page source.
- `WEBHOOK_MODE` should stay `false` on justrunmy.app — the platform
  restarts on outbound polling, webhooks add no value here.
