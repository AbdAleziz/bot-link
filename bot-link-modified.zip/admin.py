import asyncio
import io
import logging
import os
from datetime import datetime

from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from config import Config
from database import Database

logger = logging.getLogger("admin")


class AdminHandler:
    def __init__(self, db: Database):
        self.db = db

    def register(self, app: Client):
        @app.on_message(filters.command("addadmin") & filters.user(Config.SUDO_USERS))
        async def add_admin(client: Client, message: Message):
            if not message.reply_to_message:
                await message.reply("❌ يرجى الرد على رسالة المستخدم")
                return
            uid = message.reply_to_message.from_user.id
            await message.reply(f"✅ تمت إضافة {uid} كمسؤول\nملاحظة: صلاحية المسؤول تتحكم بها فقط متغير SUDO_USERS في البيئة")

        @app.on_message(filters.command("deladmin") & filters.user(Config.SUDO_USERS))
        async def del_admin(client: Client, message: Message):
            if not message.reply_to_message:
                await message.reply("❌ يرجى الرد على رسالة المستخدم")
                return
            uid = message.reply_to_message.from_user.id
            await message.reply(f"✅ تمت إزالة {uid} من المسؤولين")

        @app.on_message(filters.command("ban") & filters.user(Config.SUDO_USERS))
        async def ban_user(client: Client, message: Message):
            if not message.reply_to_message:
                await message.reply("❌ يرجى الرد على رسالة المستخدم")
                return
            uid = message.reply_to_message.from_user.id
            reason = message.text.split(maxsplit=1)[1] if len(message.text.split()) > 1 else "بدون سبب"
            await self.db.execute(
                "INSERT OR REPLACE INTO banned_users (user_id, reason, banned_at) VALUES (?, ?, ?)",
                (uid, reason, datetime.utcnow().isoformat()))
            await message.reply(f"✅ تم حظر المستخدم {uid}\nالسبب: {reason}")

        @app.on_message(filters.command("unban") & filters.user(Config.SUDO_USERS))
        async def unban_user(client: Client, message: Message):
            if not message.reply_to_message:
                await message.reply("❌ يرجى الرد على رسالة المستخدم")
                return
            uid = message.reply_to_message.from_user.id
            await self.db.execute("DELETE FROM banned_users WHERE user_id = ?", (uid,))
            await message.reply(f"✅ تم إلغاء حظر المستخدم {uid}")

        @app.on_message(filters.command("broadcast") & filters.user(Config.SUDO_USERS))
        async def broadcast(client: Client, message: Message):
            if not message.reply_to_message:
                await message.reply("❌ يرجى الرد على رسالة للإذاعة")
                return
            msg = message.reply_to_message.text or message.reply_to_message.caption or ""
            if not msg:
                await message.reply("❌ الرسالة فارغة")
                return
            sent_msg = await message.reply("📢 جاري الإذاعة...")
            users = await self.db.fetch("SELECT user_id FROM users")
            sent = 0
            failed = 0
            for u in users:
                try:
                    await client.send_message(u["user_id"], msg)
                    sent += 1
                    await asyncio.sleep(0.05)
                except Exception:
                    failed += 1
            await sent_msg.edit(f"✅ تم الإرسال لـ {sent} مستخدم\n❌ فشل: {failed}")

        @app.on_message(filters.command("stats") & filters.user(Config.SUDO_USERS))
        async def stats_cmd(client: Client, message: Message):
            users = await self.db.fetchval("SELECT COUNT(*) FROM users") or 0
            vips = await self.db.fetchval(
                "SELECT COUNT(*) FROM vip_users WHERE expires_at > datetime('now')") or 0
            scans_today = await self.db.fetchval(
                "SELECT COUNT(*) FROM scan_history WHERE date(scanned_at) = date('now')") or 0
            total_scans = await self.db.fetchval("SELECT COUNT(*) FROM scan_history") or 0
            threats = await self.db.fetchval("SELECT COUNT(*) FROM scan_history WHERE is_threat = 1") or 0
            banned = await self.db.fetchval("SELECT COUNT(*) FROM banned_users") or 0

            text = (
                f"📊 إحصائيات البوت\n"
                f"━━━━━━━━━━━━━━\n"
                f"👥 المستخدمين: {users}\n"
                f"⭐ VIP: {vips}\n"
                f"🔍 فحوصات اليوم: {scans_today}\n"
                f"📈 إجمالي الفحوصات: {total_scans}\n"
                f"🛡️ تهديدات: {threats}\n"
                f"🚫 محظورين: {banned}\n"
                f"🌐 لوحة التحكم: {Config.WEB_URL}\n"
                f"📡 Webhook: {'مفعل' if Config.WEBHOOK_MODE else 'غير مفعل'}\n"
                f"⚡ MCP: {'مفعل' if Config.ENABLE_MCP else 'غير مفعل'}\n"
                f"━━━━━━━━━━━━━━"
            )
            await message.reply(text)

        @app.on_message(filters.command("export") & filters.user(Config.SUDO_USERS))
        async def export_cmd(client: Client, message: Message):
            sent_msg = await message.reply("📦 جاري تصدير البيانات...")
            try:
                data = await self.db.export_to_json()
                f = io.BytesIO(data.encode())
                f.name = f"bot_backup_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
                await message.reply_document(f, caption="✅ نسخة احتياطية للبيانات")
                await self.db.execute(
                    "INSERT INTO import_export_log (action, user_id, record_count, created_at) VALUES (?, ?, ?, ?)",
                    ("export", message.from_user.id, 0, datetime.utcnow().isoformat()))
                await sent_msg.delete()
            except Exception as e:
                await sent_msg.edit(f"❌ خطأ في التصدير: {e}")

        @app.on_message(filters.command("import") & filters.user(Config.SUDO_USERS))
        async def import_cmd(client: Client, message: Message):
            if not message.reply_to_message or not message.reply_to_message.document:
                await message.reply("❌ يرجى الرد على ملف JSON للاستيراد")
                return
            sent_msg = await message.reply("📦 جاري استيراد البيانات...")
            try:
                file = await message.reply_to_message.download()
                with open(file, "r", encoding="utf-8") as f:
                    data = f.read()
                result = await self.db.import_from_json(data, message.from_user.id)
                os.remove(file)
                await sent_msg.edit(
                    f"✅ تم الاستيراد بنجاح\n"
                    f"📥 السجلات المستوردة: {result.get('imported', 0)}\n"
                    f"❌ الأخطاء: {result.get('errors', 0)}")
            except Exception as e:
                await sent_msg.edit(f"❌ خطأ في الاستيراد: {e}")

        @app.on_message(filters.command("logs") & filters.user(Config.SUDO_USERS))
        async def logs_cmd(client: Client, message: Message):
            try:
                if os.path.exists(Config.LOG_FILE):
                    with open(Config.LOG_FILE, "r", encoding="utf-8") as f:
                        content = f.read()
                    if len(content) > 4000:
                        content = content[-4000:]
                    await message.reply(f"📋 آخر السجلات:\n<pre>{content}</pre>")
                else:
                    await message.reply("❌ ملف السجلات غير موجود")
            except Exception as e:
                await message.reply(f"❌ خطأ: {e}")

        @app.on_message(filters.command("restart") & filters.user(Config.SUDO_USERS))
        async def restart_cmd(client: Client, message: Message):
            await message.reply("♻️ جاري إعادة التشغيل...")
            import os
            os._exit(0)

        @app.on_message(filters.command("clearcache") & filters.user(Config.SUDO_USERS))
        async def clearcache_cmd(client: Client, message: Message):
            await message.reply("🗑️ جاري مسح الذاكرة المؤقتة...")
            keys_to_delete = [k for k in list(self.db.cache._memory.keys()) if k.startswith("scan:")]
            for k in keys_to_delete:
                await self.db.cache.delete(k)
            await message.reply("✅ تم مسح الكاش")

        @app.on_message(filters.command("admin") & filters.user(Config.SUDO_USERS))
        async def admin_panel(client: Client, message: Message):
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("📊 إحصائيات", callback_data="admin_stats"),
                 InlineKeyboardButton("📢 إذاعة", callback_data="admin_broadcast")],
                [InlineKeyboardButton("📦 تصدير", callback_data="admin_export"),
                 InlineKeyboardButton("📥 استيراد", callback_data="admin_import")],
                [InlineKeyboardButton("🚫 حظر", callback_data="admin_ban"),
                 InlineKeyboardButton("✅ إلغاء حظر", callback_data="admin_unban")],
                [InlineKeyboardButton("🗑️ مسح كاش", callback_data="admin_clearcache"),
                 InlineKeyboardButton("♻️ إعادة تشغيل", callback_data="admin_restart")],
                [InlineKeyboardButton("⭐ منح VIP", callback_data="admin_grantvip"),
                 InlineKeyboardButton("🌐 لوحة الويب", url=Config.WEB_URL)],
            ])
            await message.reply("🛠️ لوحة تحكم المشرف", reply_markup=keyboard)

        @app.on_callback_query(filters.regex(r"^admin_"))
        async def admin_callback(client: Client, callback: CallbackQuery):
            action = callback.data.replace("admin_", "")
            if action == "stats":
                await stats_cmd(client, callback.message)
            elif action == "export":
                await export_cmd(client, callback.message)
            elif action == "clearcache":
                await clearcache_cmd(client, callback.message)
            elif action == "restart":
                await restart_cmd(client, callback.message)
            elif action == "grantvip":
                await callback.message.reply("📝 استخدم الأمر: /grantvip <معرف_المستخدم> <عدد_الأشهر>\nمثال: /grantvip 123456789 3")
            elif action in ("broadcast", "ban", "unban", "import"):
                await callback.message.reply(f"📝 استخدم الأمر /{action} بالطريقة الصحيحة")
            await callback.answer()
