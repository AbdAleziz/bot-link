import asyncio
import logging
import os
import sys
from datetime import datetime

# Auto-detect PORT from environment (justrunmy.app sets this)
_PORT = os.getenv("PORT")
if _PORT:
    os.environ["WEB_PORT"] = _PORT
    os.environ["MCP_PORT"] = str(int(_PORT) + 1)

from pyrogram import Client, filters, idle

from config import Config
from database import Database
from scanner import Scanner
from admin import AdminHandler
from vip_handlers import VipHandler
from flood_captcha import FloodCaptcha
from web_dashboard import WebDashboard
from click_tracker import ClickTracker
from mcp_server import MCPServer

# Build logging handlers list safely (fixed syntax error from `*tuple if cond else ()`)
_log_handlers = [logging.StreamHandler()]
if Config.LOG_FILE:
    _log_handlers.append(logging.FileHandler(Config.LOG_FILE, encoding="utf-8"))

logging.basicConfig(
    level=getattr(logging, Config.LOG_LEVEL),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=_log_handlers,
)
logger = logging.getLogger("main")

app = Client(
    "scanner_bot",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN,
    workers=16,
)

db = Database()
scanner = Scanner(db)
admin_handler = AdminHandler(db)
click_tracker = ClickTracker(db)
dashboard = None
mcp = None


async def start_webhook():
    """Set up webhook for justrunmy.app compatibility."""
    try:
        webhook_url = Config.WEBHOOK_URL
        if not webhook_url:
            public_url = os.getenv("PUBLIC_URL", "").rstrip("/")
            if public_url:
                webhook_url = public_url + Config.WEBHOOK_PATH
            else:
                logger.warning("No WEBHOOK_URL or PUBLIC_URL set, webhook mode disabled")
                return

        await app.set_webhook(
            url=webhook_url,
            secret_token=Config.WEBHOOK_SECRET or None,
            max_connections=40,
        )
        logger.info(f"Webhook set to {webhook_url}")
    except Exception as e:
        logger.error(f"Webhook setup failed: {e}")


async def start_dashboard():
    global dashboard
    try:
        dashboard = WebDashboard(db, bot=app)
        await dashboard.start()
        logger.info("Web dashboard started")
    except Exception as e:
        logger.error(f"Dashboard start failed: {e}")


async def start_mcp():
    global mcp
    try:
        mcp = MCPServer(bot=app, db=db, dashboard=dashboard, scanner=scanner)

        from aiohttp import web
        mcp_app = web.Application()

        async def mcp_handler(request):
            data = await request.json()
            result = await mcp.handle_request(data)
            return web.json_response(result)

        mcp_app.router.add_post("/mcp", mcp_handler)

        runner = web.AppRunner(mcp_app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", Config.MCP_PORT)
        await site.start()
        logger.info(f"MCP server running on port {Config.MCP_PORT}")
    except Exception as e:
        logger.error(f"MCP server start failed: {e}")


async def cleanup_expired_links():
    while True:
        try:
            await click_tracker.cleanup_expired()
        except Exception as e:
            logger.error(f"Cleanup error: {e}")
        await asyncio.sleep(3600)


@app.on_message(filters.command("start"))
async def start_cmd(client, message):
    user = message.from_user
    await db.execute(
        "INSERT OR IGNORE INTO users (user_id, username, first_name, last_name, joined_at) VALUES (?, ?, ?, ?, ?)",
        (user.id, user.username or "", user.first_name or "", user.last_name or "",
         datetime.utcnow().isoformat()))

    # Check if user is banned
    banned = await db.fetchrow("SELECT * FROM banned_users WHERE user_id = ?", (user.id,))
    if banned:
        await message.reply("🚫 أنت محظور من استخدام البوت.")
        return

    await message.reply(
        "🤖 <b>مرحباً بك في بوت فحص الروابط</b>\n\n"
        "أرسل لي رابطاً وسأقوم بفحصه بحثاً عن التهديدات الأمنية\n\n"
        "الأوامر المتاحة:\n"
        "/scan <code>الرابط</code> - فحص رابط\n"
        "/vip - معلومات الاشتراك المميز\n"
        "/help - المساعدة\n\n"
        "✨ <b>مميزات VIP:</b>\n"
        "• فحص متقدم بالذكاء الاصطناعي\n"
        "• مراقبة النطاقات\n"
        "• فحص جماعي\n"
        "• وأكثر..."
    )


@app.on_message(filters.command("scan") & filters.private)
async def scan_cmd(client, message):
    user = message.from_user

    # Check ban
    banned = await db.fetchrow("SELECT * FROM banned_users WHERE user_id = ?", (user.id,))
    if banned:
        await message.reply("🚫 أنت محظور من استخدام البوت.")
        return

    text = message.text.split(maxsplit=1)
    if len(text) < 2:
        await message.reply("❌ أرسل الرابط بعد الأمر\nمثال: /scan https://example.com")
        return

    url = text[1].strip()
    sent = await message.reply("🔍 جاري فحص الرابط...")

    # Check for existing scan in cache
    cache_key = f"scan:{url}"
    cached = await db.cache.get(cache_key)
    if cached:
        import json
        result = json.loads(cached)
        await sent.edit(format_scan_result(result))
        return

    # Check VIP status for priority
    vip = await db.fetchrow(
        "SELECT * FROM vip_users WHERE user_id = ? AND expires_at > datetime('now')",
        (user.id,))
    priority = vip is not None

    try:
        result = await scanner.scan_url(url, user.id, priority)
        await sent.edit(format_scan_result(result))
    except Exception as e:
        logger.error(f"Scan error for {url}: {e}")
        await sent.edit(f"❌ حدث خطأ أثناء الفحص: {str(e)[:200]}")


@app.on_message(filters.command("help"))
async def help_cmd(client, message):
    await message.reply(
        "📚 <b>مساعدة البوت</b>\n\n"
        "<b>الأوامر الأساسية:</b>\n"
        "/start - بدء البوت\n"
        "/scan + الرابط - فحص رابط\n"
        "/help - هذه المساعدة\n\n"
        "<b>أوامر VIP:</b>\n"
        "/vip - معلومات الاشتراك\n"
        "/bulkscan - فحص جماعي\n"
        "/domainwatch + النطاق - مراقبة نطاق\n"
        "/myapi - مفتاح API الخاص بك\n"
        "/whitelist + النطاق - إضافة نطاق آمن\n\n"
        "<b>لوحة التحكم:</b>\n"
        f"• لوحة الويب: {Config.WEB_URL}\n"
        "• للإدارة والتقارير"
    )


@app.on_message(filters.command("r"))
async def resolve_short(client, message):
    text = message.text.split(maxsplit=1)
    if len(text) < 2:
        await message.reply("❌ استخدم: /r كود_الرابط")
        return
    code = text[1].strip()
    original = await click_tracker.resolve_short_url(code)
    if original:
        await message.reply(f"🔗 الرابط الأصلي: {original}")
    else:
        await message.reply("❌ الرابط غير موجود أو منتهي الصلاحية")


@app.on_message(filters.command("myapi") & filters.private)
async def myapi_cmd(client, message):
    user_id = message.from_user.id

    # Check VIP
    vip = await db.fetchrow(
        "SELECT * FROM vip_users WHERE user_id = ? AND expires_at > datetime('now')",
        (user_id,))
    if not vip:
        await message.reply("❌ هذه الميزة للمستخدمين VIP فقط\nاستخدم /vip للاشتراك")
        return

    # Find or create API key
    key = await db.fetchrow("SELECT * FROM api_keys WHERE user_id = ?", (user_id,))
    if not key:
        import secrets
        new_key = f"sb_{secrets.token_hex(16)}"
        await db.execute(
            "INSERT INTO api_keys (key, user_id, permissions, created_at) VALUES (?, ?, ?, ?)",
            (new_key, user_id, "read", datetime.utcnow().isoformat()))
        key = {"key": new_key}

    api_endpoint = f"{Config.WEB_URL}/api/scan"

    await message.reply(
        f"🔑 <b>مفتاح API الخاص بك</b>\n\n"
        f"المفتاح: <code>{key['key']}</code>\n"
        f"الرابط: {api_endpoint}\n\n"
        f"<b>طريقة الاستخدام:</b>\n"
        f"<pre>curl -X POST {api_endpoint} \\\n"
        f"  -H \"Authorization: Bearer {key['key']}\" \\\n"
        f"  -H \"Content-Type: application/json\" \\\n"
        f"  -d '{{\"url\":\"https://example.com\"}}'</pre>"
    )


# Webhook handler for justrunmy.app
async def webhook_handler(request):
    from aiohttp import web
    try:
        data = await request.json()
        secret = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
        if Config.WEBHOOK_SECRET and secret != Config.WEBHOOK_SECRET:
            return web.Response(status=403)

        update = data
        await app.process_update(update)
        return web.Response(status=200)
    except Exception as e:
        logger.error(f"Webhook handler error: {e}")
        return web.Response(status=500)


def format_scan_result(result: dict) -> str:
    emoji = "✅" if not result.get("is_threat") else "🚫"
    status_text = "آمن ✅" if not result.get("is_threat") else f"تهديد 🚫 ({result.get('threat_type', 'غير معروف')})"

    text = (
        f"{emoji} <b>نتيجة الفحص</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"🔗 الرابط: <code>{result.get('url', '')[:100]}</code>\n"
        f"🌐 النطاق: {result.get('domain', '')}\n"
        f"📊 الحالة: {status_text}\n"
        f"⭐ ثقة: {result.get('trust_score', 0):.1f}%\n"
    )

    checks = result.get("checks", {})

    # VirusTotal
    vt = checks.get("virustotal", {})
    if isinstance(vt, dict) and vt.get("positives") is not None:
        text += f"🦠 VirusTotal: {vt.get('positives', 0)} إيجابي\n"

    # SSL
    ssl_check = checks.get("ssl", {})
    if isinstance(ssl_check, dict):
        ssl_status = "✅ صالح" if ssl_check.get("valid") else "❌ غير صالح"
        text += f"🔐 SSL: {ssl_status}\n"

    # WHOIS
    whois = checks.get("whois", {})
    if isinstance(whois, dict) and whois.get("registrar"):
        text += f"📅 WHOIS: {whois.get('registrar', '')[:50]}\n"
        if whois.get("age_days"):
            text += f"📆 عمر النطاق: {whois['age_days']} يوم\n"
        if whois.get("risk") and whois["risk"] != "low":
            text += f"⚠️ مخاطرة WHOIS: {whois['risk']}\n"

    text += f"\n🕐 {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC"
    return text


async def main():
    logger.info("Starting bot...")

    await db.init()
    await app.start()

    # Register handlers
    admin_handler.register(app)
    vip_handler = VipHandler(db)
    vip_handler.register(app)
    flood = FloodCaptcha(db)
    flood.register(app)

    # Get bot info
    bot_info = await app.get_me()
    logger.info(f"Bot started: @{bot_info.username}")

    # Start web dashboard
    if Config.ENABLE_DASHBOARD:
        asyncio.create_task(start_dashboard())
        # Small delay to let dashboard initialize
        await asyncio.sleep(1)

    # Setup webhook mode vs polling
    from aiohttp import web

    if Config.WEBHOOK_MODE:
        # Single aiohttp app for both webhook and dashboard
        webhook_app = web.Application()

        # Webhook route for Telegram updates
        webhook_app.router.add_post(Config.WEBHOOK_PATH, webhook_handler)

        # Health check
        webhook_app.router.add_get("/health", lambda r: web.json_response({
            "status": "healthy", "mode": "webhook",
            "timestamp": datetime.utcnow().isoformat()
        }))

        # Merge dashboard routes if available
        if dashboard:
            webhook_app.router.add_routes(dashboard.app.router.routes())

        runner = web.AppRunner(webhook_app)
        await runner.setup()
        site = web.TCPSite(runner, Config.WEB_HOST, Config.WEB_PORT)
        await site.start()
        logger.info(f"Webhook+dashboard server on {Config.WEB_HOST}:{Config.WEB_PORT}")

        if Config.WEBHOOK_URL:
            await start_webhook()

        # Stop the dashboard's own runner since we merged routes
        if dashboard and hasattr(dashboard, 'runner') and dashboard.runner:
            await dashboard.runner.cleanup()
            dashboard.runner = None
    else:
        logger.info("Running in polling mode")

    # Start MCP server
    if Config.ENABLE_MCP:
        asyncio.create_task(start_mcp())

    # Start cleanup task
    asyncio.create_task(cleanup_expired_links())

    logger.info("Bot is ready!")
    await idle()

    # Shutdown
    logger.info("Shutting down...")
    if dashboard:
        await dashboard.stop()
    await scanner.close()
    await db.close()
    await app.stop()


if __name__ == "__main__":
    try:
        # Ensure data directory exists
        os.makedirs("data", exist_ok=True)
        os.makedirs("uploads", exist_ok=True)

        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except ImportError as e:
        logger.error(f"Missing module: {e}")
        logger.error(f"Run: pip install -r requirements.txt")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)
