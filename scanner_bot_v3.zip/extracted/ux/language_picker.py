import logging

from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from config import Config
from database import Database

logger = logging.getLogger(__name__)

LANGUAGES = {
    "ar": "🇸🇦 العربية",
    "en": "🇬🇧 English",
    "ku": "🇹🇯 كوردی",
}


async def register_language_picker(app: Client, db: Database):
    await db.execute("""
        CREATE TABLE IF NOT EXISTS user_language (
            user_id INTEGER PRIMARY KEY,
            language_code TEXT NOT NULL DEFAULT 'ar',
            updated_at TEXT
        )
    """)

    @app.on_message(filters.command("language") & filters.private)
    async def language_cmd(client: Client, message: Message):
        uid = message.from_user.id
        current = await db.fetchval(
            "SELECT language_code FROM user_language WHERE user_id = ?", (uid,)
        ) or "ar"

        text = "🌐 <b>اختر لغتك / Choose your language / زمانت هه‌ڵبژێره</b>\n━━━━━━━━━━━━━━\n"
        kb_rows = []
        for code, label in LANGUAGES.items():
            indicator = "✅" if code == current else ""
            kb_rows.append([
                InlineKeyboardButton(f"{indicator} {label}", callback_data=f"lang_{code}")
            ])
        kb_rows.append([InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")])

        await message.reply(text, reply_markup=InlineKeyboardMarkup(kb_rows))

    @app.on_callback_query(filters.regex(r"^lang_"))
    async def lang_callback(client: Client, cb: CallbackQuery):
        uid = cb.from_user.id
        lang_code = cb.data[len("lang_"):]

        if lang_code not in LANGUAGES:
            await cb.answer("❌ لغة غير مدعومة.")
            return

        await db.execute(
            "INSERT OR REPLACE INTO user_language (user_id, language_code, updated_at) VALUES (?, ?, ?)",
            (uid, lang_code, __import__("datetime").datetime.utcnow().isoformat()),
        )

        labels = {
            "ar": f"✅ تم تعيين اللغة إلى {LANGUAGES['ar']}",
            "en": f"✅ Language set to {LANGUAGES['en']}",
            "ku": f"✅ زمان به‌ {LANGUAGES['ku']} گۆڕا",
        }
        await cb.answer(labels.get(lang_code, "✅ Language updated!"), show_alert=True)

        current_display = LANGUAGES.get(lang_code, lang_code)
        await cb.message.edit(
            f"🌐 <b>Language / اللغة / زمان</b>\n━━━━━━━━━━━━━━\n"
            f"✅ {current_display}\n"
            f"━━━━━━━━━━━━━━",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")]
            ]),
        )


async def get_user_language(db: Database, user_id: int) -> str:
    code = await db.fetchval(
        "SELECT language_code FROM user_language WHERE user_id = ?", (user_id,)
    )
    return code or "ar"
