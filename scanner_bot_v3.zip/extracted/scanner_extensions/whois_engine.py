import asyncio
import json
import logging
from datetime import datetime, timedelta

from config import Config

logger = logging.getLogger(__name__)


class WhoisEngine:
    def __init__(self, db):
        self.db = db

    async def lookup(self, domain: str) -> dict:
        cache_key = f"whois:{domain}"
        cached = await self.db.cache.get(cache_key)
        if cached:
            try:
                return json.loads(cached)
            except Exception:
                pass

        row = await self.db.fetchrow(
            "SELECT result, looked_up_at FROM whois_cache WHERE domain = ?",
            (domain,),
        )
        if row:
            try:
                looked_at = datetime.fromisoformat(row["looked_up_at"])
                if datetime.utcnow() - looked_at < timedelta(hours=24):
                    return json.loads(row["result"])
            except Exception:
                pass

        result = await self._query_whois(domain)

        await self.db.execute(
            "INSERT OR REPLACE INTO whois_cache (domain, result, looked_up_at) VALUES (?, ?, ?)",
            (domain, json.dumps(result, ensure_ascii=False), datetime.utcnow().isoformat()),
        )

        await self.db.cache.set(cache_key, json.dumps(result), ttl=86400)

        return result

    async def _query_whois(self, domain: str) -> dict:
        try:
            import whois as whois_lib

            w = await asyncio.wait_for(
                asyncio.to_thread(whois_lib.whois, domain),
                timeout=10,
            )

            result = {
                "domain": domain,
                "registrar": str(w.registrar or ""),
                "creation_date": str(w.creation_date) if w.creation_date else None,
                "expiration_date": str(w.expiration_date) if w.expiration_date else None,
                "name_servers": w.name_servers[:5] if w.name_servers else [],
                "org": str(w.org or ""),
                "country": str(w.country or ""),
                "emails": w.emails[:3] if w.emails else [],
                "status": w.status,
                "dnssec": str(w.dnssec or ""),
            }

            risk_score = 5
            risk_label = "negligible"
            if w.creation_date:
                try:
                    cd = w.creation_date
                    if isinstance(cd, list):
                        cd = cd[0]
                    age_days = (datetime.now() - cd).days
                    result["age_days"] = age_days
                    if age_days < 30:
                        risk_score = 80
                        risk_label = "high"
                    elif age_days < 180:
                        risk_score = 50
                        risk_label = "medium"
                    elif age_days < 365:
                        risk_score = 20
                        risk_label = "low"
                    else:
                        risk_score = 5
                        risk_label = "negligible"
                except Exception:
                    pass

            result["risk_score"] = risk_score
            result["risk_label"] = risk_label
            return result

        except asyncio.TimeoutError:
            logger.warning(f"WHOIS timeout for {domain}")
            return {"domain": domain, "error": "timeout", "risk_score": 0, "risk_label": "unknown"}
        except ImportError:
            return {"domain": domain, "error": "whois library not available", "risk_score": 0, "risk_label": "unknown"}
        except Exception as e:
            logger.error(f"WHOIS error for {domain}: {e}")
            return {"domain": domain, "error": str(e)[:200], "risk_score": 0, "risk_label": "unknown"}
