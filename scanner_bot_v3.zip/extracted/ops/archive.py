# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import logging
from datetime import datetime, timezone

from config import Config

logger = logging.getLogger(__name__)

_ARCHIVE_TABLES = {
    "scan_history": "scan_history_archive",
    "audit_log": "audit_log_archive",
    "click_logs": "click_logs_archive",
}


class ArchiveManager:
    def __init__(self):
        self._task: asyncio.Task | None = None
        self._running = False

    async def _archive_table(self, db, source: str, archive: str, cutoff: str):
        try:
            row = await db.fetchval(
                f"SELECT COUNT(*) FROM {source} WHERE created_at < ?",
                (cutoff,),
            ) if source == "audit_log" else await db.fetchval(
                f"SELECT COUNT(*) FROM {source} WHERE scanned_at < ?",
                (cutoff,),
            )
            count_before = row or 0
            if count_before == 0:
                logger.info("No rows to archive from %s", source)
                return 0

            await db.execute(f"DELETE FROM {source} WHERE scanned_at < ?", (cutoff,))
            vacuum_after = True
            return count_before
        except Exception:
            pass

        try:
            await db.execute(
                f"INSERT INTO {archive} SELECT * FROM {source} WHERE scanned_at < ?",
                (cutoff,),
            )
            await db.execute(f"DELETE FROM {source} WHERE scanned_at < ?", (cutoff,))
        except Exception:
            pass

        try:
            await db.execute(
                f"INSERT INTO {archive} SELECT * FROM {source} WHERE created_at < ?",
                (cutoff,),
            )
            await db.execute(f"DELETE FROM {source} WHERE created_at < ?", (cutoff,))
        except Exception as e:
            logger.error("Archive error for %s: %s", source, e)
            return 0

        return count_before

    async def run_archive(self, db):
        logger.info("Starting monthly archive...")
        cutoff = datetime.now(timezone.utc).isoformat()

        total_before = 0
        total_after = 0

        for source, archive in _ARCHIVE_TABLES.items():
            try:
                await db.execute(
                    f"CREATE TABLE IF NOT EXISTS {archive} AS SELECT * FROM {source} WHERE 1=0"
                )
            except Exception:
                await db.execute(
                    f"CREATE TABLE IF NOT EXISTS {archive} (id INTEGER PRIMARY KEY AUTOINCREMENT)"
                )
                logger.warning("Created empty archive table %s", archive)

            count = await self._archive_table(db, source, archive, cutoff)
            total_before += count

        await db.execute("VACUUM")
        logger.info("VACUUM completed after archive")

        total_after = 0
        for source in _ARCHIVE_TABLES:
            try:
                row = await db.fetchval(f"SELECT COUNT(*) FROM {source}")
                total_after += row or 0
            except Exception:
                pass

        summary = (
            f"📦 <b>Monthly Archive Complete</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"🗂 Rows archived: {total_before}\n"
            f"📊 Remaining rows: {total_after}\n"
            f"━━━━━━━━━━━━━━"
        )
        logger.info(summary)
        await self._log_to_channel(summary)

    async def _log_to_channel(self, message: str):
        alert_channel = getattr(Config, "ALERT_LOG_CHANNEL", 0)
        if not alert_channel:
            return
        try:
            from main import app
            await app.send_message(alert_channel, message)
        except Exception as e:
            logger.error("Archive channel log error: %s", e)

    async def _scheduler(self, db):
        self._running = True
        while self._running:
            now = datetime.now(timezone.utc)
            if now.day == 1 and now.hour == 2 and now.minute == 0:
                try:
                    await self.run_archive(db)
                except Exception as e:
                    logger.error("Scheduled archive error: %s", e)
                await asyncio.sleep(3600)
            await asyncio.sleep(30)

    def start(self, db):
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._scheduler(db))

    async def stop(self):
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None


archive_manager = ArchiveManager()
