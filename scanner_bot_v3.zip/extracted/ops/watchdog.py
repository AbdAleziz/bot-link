# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import functools
import gc
import logging
import os
import time

from config import Config

logger = logging.getLogger(__name__)

_METRIC_COUNTER = 0


def with_watchdog(timeout: int = 10):
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            handler_name = func.__name__
            chat_id = kwargs.get("chat_id") or kwargs.get("user_id") or 0
            for arg in args:
                if hasattr(arg, "from_user") and arg.from_user:
                    chat_id = arg.from_user.id
                    break
                if hasattr(arg, "chat") and arg.chat:
                    chat_id = arg.chat.id
                    break

            try:
                return await asyncio.wait_for(func(*args, **kwargs), timeout=timeout)
            except asyncio.TimeoutError:
                global _METRIC_COUNTER
                _METRIC_COUNTER += 1
                logger.error(
                    "Watchdog timeout for handler '%s' (chat_id=%s) after %ss",
                    handler_name,
                    chat_id,
                    timeout,
                )
                fallback_msg = kwargs.get(
                    "fallback_message",
                    "⚠️ The operation timed out. Please try again later.",
                )
                return fallback_msg
        return wrapper
    return decorator


class MemoryWatchdog:
    def __init__(self):
        self._task: asyncio.Task | None = None
        self._running = False

    async def _check_loop(self):
        logger.info("Memory watchdog started (checking every 30s)")
        self._running = True
        while self._running:
            try:
                await self._check()
            except Exception as e:
                logger.error("Memory watchdog check error: %s", e)
            await asyncio.sleep(30)

    async def _check(self):
        try:
            import psutil
            proc = psutil.Process(os.getpid())
            rss_mb = proc.memory_info().rss / (1024 * 1024)
        except ImportError:
            return

        max_ram = getattr(Config, "MAX_RAM_MB", 800)
        max_ram_hard = getattr(Config, "MAX_RAM_HARD_MB", 1024)

        if rss_mb > max_ram_hard:
            logger.critical(
                "RSS %.0fMB exceeds hard limit %dMB, triggering graceful restart",
                rss_mb,
                max_ram_hard,
            )
            await self._alert_owner(
                f"🚨 Memory critical: {rss_mb:.0f}MB > {max_ram_hard}MB. Restarting..."
            )
            self._running = False
            os._exit(1)

        if rss_mb > max_ram:
            logger.warning(
                "RSS %.0fMB exceeds soft limit %dMB, forcing GC and cache eviction",
                rss_mb,
                max_ram,
            )
            gc.collect()
            self._drop_lru_caches()
            await self._alert_owner(
                f"⚠️ Memory high: {rss_mb:.0f}MB > {max_ram}MB. GC + caches dropped."
            )

    def _drop_lru_caches(self):
        from database import Database
        if hasattr(Database, "cache") and Database.cache:
            Database.cache._memory.clear()
            Database.cache._ttl.clear()
            logger.info("LRU cache dropped due to memory pressure")

    async def _alert_owner(self, message: str):
        alert_channel = getattr(Config, "ALERT_LOG_CHANNEL", 0)
        if not alert_channel:
            return
        try:
            from main import app
            await app.send_message(alert_channel, message)
        except Exception as e:
            logger.error("Failed to send memory alert: %s", e)

    def start(self):
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._check_loop())

    async def stop(self):
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None


memory_watchdog = MemoryWatchdog()
