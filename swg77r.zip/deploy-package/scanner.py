# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import json
import logging
import ssl
from datetime import datetime
from urllib.parse import urlparse

import httpx

from config import Config
from database import Database

logger = logging.getLogger("scanner")

# Well-known brand domains commonly targeted by typosquatting/phishing.
POPULAR_BRANDS = [
    "google.com", "youtube.com", "facebook.com", "instagram.com", "whatsapp.com",
    "apple.com", "microsoft.com", "amazon.com", "netflix.com", "paypal.com",
    "twitter.com", "x.com", "linkedin.com", "tiktok.com", "telegram.org",
    "binance.com", "coinbase.com", "steampowered.com", "bankofamerica.com",
    "chase.com", "wellsfargo.com", "outlook.com", "gmail.com", "icloud.com",
    "dropbox.com", "adobe.com", "spotify.com", "ebay.com", "aliexpress.com",
    "discord.com", "twitch.tv", "roblox.com", "yahoo.com", "hotmail.com",
]

# Cyrillic / Greek characters that visually mimic Latin letters (homograph attacks).
CONFUSABLE_CHARS = set("аеорсухАЕОРСУХіІѕЅ" + "αερτυο")


class Scanner:
    def __init__(self, db: Database):
        self.db = db
        self._client = httpx.AsyncClient(
            timeout=Config.SCAN_TIMEOUT,
            follow_redirects=True,
            max_redirects=Config.MAX_REDIRECTS,
            verify=False,
            headers={"User-Agent": "Mozilla/5.0 (compatible; SecurityBot/2.0)"}
        )

    async def scan_url(self, url: str, user_id: int = None,
                       priority: bool = False) -> dict:
        # Check cache
        cache_key = f"scan:{url}"
        cached = await self.db.cache.get(cache_key)
        if cached and not priority:
            try:
                return json.loads(cached)
            except Exception:
                pass

        parsed = urlparse(url)
        if not parsed.scheme:
            url = "https://" + url
            parsed = urlparse(url)

        domain = parsed.netloc.lower()
        result = {
            "url": url, "domain": domain, "scanned_at": datetime.utcnow().isoformat(),
            "is_threat": False, "threat_type": None, "trust_score": 100.0,
            "vt_positives": 0, "whois": {}, "checks": {}
        }

        # Run all checks concurrently
        checks = await asyncio.gather(
            self._check_local_blacklist(url, domain),
            self._check_ssl(domain),
            self._check_virustotal(url),
            self._check_urlscan(url),
            self._check_whois(domain),
            self._check_redirects(url),
            self._check_typosquatting(domain),
            self._check_homograph(domain),
            self._check_reports(domain),
            return_exceptions=True
        )

        (bl_result, ssl_result, vt_result, us_result, whois_result, redirect_result,
         typo_result, homograph_result, reports_result) = checks

        # Process checks
        result["checks"]["blacklist"] = bl_result if isinstance(bl_result, dict) else {"error": str(bl_result)}
        result["checks"]["ssl"] = ssl_result if isinstance(ssl_result, dict) else {"error": str(ssl_result)}
        result["checks"]["virustotal"] = vt_result if isinstance(vt_result, dict) else {"error": str(vt_result)}
        result["checks"]["urlscan"] = us_result if isinstance(us_result, dict) else {"error": str(us_result)}
        result["checks"]["whois"] = whois_result if isinstance(whois_result, dict) else {"error": str(whois_result)}
        result["checks"]["redirects"] = redirect_result if isinstance(redirect_result, list) else {"error": str(redirect_result)}
        result["checks"]["typosquatting"] = typo_result if isinstance(typo_result, dict) else {"error": str(typo_result)}
        result["checks"]["homograph"] = homograph_result if isinstance(homograph_result, dict) else {"error": str(homograph_result)}
        result["checks"]["community_reports"] = reports_result if isinstance(reports_result, dict) else {"error": str(reports_result)}

        # Aggregate threats
        if isinstance(bl_result, dict) and bl_result.get("blocked"):
            result["is_threat"] = True
            result["threat_type"] = "blacklist"
            result["trust_score"] = 0

        if isinstance(vt_result, dict):
            result["vt_positives"] = vt_result.get("positives", 0)
            if vt_result.get("malicious"):
                result["is_threat"] = True
                result["threat_type"] = "virus_total"
                result["trust_score"] = min(result["trust_score"], 20)

        if isinstance(ssl_result, dict) and not ssl_result.get("valid"):
            result["trust_score"] -= 15

        if isinstance(whois_result, dict) and whois_result.get("risk") == "high":
            result["trust_score"] -= 20

        if isinstance(typo_result, dict) and typo_result.get("suspicious"):
            result["is_threat"] = True
            result["threat_type"] = result["threat_type"] or "typosquatting"
            result["trust_score"] = min(result["trust_score"], 25)

        if isinstance(homograph_result, dict) and homograph_result.get("suspicious"):
            result["is_threat"] = True
            result["threat_type"] = result["threat_type"] or "homograph_attack"
            result["trust_score"] = min(result["trust_score"], 15)

        if isinstance(reports_result, dict) and reports_result.get("count", 0) >= 3:
            result["is_threat"] = True
            result["threat_type"] = result["threat_type"] or "community_reported"
            result["trust_score"] -= min(60, reports_result["count"] * 10)

        result["trust_score"] = max(0, min(100, result["trust_score"]))

        if not result["is_threat"] and result["trust_score"] < 50:
            result["is_threat"] = True
            result["threat_type"] = "low_trust"

        # Reclassification check: compare against the most recent previous scan of this exact URL
        reclassified = False
        previous_verdict = None
        try:
            prev = await self.db.fetchrow(
                "SELECT is_threat, trust_score FROM scan_history WHERE url = ? ORDER BY id DESC LIMIT 1",
                (url[:2000],),
            )
            if prev is not None:
                previous_verdict = bool(prev["is_threat"])
                if previous_verdict != result["is_threat"]:
                    reclassified = True
        except Exception as e:
            logger.error(f"Reclassification check failed for {url}: {e}")

        result["reclassified"] = reclassified
        result["previous_verdict"] = previous_verdict

        # Save to history
        await self.db.execute(
            "INSERT INTO scan_history (url, domain, user_id, is_threat, threat_type, trust_score, vt_positives, scanner_result, scanned_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (url[:2000], domain, user_id, int(result["is_threat"]), result["threat_type"],
             result["trust_score"], result["vt_positives"],
             json.dumps(result, ensure_ascii=False)[:5000],
             result["scanned_at"])
        )

        # Cache result
        await self.db.cache.set(cache_key, json.dumps(result), Config.SCAN_CACHE_TTL)

        return result

    @staticmethod
    def _levenshtein(a: str, b: str) -> int:
        if a == b:
            return 0
        if not a:
            return len(b)
        if not b:
            return len(a)
        prev = list(range(len(b) + 1))
        for i, ca in enumerate(a, 1):
            cur = [i] + [0] * len(b)
            for j, cb in enumerate(b, 1):
                cur[j] = min(
                    prev[j] + 1,      # deletion
                    cur[j - 1] + 1,   # insertion
                    prev[j - 1] + (ca != cb),  # substitution
                )
            prev = cur
        return prev[-1]

    async def _check_typosquatting(self, domain: str) -> dict:
        try:
            bare = domain.split(":")[0].lower()
            if bare.startswith("www."):
                bare = bare[4:]
            parts = bare.split(".")
            registrable = ".".join(parts[-2:]) if len(parts) >= 2 else bare

            if registrable in POPULAR_BRANDS:
                return {"suspicious": False}

            closest, closest_dist = None, 99
            for brand in POPULAR_BRANDS:
                dist = self._levenshtein(registrable, brand)
                if dist < closest_dist:
                    closest, closest_dist = brand, dist

            # A tiny edit distance to a known brand (but not that brand or its subdomain) is suspicious
            if closest and 0 < closest_dist <= 2 and not bare.endswith("." + closest):
                return {
                    "suspicious": True,
                    "looks_like": closest,
                    "distance": closest_dist,
                    "reason": f"'{registrable}' closely resembles '{closest}'",
                }
            return {"suspicious": False}
        except Exception as e:
            return {"error": str(e)}

    async def _check_homograph(self, domain: str) -> dict:
        try:
            bare = domain.split(":")[0]
            flags = []

            if "xn--" in bare:
                flags.append("punycode_encoded")
                try:
                    decoded = bare.encode("ascii").decode("idna")
                    flags.append(f"decodes_to:{decoded}")
                except Exception:
                    pass

            has_latin = any(c.isascii() and c.isalpha() for c in bare)
            has_non_ascii = any(not c.isascii() for c in bare)
            if has_latin and has_non_ascii:
                flags.append("mixed_script")

            if any(ch in CONFUSABLE_CHARS for ch in bare):
                flags.append("confusable_characters")

            return {"suspicious": bool(flags), "flags": flags}
        except Exception as e:
            return {"error": str(e)}

    async def _check_reports(self, domain: str) -> dict:
        try:
            count = await self.db.fetchval(
                "SELECT COUNT(*) FROM url_reports WHERE domain = ?", (domain,)
            )
            return {"count": count or 0}
        except Exception as e:
            return {"error": str(e)}

    async def report_url(self, url: str, domain: str, reported_by: int, reason: str = "") -> dict:
        await self.db.execute(
            "INSERT INTO url_reports (url, domain, reported_by, reason, created_at) VALUES (?, ?, ?, ?, ?)",
            (url[:2000], domain, reported_by, reason[:500], datetime.utcnow().isoformat()),
        )
        # A fresh report should be reflected immediately, not served from a stale cache
        await self.db.cache.delete(f"scan:{url}")
        count = await self.db.fetchval(
            "SELECT COUNT(*) FROM url_reports WHERE domain = ?", (domain,)
        )
        return {"total_reports": count or 0}

    async def _check_local_blacklist(self, url: str, domain: str) -> dict:
        try:
            rows = await self.db.fetch("SELECT pattern FROM blacklist")
            for row in rows:
                pattern = row["pattern"]
                if pattern in url or pattern in domain:
                    return {"blocked": True, "pattern": pattern}
            return {"blocked": False}
        except Exception as e:
            return {"error": str(e)}

    async def _check_ssl(self, domain: str) -> dict:
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = True
            ctx.verify_mode = ssl.CERT_REQUIRED

            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(domain, 443, ssl=ctx, server_hostname=domain),
                timeout=10
            )

            cert = writer.get_extra_info("ssl_object").getpeercert()
            writer.close()

            if not cert:
                return {"valid": False, "reason": "no certificate"}

            return {"valid": True, "issuer": dict(cert.get("issuer", [])), "expiry": cert.get("notAfter", "unknown")}
        except Exception as e:
            return {"valid": False, "reason": str(e)}

    async def _check_virustotal(self, url: str) -> dict:
        if not Config.VIRUSTOTAL_API_KEY:
            return {"error": "no API key"}

        try:
            # Submit URL for analysis
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.post(
                    "https://www.virustotal.com/api/v3/urls",
                    headers={"x-apikey": Config.VIRUSTOTAL_API_KEY},
                    data={"url": url}
                )
                if resp.status_code != 200:
                    return {"error": f"VT submission failed: {resp.status_code}"}

                data = resp.json()
                analysis_id = data.get("data", {}).get("id", "")

                # Wait and get analysis
                await asyncio.sleep(3)
                analysis_url = f"https://www.virustotal.com/api/v3/analyses/{analysis_id}"
                resp = await client.get(
                    analysis_url,
                    headers={"x-apikey": Config.VIRUSTOTAL_API_KEY}
                )

                if resp.status_code != 200:
                    return {"error": f"VT analysis failed: {resp.status_code}"}

                result = resp.json()
                stats = result.get("data", {}).get("attributes", {}).get("stats", {})
                return {
                    "malicious": stats.get("malicious", 0) > 0,
                    "suspicious": stats.get("suspicious", 0),
                    "harmless": stats.get("harmless", 0),
                    "undetected": stats.get("undetected", 0),
                    "positives": stats.get("malicious", 0) + stats.get("suspicious", 0),
                }
        except Exception as e:
            return {"error": str(e)}

    async def _check_urlscan(self, url: str) -> dict:
        if not Config.URLSCAN_API_KEY:
            return {"error": "no API key"}

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                # Submit scan
                resp = await client.post(
                    "https://urlscan.io/api/v1/scan/",
                    headers={
                        "API-Key": Config.URLSCAN_API_KEY,
                        "Content-Type": "application/json"
                    },
                    json={"url": url, "visibility": "public"}
                )

                if resp.status_code != 200:
                    return {"error": f"URLScan submission failed: {resp.status_code}"}

                result = resp.json()
                uuid = result.get("uuid", "")

                # Poll for results
                for _ in range(10):
                    await asyncio.sleep(3)
                    resp = await client.get(
                        f"https://urlscan.io/api/v1/result/{uuid}/"
                    )
                    if resp.status_code == 200:
                        data = resp.json()
                        verdicts = data.get("verdicts", {})
                        overall = verdicts.get("overall", {})

                        return {
                            "malicious": overall.get("malicious", False),
                            "score": overall.get("score", 0),
                            "categories": data.get("lists", {}).get("categories", []),
                            "country": data.get("page", {}).get("country", ""),
                            "ip": data.get("page", {}).get("ip", ""),
                            "server": data.get("page", {}).get("server", ""),
                            "url": data.get("page", {}).get("url", ""),
                        }

                return {"error": "timeout waiting for URLScan result"}
        except Exception as e:
            return {"error": str(e)}

    async def _check_whois(self, domain: str) -> dict:
        try:
            import whois as whois_lib
            w = await asyncio.to_thread(whois_lib.whois, domain)

            result = {
                "registrar": w.registrar,
                "creation_date": str(w.creation_date) if w.creation_date else None,
                "expiration_date": str(w.expiration_date) if w.expiration_date else None,
                "name_servers": w.name_servers[:5] if w.name_servers else [],
                "org": w.org,
                "country": w.country,
                "emails": w.emails[:3] if w.emails else [],
            }

            # Risk assessment based on WHOIS
            risk = "low"
            risk_factors = []

            # New domain (less than 30 days) = risk
            if w.creation_date:
                try:
                    if isinstance(w.creation_date, list):
                        creation = w.creation_date[0]
                    else:
                        creation = w.creation_date
                    age_days = (datetime.now() - creation).days
                    result["age_days"] = age_days
                    if age_days < 30:
                        risk = "high"
                        risk_factors.append(f"domain age: {age_days} days")
                    elif age_days < 365:
                        risk = "medium"
                        risk_factors.append(f"domain age: {age_days} days")
                except Exception:
                    pass

            # Missing registrar info = risk
            if not w.registrar:
                risk_factors.append("no registrar info")
                if risk != "high":
                    risk = "medium"

            # Privacy/protected email = risk
            if w.emails and any("privacy" in str(e).lower() or "protect" in str(e).lower() for e in w.emails):
                risk_factors.append("privacy-protected WHOIS")

            result["risk"] = risk
            result["risk_factors"] = risk_factors
            return result
        except ImportError:
            return {"error": "whois library not available"}
        except Exception as e:
            return {"error": str(e)}

    async def _check_redirects(self, url: str) -> list:
        results = []
        try:
            async with httpx.AsyncClient(
                timeout=Config.SCAN_TIMEOUT,
                follow_redirects=True,
                max_redirects=Config.MAX_REDIRECTS,
                verify=False
            ) as client:
                resp = await client.get(url, headers={"User-Agent": "Mozilla/5.0"})
                for r in resp.history:
                    results.append({"from": str(r.url), "status": r.status_code})
                results.append({"final": str(resp.url), "status": resp.status_code})
        except httpx.MaxRedirectException:
            results.append({"error": "max redirects exceeded"})
        except Exception as e:
            results.append({"error": str(e)})
        return results

    async def close(self):
        await self._client.aclose()
