# scanner_bot — AI Agent Guide

## Project Overview
scanner_bot is a Pyrogram-based Telegram bot for URL scanning (VirusTotal/URLScan), QR code generation/decoding, and VIP subscription management. Uses SQLite/Turso/Postgres (auto-detected), optional Redis, and aiohttp for web dashboard.

## Key Files
```
main.py              — Entry point, all bot handlers, lifecycle
config/__init__.py   — Config class reading env vars
rbac.py              — Roles: OWNER, SUB_DEV, USER; is_admin(), is_owner()
database.py          — SQLite/Turso/Postgres via async, WAL mode
admin_panel.py       — Admin panel UI (/panel), broadcast/ban/unban/export
backup_system.py     — BackupManager: tar.gz backups, auto-scheduler, restore
vip_system.py        — VIP subscription management
vip_handlers.py      — Telegram Stars payment flow
services/payment_flow.py — Iraqi manual payment flow
scanner.py           — URL scanning engine (VT, URLScan, SSL, WHOIS)
qr_system.py         — QR code generation/decode/analytics
queue_system.py      — Async task queue (Redis or in-memory)
rate_limiter.py      — Per-user rate limiting
flood_captcha.py     — Flood protection captcha
web_dashboard.py     — aiohttp web dashboard
mcp_server.py        — MCP protocol server
click_tracker.py     — Short link click tracking
```

## How to Run
```bash
cp .env.example .env   # edit with real values
pip install -r requirements.txt
python main.py
```

## Environment Variables
All config is in `config/__init__.py`. See `.env.example` for the full list.
Key vars: `BOT_TOKEN`, `API_ID`, `API_HASH`, `PRIMARY_ADMIN_ID`, `SUDO_USERS`, `DATABASE_URL`.

## Backup System
The `BackupManager` class (`backup_system.py`) provides:
- Manual backups via `/backup` command (admins only)
- Auto daily backups at `BACKUP_AUTO_HOUR` UTC
- Backup list/restore/delete via `/backups` command with inline UI
- 2-step confirmation before restore (destructive operation safety)
- Path traversal protection on delete/restore
- Old backup cleanup (keep `BACKUP_KEEP_LAST`)
- Rollback backup created before restore

## Adding New Features
- **New bot commands**: Add handlers in `main.py` using `@app.on_message(filters.command(...))`
- **New services**: Create file in `services/` or at root level
- **New config**: Add var to `config/__init__.py` and `.env.example`
- **RBAC**: Always check `RBAC.is_admin(uid)` for admin-only commands

## Coding Conventions
- Async/await throughout (Pyrogram async client)
- Snake_case file names and function names
- `logging.getLogger(__name__)` — never `print()`
- Config vars accessed via `Config.UPPER_CASE` class attributes
- Inline keyboards use `InlineKeyboardMarkup` + `InlineKeyboardButton`
- Callback data prefixed with namespace (e.g., `backup_view_`, `adm_`)
- No hardcoded paths — read everything from `Config`
- Do NOT commit `.env` — it's in `.gitignore`
