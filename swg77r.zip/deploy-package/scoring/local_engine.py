# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import json
import logging
import os
import re
import unicodedata
from dataclasses import dataclass, field
from typing import List
from urllib.parse import urlparse

from config import Config

logger = logging.getLogger(__name__)

DANGEROUS_EXTENSIONS = {
    ".exe", ".scr", ".apk", ".bat", ".cmd", ".com", ".msi", ".msp",
    ".vbs", ".vbe", ".ps1", ".psm1", ".psd1", ".jar", ".dmg", ".pkg",
    ".docm", ".xlsm", ".pptm", ".hta", ".wsf", ".wsh", ".cpl",
}

SUSPICIOUS_TLDS = {
    ".zip", ".top", ".xyz", ".country", ".tk", ".gq", ".ml", ".cf",
    ".click", ".download", ".review", ".work", ".date", ".men",
    ".loan", ".win", ".bid", ".trade", ".webcam", ".science",
}

ENGINE_VERSION = "1.0.0"

try:
    import Levenshtein as _lev
    _levenshtein = _lev.distance
    HAS_LEVENSHTEIN = True
except ImportError:
    HAS_LEVENSHTEIN = False

    def _levenshtein(a: str, b: str) -> int:
        if a == b:
            return 0
        if not a:
            return len(b)
        if not b:
            return len(a)
        prev = list(range(len(b) + 1))
        cur = [0] * (len(b) + 1)
        for i, ca in enumerate(a, 1):
            cur[0] = i
            for j, cb in enumerate(b, 1):
                cur[j] = min(
                    prev[j] + 1,
                    cur[j - 1] + 1,
                    prev[j - 1] + (0 if ca == cb else 1),
                )
            prev, cur = cur, [0] * (len(b) + 1)
        return prev[-1]


def _load_tranco_list() -> List[str]:
    path = os.path.join(os.path.dirname(__file__), "tranco_top500.json")
    try:
        with open(path, "r") as f:
            data = json.load(f)
        if isinstance(data, list):
            return [d.lower().lstrip(".") for d in data if isinstance(d, str)]
        logger.warning("tranco_top500.json is not a list; using empty list")
        return []
    except Exception as exc:
        logger.error("Failed to load Tranco list: %s", exc)
        return []


TRANCO_LIST = _load_tranco_list()


@dataclass
class LocalVerdict:
    url: str
    score: int
    level: str
    reasons: List[str] = field(default_factory=list)
    engine_version: str = ENGINE_VERSION


class LocalEngine:
    def __init__(self):
        self._tranco = TRANCO_LIST
        logger.info(
            "LocalEngine v%s initialised (Levenshtein: %s, tranco: %d domains)",
            ENGINE_VERSION,
            "C" if HAS_LEVENSHTEIN else "pure-Python",
            len(self._tranco),
        )

    async def score(self, url: str) -> LocalVerdict:
        score = 0
        reasons = []
        parsed = urlparse(url)
        domain = parsed.netloc.lower()
        path = parsed.path
        hostname = parsed.hostname or ""

        # 1. File-extension guard
        for ext in DANGEROUS_EXTENSIONS:
            if path.lower().endswith(ext):
                score += 40
                reasons.append(f"Dangerous file extension: {ext}")
                break

        # 2. Raw-IP URL detection
        ip_pattern = re.compile(
            r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$"
        )
        if ip_pattern.match(hostname):
            score += 30
            reasons.append(f"Raw IP address in URL: {hostname}")

        # Also detect IPv6 in brackets
        if hostname.startswith("[") and hostname.endswith("]"):
            score += 30
            reasons.append("IPv6 address in URL")

        # 3. IDN / homoglyph detection via NFKD normalization
        idn_detected = False
        if any(ord(c) > 127 for c in domain):
            idn_detected = True
            score += 25
            reasons.append("Internationalized domain name with potential homoglyphs")
        if not idn_detected:
            try:
                nfkd = unicodedata.normalize("NFKD", domain)
                if domain != nfkd:
                    score += 25
                    reasons.append("Homoglyph characters detected via NFKD normalization")
            except Exception:
                pass

        # 4. Typosquatting vs Tranco top-500
        domain_main = hostname
        if domain_main.count(".") >= 2:
            domain_main = domain_main.split(".", 1)[-1]
        for brand in self._tranco:
            dist = _levenshtein(domain_main, brand)
            if 0 < dist <= 2:
                score += 35
                reasons.append(f"Typosquatting: {domain_main} looks like {brand} (distance {dist})")
                break

        # 5a. URL length
        if len(url) > 200:
            score += 10
            reasons.append(f"Excessive URL length ({len(url)} chars)")

        # 5b. @ symbol in URL
        if "@" in urlparse(url)._replace(scheme="").geturl():
            score += 15
            reasons.append("URL contains @ symbol (credential smuggling)")

        # 5c. Excessive subdomains
        subdomain_count = hostname.count(".")
        if subdomain_count > 5:
            score += 10
            reasons.append(f"Excessive subdomains ({subdomain_count} levels)")

        # 5d. Suspicious TLD
        for tld in SUSPICIOUS_TLDS:
            if hostname.endswith(tld):
                score += 20
                reasons.append(f"Suspicious TLD: {tld}")
                break

        score = min(100, max(0, score))

        if score <= Config.LOCAL_SCORE_SAFE:
            level = "safe"
        elif score <= Config.LOCAL_SCORE_LOW:
            level = "low"
        elif score <= Config.LOCAL_SCORE_MEDIUM:
            level = "medium"
        elif score <= Config.LOCAL_SCORE_HIGH:
            level = "high"
        else:
            level = "critical"

        if Config.LOCAL_OFFLINE_MODE and score > 0:
            logger.debug("Offline mode: capping score for %s", url)

        return LocalVerdict(
            url=url,
            score=score,
            level=level,
            reasons=reasons,
            engine_version=ENGINE_VERSION,
        )
