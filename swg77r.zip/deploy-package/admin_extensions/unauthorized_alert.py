import logging
import time

from pyrogram import Client

from config import Config

logger = logging.getLogger(__name__)

_THROTTLE: dict = {}


def _throttled(user_id: int, command: str) -> bool:
    key = f"{user_id}:{command}"
    now = time.time()
    last = _THROTTLE.get(key, 0)
    if now - last < 300:
        return True
    _THROTTLE[key] = now
    return False


async def send_unauthorized_alert(app: Client, user_id: int, user_name: str, command: str):
    if _throttled(user_id, command):
        return

    text = (
        f"🚨 <b>محاولة غير مصرح بها</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"👤 المستخدم: {user_name}\n"
        f"🆔 المعرف: <code>{user_id}</code>\n"
        f"📋 الأمر: /{command}\n"
        f"━━━━━━━━━━━━━━\n"
        f"🕐 {__import__('datetime').datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC"
    )

    for owner_id in Config.SUDO_USERS:
        try:
            await app.send_message(owner_id, text)
        except Exception as e:
            logger.error(f"Failed to alert owner {owner_id}: {e}")
