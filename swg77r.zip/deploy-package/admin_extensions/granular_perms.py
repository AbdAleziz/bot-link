import logging
from enum import IntEnum
from typing import List

from config import Config
from rbac import RBAC, Role

logger = logging.getLogger(__name__)


class Permission(IntEnum):
    BROADCAST = 1
    BAN = 2
    UNBAN = 3
    VIEW_STATS = 4
    CLEAR_CACHE = 5
    VIEW_LOGS = 6


_PERMISSION_MAP = {
    Permission.BROADCAST: {Role.OWNER, Role.SUB_DEV},
    Permission.BAN: {Role.OWNER, Role.SUB_DEV},
    Permission.UNBAN: {Role.OWNER, Role.SUB_DEV},
    Permission.VIEW_STATS: {Role.OWNER, Role.SUB_DEV},
    Permission.CLEAR_CACHE: {Role.OWNER, Role.SUB_DEV},
    Permission.VIEW_LOGS: {Role.OWNER, Role.SUB_DEV},
}


class Permissions:
    @staticmethod
    def has(user_id: int, permission: Permission) -> bool:
        role = RBAC.get_role(user_id)
        if role == Role.OWNER:
            return True
        allowed_roles = _PERMISSION_MAP.get(permission, set())
        return role in allowed_roles

    @staticmethod
    def get_user_permissions(user_id: int) -> List[Permission]:
        role = RBAC.get_role(user_id)
        if role == Role.OWNER:
            return list(Permission)
        result = []
        for perm, roles in _PERMISSION_MAP.items():
            if role in roles:
                result.append(perm)
        return result

    @staticmethod
    def require(permission: Permission):
        def decorator(func):
            async def wrapper(client, message, *args, **kwargs):
                uid = message.from_user.id
                if not Permissions.has(uid, permission):
                    await message.reply(
                        f"❌ ليس لديك صلاحية {permission.name.replace('_', ' ').title()}."
                    )
                    return
                return await func(client, message, *args, **kwargs)
            return wrapper
        return decorator
