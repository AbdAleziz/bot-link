import csv
import gzip
import io
import logging
from datetime import datetime

from pyrogram import Client, filters
from pyrogram.types import Message

from config import Config
from database import Database
from rbac import RBAC

logger = logging.getLogger(__name__)


async def register_csv_export(app: Client, db: Database):
    @app.on_message(filters.command("export_stats") & filters.private)
    async def export_stats_cmd(client: Client, message: Message):
        uid = message.from_user.id
        if not RBAC.is_owner(uid):
            await message.reply("❌ هذا الأمر خاص بالمالك فقط.")
            return

        sent = await message.reply("📦 جاري إنشاء التصدير...")
        try:
            buf = await _generate_export_archive(db)
            buf.name = f"stats_export_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv.gz"
            await client.send_document(uid, document=buf, caption="📊 تصدير إحصائيات")
            await sent.delete()
        except Exception as e:
            await sent.edit(f"❌ فشل التصدير: {e}")


async def run_scheduled_export(app: Client, db: Database):
    try:
        buf = await _generate_export_archive(db)
        target = Config.BACKUP_AUTO_SEND_TO
        if target:
            buf.name = f"weekly_export_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv.gz"
            await app.send_document(target, document=buf, caption="📊 التصدير الأسبوعي")
            logger.info(f"Weekly export sent to {target}")
    except Exception as e:
        logger.error(f"Scheduled export failed: {e}")


async def _generate_export_archive(db: Database) -> io.BytesIO:
    exports = {
        "users": await db.fetch("SELECT * FROM users"),
        "scan_history": await db.fetch("SELECT * FROM scan_history"),
        "vip_users": await db.fetch("SELECT * FROM vip_users"),
        "payments": await db.fetch("SELECT * FROM pending_payments"),
    }

    gz_buf = io.BytesIO()
    with gzip.GzipFile(fileobj=gz_buf, mode="w", mtime=0) as gz:
        for table_name, rows in exports.items():
            if not rows:
                continue
            line = f"=== {table_name} ===\n"
            gz.write(line.encode())

            fieldnames = list(rows[0].keys())
            csv_buf = io.StringIO()
            writer = csv.DictWriter(csv_buf, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                cleaned = {}
                for k, v in row.items():
                    if v is None:
                        cleaned[k] = ""
                    else:
                        cleaned[k] = str(v)
                writer.writerow(cleaned)
            gz.write(csv_buf.getvalue().encode())
            gz.write(b"\n")

    gz_buf.seek(0)
    return gz_buf
