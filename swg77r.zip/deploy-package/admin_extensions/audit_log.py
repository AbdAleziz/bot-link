import json
import logging
from datetime import datetime

from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from config import Config
from database import Database
from rbac import RBAC

logger = logging.getLogger(__name__)


async def register_audit_log(app: Client, db: Database):


    @app.on_message(filters.command("auditlog") & filters.private)
    @RBAC.owner_only
    async def auditlog_cmd(client: Client, message: Message):
        uid = message.from_user.id
        parts = message.text.split(maxsplit=2)

        filter_user = None
        if len(parts) >= 2:
            try:
                filter_user = int(parts[1])
            except ValueError:
                pass

        page = 0
        if len(parts) >= 3:
            try:
                page = max(0, int(parts[2]) - 1)
            except ValueError:
                pass

        await _show_audit_log(client, message, db, filter_user, page)


async def _show_audit_log(client, message, db, filter_user=None, page=0):
    page_size = 50
    offset = page * page_size

    if filter_user:
        rows = await db.fetch(
            "SELECT * FROM admin_audit_log WHERE user_id = ? ORDER BY ts DESC LIMIT ? OFFSET ?",
            (filter_user, page_size, offset),
        )
        total = await db.fetchval(
            "SELECT COUNT(*) FROM admin_audit_log WHERE user_id = ?", filter_user
        ) or 0
    else:
        rows = await db.fetch(
            "SELECT * FROM admin_audit_log ORDER BY ts DESC LIMIT ? OFFSET ?",
            (page_size, offset),
        )
        total = await db.fetchval("SELECT COUNT(*) FROM admin_audit_log") or 0

    if not rows:
        await message.reply("📋 لا توجد إدخالات في سجل التدقيق.")
        return

    total_pages = max(1, (total + page_size - 1) // page_size)
    text = f"📋 <b>سجل التدقيق</b> (الصفحة {page + 1}/{total_pages})\n━━━━━━━━━━━━━━\n"

    for r in rows:
        uid = r.get("user_id", "?")
        cmd = r.get("command", "?")
        ts = str(r.get("ts", ""))[:19]
        result = r.get("result", "")
        icon = "✅" if result == "success" else "❌"
        text += f"{icon} <code>{uid}</code> → /{cmd}\n  🕐 {ts}\n"

    text += "━━━━━━━━━━━━━━"

    kb_buttons = []
    nav_row = []
    if page > 0:
        nav_row.append(InlineKeyboardButton("⬅️", callback_data=f"auditlog_page_{filter_user or 0}_{page - 1}"))
    nav_row.append(InlineKeyboardButton(f"{page + 1}/{total_pages}", callback_data="auditlog_info"))
    if offset + page_size < total:
        nav_row.append(InlineKeyboardButton("➡️", callback_data=f"auditlog_page_{filter_user or 0}_{page + 1}"))
    if nav_row:
        kb_buttons.append(nav_row)
    kb_buttons.append([InlineKeyboardButton("🔙 Back", callback_data="adm_back")])

    await message.reply(text, reply_markup=InlineKeyboardMarkup(kb_buttons))


async def log_admin_action(db: Database, user_id: int, command: str, args: dict = None, ip: str = None, result: str = "success"):
    try:
        await db.execute(
            "INSERT INTO admin_audit_log (ts, user_id, command, args_json, ip, result) VALUES (?, ?, ?, ?, ?, ?)",
            (datetime.utcnow().isoformat(), user_id, command, json.dumps(args) if args else None, ip, result),
        )
    except Exception as e:
        logger.error(f"Failed to log admin action: {e}")
