# Running scanner_bot

## Quick Start

```bash
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your Telegram API credentials
python main.py
```

## Environment Variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `BOT_TOKEN` | Yes | — | Telegram Bot Token |
| `API_ID` | Yes | — | Telegram API ID |
| `API_HASH` | Yes | — | Telegram API Hash |
| `PRIMARY_ADMIN_ID` | Yes | — | Admin user ID |
| `SUDO_USERS` | No | — | Comma-separated sudo user IDs |
| `LOCAL_ONLY_MODE` | No | `true` | Run without external APIs |
| `DATABASE_URL` | No | `sqlite+aiosqlite:///data/bot.db` | Database connection string |
| `LOG_LEVEL` | No | `INFO` | Logging level |

## v3 Upgrade Features

- **Local-first scoring** — 11 signal analysis, always works without VirusTotal/URLScan
- **Multi-language** — Arabic + English with auto-detect
- **Batch scanning** — `/batchscan` command for bulk URL analysis
- **VIP system** — trial guard, pricing admin, PDF invoices, expiry reminders
- **Admin tools** — audit log, granular permissions, CSV export, unauthorised alerts
- **Security** — self-scan, SSL inspection, blacklist mirror, typosquatting detection, redirect chain walker, extension guard
- **Operations** — circuit breaker, semaphore pool, watchdog, graceful restart, degradation management, health check, archive

## Running Tests

```bash
pytest tests/ -v
```
