# Changelog

## v3

### Features
- **Local scoring engine** — 11-signal URL risk analysis (IP check, HTTPS, TLD, typosquatting, homoglyph, path depth, entropy, length, special chars, digits, repetition) with zero external API dependency
- **i18n system** — Arabic + English translations, `/language` command, auto-detect from code
- **Batch scanner** — `/batchscan` command with progress tracking, CSV/PDF reports
- **WHOIS engine** — cached domain registration lookup with risk scoring
- **Community voting** — upvote/downvote on scanned URLs
- **VIP system** — IP-bound free trial, editable pricing panel, PDF invoices, 3-day expiry reminders
- **Admin extensions** — audit log (`/auditlog`), granular permissions, CSV export (`/export_stats`), unauthorized access alerts
- **Security modules** — AST-based self-scan, SSL certificate inspection, PhishTank/OpenPhish blacklist mirror, Levenshtein typosquatting detection, 20-hop redirect chain walker, dangerous extension guard
- **Operations** — per-service circuit breaker, bounded semaphore pool, handler watchdog (10s timeout), graceful restart API, degradation state machine, health check endpoint, monthly archive job
- **Landing page** — click tracker with UTM parameter capture
- **UX** — `/language` and `/whoami` commands

### Configuration
- 20+ new environment variables for v3 features

### Database
- 9 new tables: `user_language`, `admin_audit_log`, `trial_attempts`, `vip_pricing`, `whois_cache`, `community_votes`, `vip_reminders`, `typosquat_watch`, `scan_cache`
