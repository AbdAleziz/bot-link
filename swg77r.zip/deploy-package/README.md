# scanner_bot — Advanced QR & Link Scanner Bot

A professional Telegram bot integrating URL scanning (VirusTotal, urlscan.io),
advanced QR code generation/decoding, RBAC admin panel, Redis-backed task queue,
rate limiting, and VIP subscription system — all optimized for 4GB RAM servers.

## ✨ Features

### 🔍 Link Scanner
- VirusTotal API integration for URL threat analysis
- SSL certificate validation
- WHOIS domain age/risk assessment
- URL redirect chain analysis
- Local blacklist/whitelist
- Scan history & caching

### 📱 QR Code System (Advanced)
- **Generate** colored, dynamic QR codes with optional logo overlay
- **Decode** QR images → extract URL → auto-scan via VirusTotal
- **Dual-Way**: send QR image → bot decodes + scans + returns result
- **URL Shortener**: long URLs automatically shortened before QR generation
- **vCard QR**: step-by-step wizard to create contact QR codes
- **Analytics**: track scans/clicks per QR code

### 🛡️ Security & Performance (4GB RAM Optimized)
- **Redis Queue**: async task queue for background processing
- **Rate Limiting**: per-user rate limits with automatic temp bans
- **Memory-efficient**: SQLite WAL mode, LRU cache, rotating logs
- **Anti-flood**: message frequency detection

### 👑 RBAC (Role-Based Access Control)
- **Owner**: full control, server management, manage sub-developers
- **Sub-Developer**: limited admin dashboard (stats, broadcast, ban/unban, logs, clear cache)
- **User**: standard bot features

### 🖥️ UI/UX
- Full Inline Keyboard navigation — no text commands needed
- Step-by-step wizards for QR customization and vCard creation
- Inline Mode: `@bot <url>` to generate QR in any chat
- Interactive admin panel with role-appropriate buttons

### 🧪 Staging Environment
- Run a separate test bot alongside production
- Sub-developers can test features before release
- Controlled by `STAGING_ENABLED` and `STAGING_BOT_TOKEN` env vars

## 🚀 Quick Start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your credentials
python main.py
```

## 🐳 Docker

```bash
docker build -t scanner-bot .
docker run -d --env-file .env scanner-bot
```

## ⚙️ Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `BOT_TOKEN` | Telegram Bot Token | — |
| `API_ID` | Telegram API ID | — |
| `API_HASH` | Telegram API Hash | — |
| `PRIMARY_ADMIN_ID` | Owner user ID | — |
| `SUDO_USERS` | Comma-separated owner IDs | — |
| `SUB_DEVS` | Comma-separated sub-developer IDs | — |
| `VIRUSTOTAL_API_KEY` | VirusTotal API key | — |
| `REDIS_URL` | Redis URL (optional) | — |
| `STAGING_ENABLED` | Enable staging bot | `false` |
| `STAGING_BOT_TOKEN` | Staging bot token | — |
| `RATE_LIMIT_MESSAGES` | Max messages per window | `10` |
| `RATE_LIMIT_WINDOW` | Window in seconds | `60` |
| `RATE_LIMIT_BAN_DURATION` | Ban duration in seconds | `3600` |
| `QUEUE_WORKERS` | Async queue workers | `4` |
| `LOG_JSON` | JSON log format | `false` |
| `ALERT_LOG_CHANNEL` | Telegram chat for error alerts | `0` |

## 📁 Project Structure

```
├── main.py              # Entry point + all handlers
├── config/__init__.py   # Configuration class
├── config/payment_config.py  # Payment settings
├── database.py          # Database layer (SQLite/Postgres/Turso)
├── scanner.py           # URL scanning (VirusTotal, etc.)
├── qr_system.py         # QR generation/decoding/vCard
├── rbac.py              # Role-based access control
├── admin_panel.py       # Admin dashboard (Owner + Sub-Dev)
├── rate_limiter.py      # Anti-flood rate limiting
├── queue_system.py      # Redis/in-memory task queue
├── logging_setup.py     # JSON/rotating logging + alerts
├── click_tracker.py     # URL shortener + click analytics
├── vip_system.py        # VIP subscription management
├── services/            # Payment flows (Telegram Stars & Iraqi manual)
├── web_dashboard.py     # Web admin dashboard
├── mcp_server.py        # MCP protocol server
└── Dockerfile
```

## 👑 Admin Panel

Send `/panel` in private chat with the bot to open the admin panel.
- **Owner**: full access to all tools
- **Sub-Developer**: stats, broadcast, ban/unban, clear cache, logs
