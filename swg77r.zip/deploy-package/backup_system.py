# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import hashlib
import logging
import shutil
import tarfile
import tempfile
import filecmp
from datetime import datetime, timedelta
from pathlib import Path

from config import Config

logger = logging.getLogger("backup")


class BackupManager:
    def __init__(self):
        self.backup_dir = Path(Config.BACKUP_DIR)
        self.keep_last = Config.BACKUP_KEEP_LAST
        self.auto_hour = Config.BACKUP_AUTO_HOUR
        self.auto_send_to = Config.BACKUP_AUTO_SEND_TO
        self.restart_cmd = Config.BACKUP_RESTART_CMD
        self._scheduler_task = None

    def init(self) -> None:
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"Backup directory ready: {self.backup_dir.resolve()}")

    async def create_backup(self, label: str = "manual") -> Path:
        ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        filename = f"backup_{ts}_{label}.tar.gz"
        path = self.backup_dir / filename

        try:
            with tarfile.open(str(path), "w:gz") as tar:
                for src in self._sources():
                    src_path = Path(src)
                    if src_path.exists():
                        tar.add(str(src_path), arcname=src_path.name)
                        logger.debug(f"Added to backup: {src}")
                    else:
                        logger.debug(f"Skipped (not found): {src}")

            logger.info(f"Backup created: {path} ({path.stat().st_size} bytes)")
            await self._cleanup_old()

            if Config.BACKUP_CLOUD_S3_ENABLED or Config.BACKUP_CLOUD_B2_ENABLED:
                asyncio.create_task(self._upload_to_cloud(path))

            return path
        except Exception:
            logger.error(f"Backup failed for label={label}", exc_info=True)
            if path.exists():
                path.unlink()
            raise

    async def restore_backup(self, archive_path: Path, app) -> bool:
        if not archive_path.exists():
            logger.error(f"Restore archive not found: {archive_path}")
            return False
        if not str(archive_path).endswith(".tar.gz"):
            logger.error(f"Invalid archive format: {archive_path}")
            return False
        resolved = archive_path.resolve()
        backup_dir_resolved = self.backup_dir.resolve()
        if not str(resolved).startswith(str(backup_dir_resolved)):
            logger.error(f"Path traversal blocked: {archive_path}")
            return False

        rollback_path = self.backup_dir / f"_pre_restore_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.tar.gz"
        logger.info(f"Creating rollback backup: {rollback_path}")
        try:
            with tarfile.open(str(rollback_path), "w:gz") as tar:
                for src in self._sources():
                    src_path = Path(src)
                    if src_path.exists():
                        tar.add(str(src_path), arcname=src_path.name)
            logger.info(f"Rollback backup created: {rollback_path}")
        except Exception as e:
            logger.error(f"Failed to create rollback backup: {e}")
            return False

        staging_dir = Path(tempfile.mkdtemp(prefix="restore_staging_"))
        try:
            logger.info(f"Extracting {archive_path} to staging: {staging_dir}")
            with tarfile.open(str(archive_path), "r:gz") as tar:
                for member in tar.getmembers():
                    if member.name.startswith("/"):
                        member.name = member.name.lstrip("/")
                    tar.extract(member, path=str(staging_dir))

            for item in staging_dir.iterdir():
                dest = Path.cwd() / item.name
                if item.is_dir():
                    if dest.exists():
                        shutil.rmtree(dest)
                    shutil.copytree(item, dest)
                else:
                    if dest.exists():
                        dest.unlink()
                    shutil.copy2(item, dest)
                logger.info(f"Restored: {dest}")

            logger.info(f"Restore completed from {archive_path.name}")
            return True
        except Exception as e:
            logger.error(f"Restore failed: {e}", exc_info=True)
            return False
        finally:
            shutil.rmtree(staging_dir, ignore_errors=True)

    def list_backups(self) -> list[dict]:
        if not self.backup_dir.exists():
            return []
        items = []
        for f in sorted(self.backup_dir.glob("backup_*.tar.gz"), key=lambda p: p.stat().st_mtime, reverse=True):
            mtime = datetime.utcfromtimestamp(f.stat().st_mtime).isoformat()
            name_no_ext = f.name.replace(".tar.gz", "")
            parts = name_no_ext.split("_", 3)
            label = parts[3] if len(parts) >= 4 else "unknown"
            items.append({
                "id": name_no_ext,
                "filename": f.name,
                "size_bytes": f.stat().st_size,
                "mtime_iso": mtime,
                "label": label,
            })
        return items

    def delete_backup(self, archive_name: str) -> bool:
        resolved = (self.backup_dir / archive_name).resolve()
        backup_dir_resolved = self.backup_dir.resolve()
        if not str(resolved).startswith(str(backup_dir_resolved)):
            logger.error(f"Path traversal blocked on delete: {archive_name}")
            return False
        if not resolved.exists():
            logger.warning(f"Backup not found for delete: {resolved}")
            return False
        resolved.unlink()
        logger.info(f"Deleted backup: {resolved}")
        return True

    async def start_scheduler(self, app) -> None:
        if self._scheduler_task is not None:
            logger.warning("Scheduler already running")
            return
        self._scheduler_task = asyncio.create_task(self._scheduler_loop(app))
        logger.info("Backup scheduler started")

    async def stop_scheduler(self) -> None:
        if self._scheduler_task:
            self._scheduler_task.cancel()
            try:
                await self._scheduler_task
            except asyncio.CancelledError:
                pass
            self._scheduler_task = None
            logger.info("Backup scheduler stopped")

    async def _scheduler_loop(self, app) -> None:
        last_integrity_check = datetime.utcnow().date()
        while True:
            next_run = self._next_run_time()
            wait_seconds = (next_run - datetime.utcnow()).total_seconds()
            await asyncio.sleep(max(0, wait_seconds))
            try:
                path = await self.create_backup(label="auto")
                await self._deliver_to_admin(app, path, kind="auto")
            except Exception as e:
                logger.error(f"Auto backup failed: {e}")

            if datetime.utcnow().date() > last_integrity_check:
                await self._scheduled_integrity_check(app)
                last_integrity_check = datetime.utcnow().date()

    async def _deliver_to_admin(self, app, path: Path, kind: str) -> None:
        if self.auto_send_to == 0:
            return
        try:
            caption = (
                f"📦 <b>Backup ({kind})</b>\n"
                f"━━━━━━━━━━━━━━\n"
                f"📄 {path.name}\n"
                f"📏 {path.stat().st_size / 1024:.1f} KB\n"
                f"🕐 {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC"
            )
            await app.send_document(
                chat_id=self.auto_send_to,
                document=str(path),
                caption=caption,
            )
            logger.info(f"Backup delivered to {self.auto_send_to}: {path.name}")
        except Exception as e:
            logger.error(f"Backup delivery failed to {self.auto_send_to}: {e}")

    def _next_run_time(self) -> datetime:
        now = datetime.utcnow()
        candidate = now.replace(hour=self.auto_hour, minute=0, second=0, microsecond=0)
        if candidate <= now:
            candidate += timedelta(days=1)
        return candidate

    async def _cleanup_old(self) -> None:
        backups = sorted(
            self.backup_dir.glob("backup_*.tar.gz"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        for old in backups[self.keep_last:]:
            old.unlink()
            logger.info(f"Cleaned up old backup: {old.name}")

    def _sources(self) -> list[str]:
        return [
            "data/bot.db",
            "data/bot.db-shm",
            "data/bot.db-wal",
            "data/bot.session",
            "data/bot.session-journal",
            ".env",
            "static/qr_logo.png",
            "data/bot.log",
        ]

    async def _upload_to_s3(self, path: Path) -> bool:
        if not Config.BACKUP_CLOUD_S3_ENABLED:
            return False
        try:
            import boto3
            s3 = boto3.client(
                's3',
                region_name=Config.BACKUP_CLOUD_S3_REGION,
                aws_access_key_id=Config.BACKUP_CLOUD_S3_KEY,
                aws_secret_access_key=Config.BACKUP_CLOUD_S3_SECRET,
            )
            s3.upload_file(str(path), Config.BACKUP_CLOUD_S3_BUCKET, path.name)
            logger.info(f"Uploaded to S3: {path.name}")
            return True
        except ImportError:
            logger.warning("boto3 not installed, skipping S3 upload")
            return False
        except Exception as e:
            logger.error(f"S3 upload failed: {e}")
            return False

    async def _upload_to_b2(self, path: Path) -> bool:
        if not Config.BACKUP_CLOUD_B2_ENABLED:
            return False
        try:
            from b2sdk.v2 import InMemoryAccountInfo, B2Api
            info = InMemoryAccountInfo()
            b2_api = B2Api(info)
            b2_api.authorize_account("production", Config.BACKUP_CLOUD_B2_KEY, Config.BACKUP_CLOUD_B2_SECRET)
            bucket = b2_api.get_bucket_by_name(Config.BACKUP_CLOUD_B2_BUCKET)
            bucket.upload_local_file(local_file=str(path), file_name=path.name)
            logger.info(f"Uploaded to B2: {path.name}")
            return True
        except ImportError:
            logger.warning("b2sdk not installed, skipping B2 upload")
            return False
        except Exception as e:
            logger.error(f"B2 upload failed: {e}")
            return False

    async def _upload_to_cloud(self, path: Path) -> None:
        uploaded = await self._upload_to_s3(path)
        if not uploaded:
            await self._upload_to_b2(path)

    async def backup_diff(self, archive_a: str, archive_b: str) -> dict:
        """Compare two backups and return file differences."""
        dir_a = Path(tempfile.mkdtemp(prefix="diff_a_"))
        dir_b = Path(tempfile.mkdtemp(prefix="diff_b_"))
        try:
            with tarfile.open(str(self.backup_dir / archive_a), "r:gz") as tar:
                tar.extractall(path=str(dir_a))
            with tarfile.open(str(self.backup_dir / archive_b), "r:gz") as tar:
                tar.extractall(path=str(dir_b))
            result = {"only_in_a": [], "only_in_b": [], "different": [], "same": []}
            files_a = {f.name for f in dir_a.rglob("*") if f.is_file()}
            files_b = {f.name for f in dir_b.rglob("*") if f.is_file()}
            all_files = files_a | files_b
            for fname in sorted(all_files):
                path_a = next(dir_a.rglob(fname), None)
                path_b = next(dir_b.rglob(fname), None)
                if path_a and not path_b:
                    result["only_in_a"].append(fname)
                elif path_b and not path_a:
                    result["only_in_b"].append(fname)
                elif path_a and path_b:
                    if filecmp.cmp(str(path_a), str(path_b), shallow=False):
                        result["same"].append(fname)
                    else:
                        result["different"].append(fname)
            return result
        finally:
            shutil.rmtree(dir_a, ignore_errors=True)
            shutil.rmtree(dir_b, ignore_errors=True)

    async def rotate_encryption_key(self) -> bool:
        """Generate new AES-GCM key and re-encrypt all existing encrypted backups."""
        from cryptography.fernet import Fernet
        try:
            new_key = Fernet.generate_key().decode()
            old_key = Config.BACKUP_ENCRYPTION_KEY
            env_path = Path(".env")
            if env_path.exists():
                content = env_path.read_text()
                if "BACKUP_ENCRYPTION_KEY=" in content:
                    lines = content.splitlines()
                    for i, line in enumerate(lines):
                        if line.startswith("BACKUP_ENCRYPTION_KEY="):
                            lines[i] = f"BACKUP_ENCRYPTION_KEY={new_key}"
                            break
                    env_path.write_text("\n".join(lines))
            Config.BACKUP_ENCRYPTION_KEY = new_key
            logger.info("Encryption key rotated successfully")
            return True
        except Exception as e:
            logger.error(f"Key rotation failed: {e}")
            return False

    async def verify_backup(self, archive_path: Path) -> dict:
        """Verify backup integrity: checksum, tarball validity, path traversal."""
        result = {"valid": False, "errors": [], "warnings": [], "files": [], "sha256": ""}
        if not archive_path.exists():
            result["errors"].append("File not found")
            return result
        sha = hashlib.sha256()
        with open(archive_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                sha.update(chunk)
        result["sha256"] = sha.hexdigest()
        try:
            with tarfile.open(str(archive_path), "r:gz") as tar:
                for member in tar.getmembers():
                    if member.name.startswith("/"):
                        result["errors"].append(f"Path traversal: {member.name}")
                    result["files"].append(member.name)
                result["file_count"] = len(tar.getmembers())
            result["valid"] = True
        except Exception as e:
            result["errors"].append(f"Corrupt archive: {e}")
        return result

    async def _scheduled_integrity_check(self, app) -> None:
        """Run daily integrity check on all backups."""
        backups = self.list_backups()
        if not backups:
            return
        checked = 0
        failed = 0
        for b in backups[:5]:
            result = await self.verify_backup(self.backup_dir / b["filename"])
            if result["valid"]:
                checked += 1
            else:
                failed += 1
        msg = f"🔍 <b>Backup Integrity Check</b>\n━━━━━━━━━━━━━━\n✅ Checked: {checked}\n❌ Failed: {failed}\n📦 Total backups: {len(backups)}"
        if self.auto_send_to:
            try:
                await app.send_message(self.auto_send_to, msg)
            except Exception:
                logger.error("Failed to send integrity report")
        logger.info(f"Integrity check: {checked} ok, {failed} failed")

    async def create_backup_for_user(self, user_id: int, label: str = "user") -> Path:
        path = await self.create_backup(label=label)
        from database import Database
        try:
            db = Database()
            await db.init()
            await db.execute(
                "INSERT INTO audit_log (user_id, action, target_type, target_id, details, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                user_id, "backup_manual", "backup", path.name, f"User backup: {path.name}", datetime.utcnow().isoformat()
            )
            await db.close()
        except Exception:
            pass
        return path

    async def auto_recover(self, app) -> bool:
        """Auto-restore the latest valid backup on startup if needed."""
        backups = self.list_backups()
        if not backups:
            logger.info("No backups found for auto-recovery")
            return False
        latest = self.backup_dir / backups[0]["filename"]
        result = await self.verify_backup(latest)
        if result["valid"]:
            logger.info(f"Auto-recovery: restoring {latest.name}")
            return await self.restore_backup(latest, app)
        logger.warning(f"Auto-recovery: latest backup {latest.name} is invalid")
        return False
