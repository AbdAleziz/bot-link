# 🚀 دليل النشر على السيرفر — scanner_bot

هالدليل يعلمك شلون تنشر البوت على سيرفر خاصك (VPS) خطوة بخطوة.

---

## شنو تحتاج قبل ما تبدأ؟

1. **سيرفر VPS** (Ubuntu 22.04 أو Debian 12) — حتى لو 1GB RAM يكفي
2. **IP السيرفر** (مثال: `185.123.45.67`)
3. **Domain (اختياري)** — لو تريد رابط حلو بدال IP
4. **مفاتيح تليغرام**:
   - `BOT_TOKEN` من [@BotFather](https://t.me/BotFather)
   - `API_ID` و `API_HASH` من [my.telegram.org](https://my.telegram.org)

---

## الطريقة 1: Docker (الأسهل ✅)

### خطوة 1: ارفع الحزمة على السيرفر

من جهازك، اربط بسيرفرك وارفع الملفات:

```bash
# من جهازك المحلي:
scp -r deploy-package root@YOUR_SERVER_IP:/root/scanner-bot

# لو ما عندك scp، استخدم FileZilla أو WinSCP
```

### خطوة 2: ادخل السيرفر وجهّز

```bash
ssh root@YOUR_SERVER_IP
cd /root/scanner-bot
```

### خطوة 3: عدّل المفاتيح

```bash
nano .env
```

غيّر هالقيم على الأقل:
- `BOT_TOKEN` — توكن البوت من @BotFather
- `API_ID` و `API_HASH` — من my.telegram.org
- `PRIMARY_ADMIN_ID` — الـ user id مالاك بتليغرام (جيبه من @userinfobot)
- `DASHBOARD_PASS` — كلمة سر قوية للوحة التحكم
- `WEB_URL=http://YOUR_SERVER_IP:8080` — حط IP مالاك

احفظ: `Ctrl+O` → `Enter` → `Ctrl+X`

### خطوة 4: شغّل

```bash
bash deploy.sh
```

سكربت `deploy.sh` يسوي:
- ينصّب Docker لو ما موجود
- يبني الصورة
- يشغّل البوت بالخلفية
- يعرضلك الرابط

### خطوة 5: تأكد إنه شغّال

```bash
# شوف اللوقات (logs)
docker compose logs -f

# جرب اللوحة
curl http://YOUR_SERVER_IP:8080/health
```

لو كلشي تمام، افتح بالمتصفح:

```
http://YOUR_SERVER_IP:8080
```

هذا **رابط لوحة التحكم** مالاك — هنا ترفع الملفات (`/api/files/upload`) وتشوف الإحصائيات.

---

## الطريقة 2: بدون Docker (لو تبي تشغّله مباشرة بـ Python)

```bash
ssh root@YOUR_SERVER_IP
cd /root/scanner-bot

# 1. نصّب Python 3.11 والاعتماديات
apt update && apt install -y python3.11 python3.11-venv libzbar0 fonts-dejavu
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# 2. عدّل المفاتيح
nano .env

# 3. شغّل (شغّال بالخلفية بـ systemd)
```

### تشغيل دائم بـ systemd:

```bash
cat > /etc/systemd/system/scanner-bot.service <<'EOF'
[Unit]
Description=scanner_bot Telegram
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/scanner-bot
EnvironmentFile=/root/scanner-bot/.env
ExecStart=/root/scanner-bot/.venv/bin/python main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now scanner-bot
systemctl status scanner-bot
```

---

## 🔒 إضافة HTTPS (مهم لو تبي تستخدمه فعلياً)

### بـ Caddy (الأسهل — يجيب شهادة أوتوماتيك):

```bash
apt install -y caddy

cat > /etc/caddy/Caddyfile <<'EOF'
your-domain.com {
    reverse_proxy localhost:8080
}
EOF

systemctl restart caddy
```

الحين `https://your-domain.com` راح يفتح لوحة التحكم بشهادة SSL.

### بـ nginx (لو تفضل):

```bash
apt install -y nginx certbot python3-certbot-nginx
```

أضف بملف `/etc/nginx/sites-available/scanner`:
```
server {
    listen 80;
    server_name your-domain.com;

    client_max_body_size 100M;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

```bash
ln -s /etc/nginx/sites-available/scanner /etc/nginx/sites-enabled/
systemctl reload nginx
certbot --nginx -d your-domain.com
```

---

## 📁 وين تروح الملفات اللي ترفعها؟

البوت يخدم endpoints مهمة على `http://YOUR_IP:8080`:

| Endpoint | الوظيفة |
|---|---|
| `GET  /` | لوحة التحكم (index) |
| `GET  /health` | فحص الصحة |
| `POST /api/files/upload` | **رفع ملف** |
| `GET  /api/files` | قائمة الملفات |
| `DELETE /api/files/{filename}` | حذف ملف |
| `POST /api/scan` | فحص URL |
| `GET  /api/stats` | إحصائيات |
| `GET  /api/docs` | توثيق API |

الملفات تنحفظ بمجلد `uploads/` على السيرفر (mounted كـ volume فـ Docker).

---

## 🛠️ أوامر مفيدة

```bash
# شوف اللوقات لايف
docker compose logs -f

# ريستارت
docker compose restart

# تحديث الكود (لو عدّلت شي)
docker compose up -d --build

# إيقاف
docker compose down

# دخول للـ container
docker exec -it scanner-bot bash

# نسخ احتياطي للداتا
cp -r data/ backups/data-$(date +%F)
```

---

## 🆘 مشاكل شائعة

| المشكلة | الحل |
|---|---|
| `Address already in use` | غيّر `WEB_PORT` بـ `.env` |
| `BOT_TOKEN is invalid` | جيب توكن جديد من @BotFather |
| `Database is locked` | أوقف البوت: `docker compose down` ثم شغّله |
| لوحة التحكم ما تفتح | تأكد الـ firewall: `ufw allow 8080/tcp` |
| ما يصير login بالداشبورد | تأكد `DASHBOARD_USER` و `DASHBOARD_PASS` بملف `.env` |

---

## ✅ بعد النشر

1. ادخل تليغرام، ابعت للبوت `/start` — لازم يرد
2. افتح `http://YOUR_IP:8080` بالمتصفح — لازم تشوف لوحة التحكم
3. ارفع ملف من `POST /api/files/upload` (مثلاً بـ curl):

```bash
curl -u admin:YOUR_DASHBOARD_PASS \
  -F "file=@/path/to/root.txt" \
  http://YOUR_IP:8080/api/files/upload
```

وإذا تريد تشوف الملف بأمر:
```bash
curl -u admin:YOUR_DASHBOARD_PASS http://YOUR_IP:8080/api/files
```

---

**مبروك! 🎉** البوت شغّال على سيرفرك ولوحة التحكم جاهزة.
