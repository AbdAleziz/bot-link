#!/usr/bin/env python3
# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

"""Lightweight startup checks for justrunmy.app deployment.

This script used to call ``pip install`` for missing packages, which could
break the boot if the platform's network is restricted or any package fails
to build. The platform already installs ``requirements.txt`` for us, so this
script now only:
  1. Ensures the persistent data/upload directories exist.
  2. Honors the ``PORT`` env var (the platform exposes a single public port).
  3. Warns about missing critical env vars / importable modules.
"""
import os
from pathlib import Path


REQUIRED_ENV = ["BOT_TOKEN", "API_ID", "API_HASH", "SUDO_USERS"]
REQUIRED_IMPORTS = [
    "pyrogram", "aiohttp", "aiosqlite", "jinja2", "aiohttp_jinja2",
    "httpx", "whois", "cryptography", "yaml", "humanize",
]


def check_imports():
    missing = []
    for lib in REQUIRED_IMPORTS:
        try:
            __import__(lib.replace("-", "_"))
        except ImportError:
            missing.append(lib)
    return missing


def main():
    print("🔧 Running deployment checks...")

    # 1. Persistent directories (volume mount point on the platform)
    Path("data").mkdir(parents=True, exist_ok=True)
    Path("uploads").mkdir(parents=True, exist_ok=True)
    print("✅ data/ and uploads/ ready")

    # 2. Env vars
    missing_env = [v for v in REQUIRED_ENV if not os.getenv(v)]
    if missing_env:
        print(f"⚠️  Missing env vars: {', '.join(missing_env)}")
        print("    Set them in the justrunmy.app dashboard before starting the app.")
    else:
        print("✅ Required env vars are set")

    # 3. Imports (warn only — the platform installs requirements.txt)
    missing_pkgs = check_imports()
    if missing_pkgs:
        print(f"⚠️  Missing packages: {', '.join(missing_pkgs)}")
        print("    Check that requirements.txt is being installed by the platform.")
    else:
        print("✅ All required packages importable")

    # 4. Honor PORT env var
    port = os.getenv("PORT")
    if port:
        os.environ["WEB_PORT"] = port
        print(f"✅ Using PORT={port} from environment (dashboard will bind to it)")

    print("\n✅ Startup checks complete. Handing off to main.py")


if __name__ == "__main__":
    main()
