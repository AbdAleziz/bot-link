# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

"""إعدادات الدفع اليدوي — كل الأرقام الحساسة من env vars."""
import os


PAYMENT_CONTACTS = {
    "mastercard": os.getenv("RECEIVE_MASTERCARD", ""),
    "zain_cash":  os.getenv("RECEIVE_ZAIN_CASH", ""),
    "fib":        os.getenv("RECEIVE_FIB", ""),
    "qicard":     os.getenv("RECEIVE_QICARD", ""),
}

PAYMENT_ACCOUNT_HOLDER = os.getenv("PAYMENT_ACCOUNT_HOLDER", "يرجى التحديث")
PAYMENT_INSTRUCTIONS = os.getenv("PAYMENT_INSTRUCTIONS", "")

PRICING = {
    "month":    {"iqd": int(os.getenv("PRICE_MONTH_IQD", "5000")),    "days": 30},
    "quarter":  {"iqd": int(os.getenv("PRICE_QUARTER_IQD", "12000")), "days": 90},
    "year":     {"iqd": int(os.getenv("PRICE_YEAR_IQD", "40000")),    "days": 365},
    "lifetime": {"iqd": int(os.getenv("PRICE_LIFETIME_IQD", "150000")),"days": 36500},
}

PRICING_DISPLAY = {
    "month":    {"label": "📅 30 يوم",          "price": PRICING["month"]["iqd"]},
    "quarter":  {"label": "📅 3 أشهر",          "price": PRICING["quarter"]["iqd"]},
    "year":     {"label": "📅 سنة",             "price": PRICING["year"]["iqd"]},
    "lifetime": {"label": "♾️ مدى الحياة",     "price": PRICING["lifetime"]["iqd"]},
}

REQUEST_EXPIRY_HOURS = int(os.getenv("REQUEST_EXPIRY_HOURS", "24"))
ENABLE_STARS_PAYMENT = os.getenv("ENABLE_STARS_PAYMENT", "false").lower() == "true"
