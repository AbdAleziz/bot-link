import logging
import secrets
import string
from datetime import datetime, timedelta

from config import Config
from database import Database
from vip_system import VipSystem

logger = logging.getLogger("invite_system")


class InviteSystem:
    def __init__(self, db: Database, vip: VipSystem):
        self.db = db
        self.vip = vip
        self._bot_username = "scanner_bot"

    def set_bot_username(self, username: str):
        self._bot_username = username

    async def _get_bot_username(self) -> str:
        return self._bot_username

    async def ensure_tables(self):
        await self.db.execute("""
            CREATE TABLE IF NOT EXISTS invite_links (
                code TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                uses INTEGER DEFAULT 0,
                max_uses INTEGER DEFAULT 50,
                is_active INTEGER DEFAULT 1
            )
        """)
        await self.db.execute("""
            CREATE TABLE IF NOT EXISTS invite_redemptions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invite_code TEXT NOT NULL,
                joiner_id INTEGER NOT NULL,
                joined_at TEXT NOT NULL,
                reward_given INTEGER DEFAULT 0,
                is_suspicious INTEGER DEFAULT 0,
                FOREIGN KEY (invite_code) REFERENCES invite_links(code)
            )
        """)
        await self.db.execute("""
            CREATE TABLE IF NOT EXISTS invite_warnings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                warning_reason TEXT,
                warned_at TEXT NOT NULL
            )
        """)

    async def generate_invite(self, user_id: int) -> dict:
        code = "".join(secrets.choice(string.ascii_letters + string.digits) for _ in range(10))
        exists = await self.db.fetchrow("SELECT code FROM invite_links WHERE code = ?", (code,))
        while exists:
            code = "".join(secrets.choice(string.ascii_letters + string.digits) for _ in range(10))
            exists = await self.db.fetchrow("SELECT code FROM invite_links WHERE code = ?", (code,))
        await self.db.execute(
            "INSERT INTO invite_links (code, user_id, created_at, uses, max_uses, is_active) VALUES (?, ?, ?, 0, 50, 1)",
            (code, user_id, datetime.utcnow().isoformat()),
        )
        bot_username = await self._get_bot_username()
        link = f"https://t.me/{bot_username}?start=invite_{code}"
        return {"code": code, "link": link}

    async def process_invite(self, joiner_id: int, code: str, joiner_data: dict = None, client=None) -> dict:
        invite = await self.db.fetchrow(
            "SELECT * FROM invite_links WHERE code = ? AND is_active = 1", (code,)
        )
        if not invite:
            return {"success": False, "reason": "رابط دعوة غير صالح أو منتهي الصلاحية"}

        creator_id = invite["user_id"]

        if creator_id == joiner_id:
            return {"success": False, "reason": "لا يمكنك استخدام رابط الدعوة الخاص بك"}

        existing = await self.db.fetchrow(
            "SELECT id FROM invite_redemptions WHERE invite_code = ? AND joiner_id = ?",
            (code, joiner_id),
        )
        if existing:
            return {"success": False, "reason": "لقد استخدمت هذا الرابط من قبل"}

        is_suspicious = await self._anti_reshq_check(joiner_id, joiner_data, client)

        await self.db.execute(
            "INSERT INTO invite_redemptions (invite_code, joiner_id, joined_at, reward_given, is_suspicious) VALUES (?, ?, ?, ?, ?)",
            (code, joiner_id, datetime.utcnow().isoformat(), 0, 1 if is_suspicious else 0),
        )

        await self.db.execute(
            "UPDATE invite_links SET uses = uses + 1 WHERE code = ?", (code,)
        )

        if is_suspicious:
            await self._warn_user(creator_id, "رشق مشبوه على رابط الدعوة", client)
            return {
                "success": False,
                "reason": "تم اكتشاف نشاط مشبوه. تم تحذير صاحب الرابط.",
                "is_suspicious": True,
            }

        await self.vip.grant_vip(creator_id, "day")
        await self.db.execute(
            "UPDATE invite_redemptions SET reward_given = 1 WHERE invite_code = ? AND joiner_id = ?",
            (code, joiner_id),
        )
        logger.info(f"Invite reward: {creator_id} got 1 day VIP for inviting {joiner_id}")

        return {
            "success": True,
            "creator_id": creator_id,
            "reward": "1 day VIP",
            "is_suspicious": False,
        }

    async def _anti_reshq_check(self, user_id: int, data: dict = None, client=None) -> bool:
        if not data:
            data = {}
        user = data.get("user")
        score = 0

        if user:
            if user.is_scam:
                score += 50
            if user.is_fake:
                score += 50
            if user.is_support:
                score += 10
            if user.is_verified:
                score -= 10
            if user.is_restricted:
                score += 20
            if hasattr(user, "dc_id") and not user.dc_id:
                score += 30
            if user.username:
                score -= 5
            else:
                score += 15
            if user.first_name and len(user.first_name) < 2:
                score += 15
            if user.last_name and len(user.last_name) < 2:
                score += 10

        recent_count = await self.db.fetchval(
            "SELECT COUNT(*) FROM invite_redemptions WHERE joiner_id = ? AND joined_at > ?",
            (user_id, (datetime.utcnow() - timedelta(hours=1)).isoformat()),
        ) or 0
        if recent_count > 3:
            score += 40

        if user and hasattr(user, "id") and client:
            try:
                common_chats = await client.get_common_chats(user.id)
                if len(common_chats) < 1:
                    score += 20
            except Exception:
                score += 10

        if user and hasattr(user, "photo") and not user.photo:
            score += 10
        if user and hasattr(user, "id") and client:
            try:
                user_photos = await client.get_profile_photos(user.id)
                if not user_photos:
                    score += 10
            except Exception:
                pass

        logger.info(f"Anti-reshq score for user {user_id}: {score}")
        return score >= 50

    async def _warn_user(self, user_id: int, reason: str, client=None):
        await self.db.execute(
            "INSERT INTO invite_warnings (user_id, warning_reason, warned_at) VALUES (?, ?, ?)",
            (user_id, reason, datetime.utcnow().isoformat()),
        )
        warning_count = await self.db.fetchval(
            "SELECT COUNT(*) FROM invite_warnings WHERE user_id = ?", (user_id,)
        ) or 0
        logger.warning(f"Invite warning for {user_id}: {reason} (count: {warning_count})")
        if client:
            try:
                await client.send_message(
                    user_id,
                    f"⚠️ <b>تحذير من رابط الدعوة</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"السبب: {reason}\n"
                    f"عدد التحذيرات: {warning_count}\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"إذا تكرر الأمر قد يتم حظرك."
                )
            except Exception as e:
                logger.error(f"Could not warn user {user_id}: {e}")

    async def get_invite_stats(self, user_id: int) -> dict:
        invites = await self.db.fetch(
            "SELECT * FROM invite_links WHERE user_id = ?", (user_id,)
        )
        total_invites = len(invites)
        total_uses = sum(inv.get("uses", 0) for inv in invites)
        total_rewards = await self.db.fetchval(
            "SELECT COUNT(*) FROM invite_redemptions ir "
            "JOIN invite_links il ON ir.invite_code = il.code "
            "WHERE il.user_id = ? AND ir.reward_given = 1",
            (user_id,),
        ) or 0
        warnings = await self.db.fetchval(
            "SELECT COUNT(*) FROM invite_warnings WHERE user_id = ?", (user_id,)
        ) or 0
        return {
            "total_invites": total_invites,
            "total_uses": total_uses,
            "total_rewards": total_rewards,
            "warnings": warnings,
        }
