import json
import logging
from datetime import datetime
from html import escape

from aiohttp import web
from config import Config
from database import Database

logger = logging.getLogger(__name__)


def setup_landing_routes(app: web.Application, db: Database):
    @app.router.add_get("/r/{short_code}")
    async def landing_redirect(request: web.Request):
        short_code = request.match_info.get("short_code", "")
        if not short_code:
            raise web.HTTPNotFound()

        row = await db.fetchrow(
            "SELECT original_url FROM short_links WHERE short_code = ?", short_code
        )
        if not row:
            raise web.HTTPNotFound(text="❌ الرابط غير موجود أو منتهي الصلاحية.")

        original_url = row["original_url"]

        use_landing = await db.fetchval(
            "SELECT use_landing FROM qr_codes WHERE short_code = ?", short_code
        )

        if not use_landing:
            raise web.HTTPFound(location=original_url)

        ip = request.headers.get("X-Forwarded-For", request.remote or "")
        ua = request.headers.get("User-Agent", "")
        referer = request.headers.get("Referer", "")

        await db.execute(
            "INSERT INTO click_logs (link_id, ip, user_agent, referer, clicked_at) VALUES ("
            "(SELECT id FROM short_links WHERE short_code = ?), ?, ?, ?, ?)",
            (short_code, ip, ua, referer, datetime.utcnow().isoformat()),
        )

        await db.execute(
            "UPDATE qr_codes SET scan_count = scan_count + 1 WHERE short_code = ?",
            (short_code,),
        )

        return await _render_landing_page(short_code, original_url)

    logger.info("Landing page routes registered")


async def _render_landing_page(short_code: str, original_url: str) -> web.Response:
    safe_url = escape(original_url)
    safe_short = escape(short_code)
    bot_name = escape(Config.BOT_OWNER_NAME)
    web_url = Config.WEB_URL.rstrip("/")

    html_content = f"""<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>scanner_bot - رابط آمن</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
  }}
  .card {{
    background: rgba(255,255,255,0.08);
    backdrop-filter: blur(12px);
    border-radius: 20px;
    padding: 40px;
    max-width: 480px;
    width: 90%;
    text-align: center;
    border: 1px solid rgba(255,255,255,0.1);
  }}
  .logo {{
    font-size: 48px;
    margin-bottom: 16px;
  }}
  h1 {{
    font-size: 24px;
    margin-bottom: 8px;
    font-weight: 600;
  }}
  p {{
    color: rgba(255,255,255,0.7);
    margin-bottom: 24px;
    font-size: 14px;
    line-height: 1.6;
  }}
  .url-display {{
    background: rgba(0,0,0,0.3);
    border-radius: 10px;
    padding: 12px 16px;
    margin-bottom: 24px;
    font-size: 13px;
    color: rgba(255,255,255,0.6);
    word-break: break-all;
    direction: ltr;
    text-align: left;
  }}
  .countdown {{
    font-size: 36px;
    font-weight: 700;
    margin-bottom: 16px;
    color: #00d4ff;
  }}
  .btn {{
    display: inline-block;
    padding: 14px 40px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: #fff;
    text-decoration: none;
    border-radius: 12px;
    font-weight: 600;
    font-size: 16px;
    transition: transform 0.2s, box-shadow 0.2s;
    border: none;
    cursor: pointer;
  }}
  .btn:hover {{
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
  }}
  .btn:disabled {{
    opacity: 0.5;
    cursor: not-allowed;
    transform: none;
  }}
  .footer {{
    margin-top: 24px;
    font-size: 12px;
    color: rgba(255,255,255,0.4);
  }}
  .footer a {{ color: rgba(255,255,255,0.6); text-decoration: none; }}
</style>
</head>
<body>
<div class="card">
  <div class="logo">🛡️</div>
  <h1>رابط آمن من {bot_name}</h1>
  <p>تم فحص هذا الرابط بواسطة بوت فحص الروابط للتأكد من أمانه</p>
  <div class="url-display">{safe_url}</div>
  <div class="countdown" id="countdown">3</div>
  <p>سيتم تحويلك تلقائياً بعد العد التنازلي</p>
  <a href="{safe_url}" class="btn" id="continueBtn" disabled>⏳ جاري التحويل...</a>
  <div class="footer">
    <a href="https://t.me/AbdAleziz_1" target="_blank">@{bot_name}</a>
  </div>
</div>
<script>
  let count = 3;
  const cd = document.getElementById('countdown');
  const btn = document.getElementById('continueBtn');
  const interval = setInterval(() => {{
    count--;
    cd.textContent = count;
    if (count <= 0) {{
      clearInterval(interval);
      cd.textContent = '✅';
      btn.textContent = '🔗 متابعة إلى الرابط';
      btn.disabled = false;
        btn.href = '{safe_url}';
    }}
  }}, 1000);
</script>
</body>
</html>"""
    return web.Response(text=html_content, content_type="text/html", charset="utf-8")
