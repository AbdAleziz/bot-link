#!/usr/bin/env bash
# ============================================================
# scanner_bot — one-shot deploy script
# Usage:  bash deploy.sh
# Tested on: Ubuntu 22.04 / Debian 12
# ============================================================
set -e

echo "============================================"
echo " scanner_bot — install on this server"
echo "============================================"

# 1. Docker / docker-compose
if ! command -v docker >/dev/null 2>&1; then
  echo "[+] Installing Docker..."
  curl -fsSL https://get.docker.com -o get-docker.sh
  sh get-docker.sh
  rm get-docker.sh
fi

if ! docker compose version >/dev/null 2>&1; then
  echo "[+] Installing docker-compose plugin..."
  apt-get update -qq
  apt-get install -y -qq docker-compose-plugin
fi

# 2. .env
if [ ! -f .env ]; then
  if [ -f .env.example ]; then
    cp .env.example .env
    echo "[!] Created .env from .env.example — open it and fill your secrets!"
    echo "    nano .env"
    exit 0
  else
    echo "[-] No .env or .env.example found."
    exit 1
  fi
fi

# 3. Build & start
echo "[+] Building image..."
docker compose build

echo "[+] Starting bot..."
docker compose up -d

sleep 3
echo "[+] Status:"
docker compose ps
echo ""
echo "Web dashboard should be live on:"
echo "  http://$(curl -s ifconfig.me 2>/dev/null || echo YOUR_SERVER_IP):8080"
echo ""
echo "Useful commands:"
echo "  docker compose logs -f        # live logs"
echo "  docker compose restart        # restart"
echo "  docker compose down           # stop"
