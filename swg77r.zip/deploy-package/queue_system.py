# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import json
import logging
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Coroutine, Optional

from config import Config

logger = logging.getLogger("queue_system")


class TaskPriority(Enum):
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


@dataclass(order=True)
class QueueTask:
    priority: TaskPriority = TaskPriority.NORMAL
    created_at: float = field(default_factory=time.time)
    id: str = field(default_factory=lambda: f"task_{int(time.time() * 1000)}")
    name: str = ""
    data: Any = None
    callback: Optional[Callable] = None


class TaskQueue:
    def __init__(self, max_size: int = Config.QUEUE_MAX_SIZE):
        self._queue: deque[QueueTask] = deque()
        self._max_size = max_size
        self._processing = False
        self._workers = Config.QUEUE_WORKERS
        self._worker_tasks: list[asyncio.Task] = []
        self._redis_client = None
        self._redis_available = False

    async def init_redis(self):
        if Config.REDIS_URL:
            try:
                import redis.asyncio as aioredis
                self._redis_client = aioredis.from_url(
                    Config.REDIS_URL, decode_responses=True
                )
                await self._redis_client.ping()
                self._redis_available = True
                logger.info("Queue: Redis connected")
            except Exception as e:
                logger.warning(f"Queue: Redis unavailable, using in-memory: {e}")

    async def push(
        self,
        task: QueueTask,
    ):
        if len(self._queue) >= self._max_size:
            logger.warning(f"Queue full ({self._max_size}), dropping task {task.name}")
            return False

        self._queue.append(task)
        self._queue = deque(
            sorted(self._queue, key=lambda t: (t.priority.value, t.created_at))
        )

        if self._redis_available:
            try:
                await self._redis_client.lpush(
                    "task_queue",
                    json.dumps(
                        {
                            "id": task.id,
                            "name": task.name,
                            "data": task.data,
                            "priority": task.priority.value,
                            "created_at": task.created_at,
                        }
                    ),
                )
            except Exception:
                pass

        return True

    async def pop(self) -> Optional[QueueTask]:
        if self._redis_available:
            try:
                data = await self._redis_client.rpop("task_queue")
                if data:
                    parsed = json.loads(data)
                    return QueueTask(
                        id=parsed["id"],
                        name=parsed.get("name", ""),
                        data=parsed.get("data"),
                        priority=TaskPriority(parsed.get("priority", 1)),
                        created_at=parsed.get("created_at", time.time()),
                    )
            except Exception:
                pass

        return self._queue.popleft() if self._queue else None

    async def process_tasks(self, handler: Callable):
        self._processing = True
        for _ in range(self._workers):
            task = asyncio.create_task(self._worker_loop(handler))
            self._worker_tasks.append(task)
        logger.info(f"Started {self._workers} queue workers")

    async def _worker_loop(self, handler: Callable):
        while self._processing:
            try:
                task = await self.pop()
                if task:
                    try:
                        await handler(task)
                    except Exception as e:
                        logger.error(
                            f"Task {task.name} ({task.id}) failed: {e}",
                            exc_info=True,
                        )
                else:
                    await asyncio.sleep(0.1)
            except Exception as e:
                logger.error(f"Worker error: {e}")
                await asyncio.sleep(1)

    async def stop(self):
        self._processing = False
        for task in self._worker_tasks:
            task.cancel()
        await asyncio.gather(*self._worker_tasks, return_exceptions=True)
        if self._redis_available and self._redis_client:
            await self._redis_client.close()
        logger.info("Queue stopped")


task_queue = TaskQueue()
