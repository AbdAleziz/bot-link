"""Tests for ops/circuit_breaker.py."""

import os
import sys
import asyncio
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("LOCAL_ONLY_MODE", "true")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///data/test_bot.db")

from ops.circuit_breaker import CircuitBreaker, CircuitState


class TestCircuitBreaker:
    def test_initial_state_closed(self):
        cb = CircuitBreaker()
        state = cb._get_state("svc")
        assert state == CircuitState.CLOSED

    @pytest.mark.asyncio
    async def test_opens_after_threshold(self):
        cb = CircuitBreaker()
        for _ in range(5):
            await cb._record_failure("svc")
        state = cb._get_state("svc")
        assert state == CircuitState.OPEN

    @pytest.mark.asyncio
    async def test_success_resets(self):
        cb = CircuitBreaker()
        await cb._record_failure("svc")
        cb._on_success("svc")
        state = cb._get_state("svc")
        assert state == CircuitState.CLOSED

    @pytest.mark.asyncio
    async def test_call_success(self):
        cb = CircuitBreaker()
        async def ok():
            return "ok"
        result = await cb.call("svc", ok)
        assert result == "ok"

    @pytest.mark.asyncio
    async def test_call_failure_triggers_cb(self):
        cb = CircuitBreaker()
        async def fail():
            raise ValueError("boom")
        with pytest.raises(ValueError):
            await cb.call("svc", fail)
        state = cb._get_state("svc")
        assert state == CircuitState.CLOSED  # only 1 failure

    @pytest.mark.asyncio
    async def test_call_fallback_on_open(self):
        cb = CircuitBreaker()
        for _ in range(5):
            await cb._record_failure("svc")
        async def will_not_run():
            raise ValueError
        result = await cb.call("svc", will_not_run, fallback="cached")
        assert result == "cached"

    def test_unknown_service_default(self):
        cb = CircuitBreaker()
        state = cb._get_state("new_svc")
        assert state == CircuitState.CLOSED

    @pytest.mark.asyncio
    async def test_on_success_resets(self):
        cb = CircuitBreaker()
        for _ in range(3):
            await cb._record_failure("svc")
        cb._on_success("svc")
        state = cb._get_state("svc")
        assert state == CircuitState.CLOSED
