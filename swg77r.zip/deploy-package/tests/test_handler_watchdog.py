"""Tests for ops/watchdog.py."""

import os
import sys
import asyncio
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("LOCAL_ONLY_MODE", "true")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///data/test_bot.db")

from ops.watchdog import with_watchdog


class TestHandlerWatchdog:
    @pytest.mark.asyncio
    async def test_watchdog_returns_result(self):
        @with_watchdog(timeout=5)
        async def fast():
            return 42
        result = await fast()
        assert result == 42

    @pytest.mark.asyncio
    async def test_watchdog_timeout_returns_fallback(self):
        @with_watchdog(timeout=0.05)
        async def slow():
            await asyncio.sleep(10)
        result = await slow()
        assert "timed out" in result.lower() or "timeout" in result.lower()

    @pytest.mark.asyncio
    async def test_watchdog_preserves_exception(self):
        @with_watchdog(timeout=5)
        async def fails():
            raise ValueError("boom")
        with pytest.raises(ValueError, match="boom"):
            await fails()

    @pytest.mark.asyncio
    async def test_watchdog_custom_timeout(self):
        @with_watchdog(timeout=0.1)
        async def moderate():
            await asyncio.sleep(0.05)
            return "done"
        result = await moderate()
        assert result == "done"


@pytest.mark.asyncio
class TestMemoryWatchdog:
    async def test_memory_watchdog_instantiate(self):
        from ops.watchdog import MemoryWatchdog
        mw = MemoryWatchdog()
        assert mw is not None

    async def test_check_does_not_crash(self):
        from ops.watchdog import MemoryWatchdog
        mw = MemoryWatchdog()
        # _check returns None but should not raise
        await mw._check()

    async def test_alert_owner_runs(self):
        from ops.watchdog import MemoryWatchdog
        mw = MemoryWatchdog()
        await mw._alert_owner("test alert from unit test")
