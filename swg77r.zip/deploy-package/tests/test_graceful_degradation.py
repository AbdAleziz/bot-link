"""Tests for ops/degraded.py."""

import os
import sys
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("LOCAL_ONLY_MODE", "true")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///data/test_bot.db")
os.environ.setdefault("DEGRADED_AUTO_RECOVER", "1")  # short delay for testing

from ops.degraded import DegradationManager
from config import Config


class TestDegradationManager:
    def test_initial_state(self):
        dm = DegradationManager()
        status = dm.get_status()
        assert isinstance(status, dict)

    def test_mark_down(self):
        dm = DegradationManager()
        # Directly check internal state after mark_down
        dm.mark_down("virustotal")
        assert dm._status["virustotal"] is False

    def test_mark_up(self):
        dm = DegradationManager()
        dm.mark_down("db")
        assert dm._status["db"] is False
        dm.mark_up("db")
        assert dm._status["db"] is True

    def test_get_status(self):
        dm = DegradationManager()
        dm.mark_down("cache")
        status = dm.get_status()
        assert "cache" in status
        assert status["cache"] == "down"

    def test_mark_up_all(self):
        dm = DegradationManager()
        dm.mark_down("virustotal")
        dm.mark_down("urlscan")
        dm.mark_up("virustotal")
        status = dm.get_status()
        assert status["virustotal"] == "up"
        assert status["urlscan"] == "down"

    def test_no_cross_contamination(self):
        dm = DegradationManager()
        dm.mark_down("svc_a")
        assert "svc_b" not in dm._status
