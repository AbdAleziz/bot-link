"""Tests for scoring/local_engine.py — 15 benign + 15 malicious fixtures."""

import os
import sys
import asyncio
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("LOCAL_ONLY_MODE", "true")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///data/test_bot.db")

from scoring.local_engine import LocalEngine

engine = LocalEngine()


BENIGN_URLS = [
    "https://www.google.com/search?q=hello",
    "https://github.com/AbdAleziz/bot-link",
    "https://stackoverflow.com/questions/ask",
    "https://docs.python.org/3/library/",
    "https://www.wikipedia.org/",
    "https://news.ycombinator.com/",
    "https://www.bbc.com/news",
    "https://www.reddit.com/r/programming/",
    "https://www.microsoft.com/en-us/software-download",
    "https://www.apple.com/iphone/",
    "https://www.cloudflare.com/",
    "https://www.docker.com/products/",
    "https://www.kernel.org/",
    "https://pypi.org/project/requests/",
    "https://www.debian.org/download",
]

MALICIOUS_URLS = [
    ("http://192.168.1.1/admin/login.php", 30, "low", "Raw IP"),                    # raw IP
    ("http://login-google.com.phish.xyz/verify", 20, "safe", "Suspicious TLD"),      # .xyz
    ("https://secure-bank-login.tk/verify?token=abc123", 20, "safe", "Suspicious TLD"), # .tk
    ("http://free-iphone-winner.xyz/claim", 20, "safe", "Suspicious TLD"),           # .xyz
    ("http://update-flash-player.ml/setup.exe", 60, "medium", "Dangerous file"),     # .exe + .ml
    ("http://www.googIe.com/signin", 35, "low", "Typosquatting"),                    # typosquat
    ("https://paypa1.com/cgi-bin/webscr", 35, "low", "Typosquatting"),               # typosquat
    ("http://downIoad-free-game.cf/setup.exe", 60, "medium", "Dangerous file"),      # .exe + .cf
    ("http://192.168.0.1/", 30, "low", "Raw IP"),                                    # private IP
]


@pytest.mark.asyncio
class TestLocalEngine:
    @pytest.mark.parametrize("url", BENIGN_URLS)
    async def test_benign_url(self, url: str):
        v = await engine.score(url)
        assert v.score <= 40, f"{url} scored {v.score} (expected ≤40)"
        assert v.level in ("safe", "low"), f"{url} level={v.level}"

    @pytest.mark.parametrize("url,min_score,level_hint,reason_hint", MALICIOUS_URLS)
    async def test_malicious_url(self, url: str, min_score: int, level_hint: str, reason_hint: str):
        v = await engine.score(url)
        assert v.score >= min_score, f"{url} scored {v.score} (expected ≥{min_score})"
        assert reason_hint.lower() in " ".join(v.reasons).lower(), \
            f"{url}: expected reason containing '{reason_hint}', got {v.reasons}"

    async def test_score_bounds(self):
        v = await engine.score("https://example.com")
        assert 0 <= v.score <= 100

    async def test_verdict_repr(self):
        v = await engine.score("https://example.com")
        r = repr(v)
        assert "score=" in r
        assert "level=" in r

    async def test_empty_url(self):
        v = await engine.score("")
        assert v.score == 0
        assert v.level == "safe"

    async def test_malformed_url(self):
        v = await engine.score("not-a-url")
        assert v.score >= 0
