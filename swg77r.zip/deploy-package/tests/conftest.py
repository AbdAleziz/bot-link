"""Shared test fixtures."""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

os.environ.setdefault("LOCAL_ONLY_MODE", "true")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///data/test_bot.db")
