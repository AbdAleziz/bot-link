"""Tests for i18n/translator.py — bilingual coverage."""

import os
import sys
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("LOCAL_ONLY_MODE", "true")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///data/test_bot.db")

from i18n.translator import t, _translations, _ensure_loaded


_ensure_loaded("en")
_ensure_loaded("ar")
_en = _translations.get("en", {})
_ar = _translations.get("ar", {})
EN_KEYS = set(_en.keys())
AR_KEYS = set(_ar.keys())


class TestI18n:
    def test_en_loads(self):
        assert len(_en) > 0, "English translations empty"

    def test_ar_loads(self):
        assert len(_ar) > 0, "Arabic translations empty"

    def test_ar_covers_en(self):
        missing = EN_KEYS - AR_KEYS
        assert not missing, f"Arabic missing keys: {missing}"

    def test_en_default(self):
        val = t("main.menu.scan")
        assert val is not None
        assert len(val) > 0

    def test_ar_translation(self):
        ar_val = t("main.menu.scan", lang="ar")
        assert ar_val is not None
        en_val = t("main.menu.scan", lang="en")
        assert ar_val != en_val

    def test_fallback_to_en(self):
        assert t("nonexistent.key") == "nonexistent.key"

    def test_ar_fallback_on_missing(self):
        val = t("nonexistent.key", lang="ar")
        assert val == "nonexistent.key"

    def test_f_string_substitution(self):
        val = t("vip.trial.granted", lang="ar", days=3)
        assert val is not None
        assert "3" in val or "٣" in val or len(val) > 0

    def test_all_keys_have_values_en(self):
        empty = [k for k, v in _en.items() if not v]
        assert not empty, f"Empty EN values: {empty}"

    def test_all_keys_have_values_ar(self):
        empty = [k for k, v in _ar.items() if not v]
        assert not empty, f"Empty AR values: {empty}"
