"""Tests for security modules."""

import os
import sys
import asyncio
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("LOCAL_ONLY_MODE", "true")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///data/test_bot.db")

from security.extension_guard import ExtensionGuard, DANGEROUS_EXTENSIONS
from security.self_scan import SelfScanner


class TestExtensionGuard:
    def test_dangerous_extension_exe(self):
        assert ExtensionGuard.is_dangerous_extension("setup.exe") == ".exe"

    def test_dangerous_extension_scr(self):
        assert ExtensionGuard.is_dangerous_extension("file.scr") == ".scr"

    def test_dangerous_extension_apk(self):
        assert ExtensionGuard.is_dangerous_extension("app.apk") == ".apk"

    def test_safe_extension_pdf(self):
        assert ExtensionGuard.is_dangerous_extension("file.pdf") is None

    def test_safe_extension_txt(self):
        assert ExtensionGuard.is_dangerous_extension("file.txt") is None

    def test_no_extension_safe(self):
        assert ExtensionGuard.is_dangerous_extension("file") is None

    def test_case_insensitive(self):
        assert ExtensionGuard.is_dangerous_extension("SETUP.EXE") == ".exe"

    def test_dangerous_list_not_empty(self):
        assert len(DANGEROUS_EXTENSIONS) > 0


@pytest.mark.asyncio
class TestSelfScanner:
    async def test_scan_returns_list(self):
        sc = SelfScanner()
        results = await sc.scan()
        assert isinstance(results, list)

    async def test_generate_report(self):
        sc = SelfScanner()
        report = await sc.generate_report()
        assert isinstance(report, str)
