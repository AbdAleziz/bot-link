"""Tests for database failure resilience (circuit breaker + retry)."""

import os
import sys
import asyncio
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("LOCAL_ONLY_MODE", "true")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///data/test_bot.db")

from ops.circuit_breaker import CircuitBreaker, CircuitState


class TestDbFailureResilience:
    def test_get_state_default_closed(self):
        cb = CircuitBreaker()
        state = cb._get_state("db")
        assert state == CircuitState.CLOSED

    @pytest.mark.asyncio
    async def test_failures_tracked(self):
        cb = CircuitBreaker()
        for _ in range(3):
            await cb._record_failure("db")
        state = cb._get_state("db")
        assert state == CircuitState.CLOSED

    @pytest.mark.asyncio
    async def test_opens_after_threshold(self):
        cb = CircuitBreaker()
        for _ in range(5):
            await cb._record_failure("db")
        state = cb._get_state("db")
        assert state == CircuitState.OPEN

    @pytest.mark.asyncio
    async def test_success_resets(self):
        cb = CircuitBreaker()
        for _ in range(3):
            await cb._record_failure("db")
        cb._on_success("db")
        state = cb._get_state("db")
        assert state == CircuitState.CLOSED

    @pytest.mark.asyncio
    async def test_call_uses_fallback(self):
        cb = CircuitBreaker()
        for _ in range(5):
            await cb._record_failure("db")
        async def fail():
            raise ValueError
        result = await cb.call("db", fail, fallback="cached_data")
        assert result == "cached_data"

    @pytest.mark.asyncio
    async def test_call_passes_through(self):
        cb = CircuitBreaker()
        async def live():
            return "live_data"
        result = await cb.call("db", live)
        assert result == "live_data"

    @pytest.mark.asyncio
    async def test_multiple_services_independent(self):
        cb = CircuitBreaker()
        for _ in range(5):
            await cb._record_failure("virustotal")
        assert cb._get_state("virustotal") == CircuitState.OPEN
        assert cb._get_state("db") == CircuitState.CLOSED
