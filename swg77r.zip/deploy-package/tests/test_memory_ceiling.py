"""Tests for memory ceiling enforcement via MemoryWatchdog."""

import os
import sys
import asyncio
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("LOCAL_ONLY_MODE", "true")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///data/test_bot.db")

from ops.watchdog import MemoryWatchdog


@pytest.mark.asyncio
class TestMemoryCeiling:
    async def test_instantiate(self):
        mw = MemoryWatchdog()
        assert mw is not None

    async def test_check_does_not_raise(self):
        mw = MemoryWatchdog()
        await mw._check()

    async def test_drop_lru_caches(self):
        mw = MemoryWatchdog()
        mw._drop_lru_caches()

    async def test_alert_owner(self):
        mw = MemoryWatchdog()
        await mw._alert_owner("memory ceiling test")

    async def test_start_stop(self):
        mw = MemoryWatchdog()
        mw.start()
        await asyncio.sleep(0.1)
        await mw.stop()
