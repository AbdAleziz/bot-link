"""Simple load test for LocalEngine — verifies 60+ req/s throughput."""

import os
import sys
import time
import asyncio
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("LOCAL_ONLY_MODE", "true")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///data/test_bot.db")

from scoring.local_engine import LocalEngine

engine = LocalEngine()

URLS = [
    "https://google.com",
    "https://github.com/AbdAleziz/bot-link",
    "https://stackoverflow.com/questions/ask",
    "https://docs.python.org/3/library/",
    "https://www.wikipedia.org/",
    "https://news.ycombinator.com/",
    "https://www.bbc.com/news",
    "https://www.reddit.com/r/programming/",
    "https://www.microsoft.com/en-us/software-download",
    "https://paypa1.com/cgi-bin/webscr",
    "http://192.168.1.1/admin/login.php",
    "http://login-google.com.phish.xyz/verify",
    "https://secure-bank-login.tk/verify",
    "http://bit.ly/3xPhIsH",
    "https://tinyurl.com/2p8h3abc",
] * 4  # 60 URLs


@pytest.mark.asyncio
async def test_throughput():
    tasks = [engine.score(url) for url in URLS]
    start = time.perf_counter()
    results = await asyncio.gather(*tasks)
    elapsed = time.perf_counter() - start
    rate = len(URLS) / elapsed
    print(f"\n⏱  {len(URLS)} URLs in {elapsed:.3f}s → {rate:.0f} req/s")
    assert rate >= 60, f"Throughput {rate:.0f} req/s < 60 req/s"
    assert len(results) == len(URLS)
