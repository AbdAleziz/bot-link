"""Tests for ops/semaphore_pool.py — concurrency & bottleneck prevention."""

import os
import sys
import asyncio
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("LOCAL_ONLY_MODE", "true")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///data/test_bot.db")

from ops.semaphore_pool import SemaphorePool


class TestNoBottleneck:
    def test_default_limits(self):
        sp = SemaphorePool()
        assert "external_http" in sp._limits
        assert "whois" in sp._limits
        assert "db_write" in sp._limits

    def test_custom_limits(self):
        sp = SemaphorePool(limits={"scan": 5})
        assert sp._limits["scan"] == 5

    @pytest.mark.asyncio
    async def test_acquire_release(self):
        sp = SemaphorePool(limits={"test": 1})  # limit 1, so locked after acquire
        await sp.acquire("test")
        sem = sp._get("test")
        assert sem.locked()
        sp.release("test")
        assert not sem.locked()

    @pytest.mark.asyncio
    async def test_context_manager(self):
        sp = SemaphorePool(limits={"test": 2})
        async with sp:
            pass

    @pytest.mark.asyncio
    async def test_limits_concurrency(self):
        sp = SemaphorePool(limits={"scan": 2})
        acquired = 0
        async def grab():
            nonlocal acquired
            await sp.acquire("scan")
            acquired += 1
            await asyncio.sleep(0.05)
            sp.release("scan")
        tasks = [asyncio.create_task(grab()) for _ in range(4)]
        await asyncio.sleep(0.02)
        assert acquired <= 2
        await asyncio.sleep(0.2)
        for t in tasks:
            t.cancel()

    def test_pool_isolation(self):
        sp = SemaphorePool(limits={"a": 1, "b": 1})
        s1 = sp._get("a")
        s2 = sp._get("b")
        assert s1 is not s2

    def test_pool_reuse(self):
        sp = SemaphorePool(limits={"x": 3})
        s1 = sp._get("x")
        s2 = sp._get("x")
        assert s1 is s2

    def test_semaphore_type(self):
        import asyncio
        sp = SemaphorePool(limits={"t": 2})
        sem = sp._get("t")
        assert isinstance(sem, asyncio.Semaphore)
