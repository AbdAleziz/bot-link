"""SupportAgent dataclass + Config.SUPPORT_USERS parser (dual-format)."""

import logging
import os
import re
from dataclasses import dataclass
from typing import Optional

from config import Config

logger = logging.getLogger(__name__)

HOURS_RE = re.compile(r"^\d{2}:\d{2}-\d{2}:\d{2}$")


@dataclass
class SupportAgent:
    user_id: int
    name: str
    role: str
    hours: Optional[str]  # "HH:MM-HH:MM" or None


def parse_support_users() -> list[SupportAgent]:
    agents: dict[int, SupportAgent] = {}

    # Format B: verbose indexed blocks SUPPORT_USER_N_ID, SUPPORT_USER_N_NAME, ...
    i = 1
    while True:
        uid_str = getattr(Config, f"SUPPORT_USER_{i}_ID", None) or ""
        if not uid_str:
            i += 1
            if i > 200:
                break
            continue
        try:
            uid = int(uid_str)
        except (ValueError, TypeError):
            logger.warning("Support: invalid SUPPORT_USER_%d_ID=%r, skipping", i, uid_str)
            i += 1
            continue

        name = getattr(Config, f"SUPPORT_USER_{i}_NAME", "") or ""
        role = getattr(Config, f"SUPPORT_USER_{i}_ROLE", "") or ""
        hours_raw = getattr(Config, f"SUPPORT_USER_{i}_HOURS", "") or ""
        hours = hours_raw if hours_raw and HOURS_RE.match(hours_raw) else None
        if hours_raw and hours is None:
            logger.warning("Support: invalid SUPPORT_USER_%d_HOURS=%r, treating as always online", i, hours_raw)

        agents[uid] = SupportAgent(uid, name, role, hours)
        i += 1

    # Format A: compact parallel lists
    raw_ids = os.getenv("SUPPORT_USERS", "")
    raw_names = os.getenv("SUPPORT_NAMES", "")
    raw_roles = os.getenv("SUPPORT_ROLES", "")
    raw_hours = os.getenv("SUPPORT_HOURS", "")

    if raw_ids:
        ids = [x.strip() for x in raw_ids.split(",") if x.strip()]
        names = [x.strip() for x in raw_names.split(",")] if raw_names else []
        roles = [x.strip() for x in raw_roles.split(",")] if raw_roles else []
        hours_list = [x.strip() for x in raw_hours.split(",")] if raw_hours else []

        # Warn if lengths mismatch
        n = len(ids)
        if len(names) != n:
            logger.warning("Support: SUPPORT_NAMES length %d != SUPPORT_USERS length %d", len(names), n)
            names = (names + [""] * n)[:n]
        if len(roles) != n:
            logger.warning("Support: SUPPORT_ROLES length %d != SUPPORT_USERS length %d", len(roles), n)
            roles = (roles + [""] * n)[:n]
        if len(hours_list) != n:
            logger.warning("Support: SUPPORT_HOURS length %d != SUPPORT_USERS length %d", len(hours_list), n)
            hours_list = (hours_list + [""] * n)[:n]

        for idx, uid_str in enumerate(ids):
            try:
                uid = int(uid_str)
            except (ValueError, TypeError):
                logger.warning("Support: invalid SUPPORT_USERS entry %r, skipping", uid_str)
                continue
            name = names[idx] if idx < len(names) else ""
            role = roles[idx] if idx < len(roles) else ""
            h = hours_list[idx] if idx < len(hours_list) else ""
            hours = h if h and HOURS_RE.match(h) else None
            if h and hours is None:
                logger.warning("Support: invalid HOURS entry %r for user %d, treating as always online", h, uid)

            # Format B wins for duplicates
            if uid not in agents:
                agents[uid] = SupportAgent(uid, name, role, hours)

    result = list(agents.values())
    logger.info("Support: parsed %d agent(s)", len(result))
    return result
