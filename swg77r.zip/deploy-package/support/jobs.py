"""Background auto-close job for stale tickets."""

import asyncio
import logging

from config import Config
from .tickets import TicketStore

logger = logging.getLogger(__name__)


async def _get_user_lang(db, user_id: int) -> str:
    try:
        row = await db.fetchval(
            "SELECT language FROM user_language WHERE user_id = ?", user_id
        )
        return row or "ar"
    except Exception:
        return "ar"


async def run_auto_close_loop(app, db):
    if Config.SUPPORT_AUTO_CLOSE_HOURS <= 0:
        logger.info("Support auto-close disabled (SUPPORT_AUTO_CLOSE_HOURS=0)")
        return

    ts = TicketStore(db)
    logger.info("Support auto-close job started (every 30m, idle >%dh)", Config.SUPPORT_AUTO_CLOSE_HOURS)
    while True:
        try:
            stale = await ts.auto_close_stale()
            if stale:
                for tkt in stale:
                    user_lang = await _get_user_lang(db, tkt["user_id"])
                    if user_lang == "ar":
                        user_msg = f"تم إغلاق التذكرة {tkt['id']} تلقائياً لانتهاء المهلة"
                    else:
                        user_msg = f"Ticket {tkt['id']} auto-closed due to inactivity"
                    try:
                        await app.send_message(
                            tkt["user_id"],
                            f"ℹ️ {user_msg}",
                        )
                    except Exception:
                        pass
                    if tkt.get("assigned_to"):
                        assignee_lang = await _get_user_lang(db, tkt["assigned_to"])
                        if assignee_lang == "ar":
                            assignee_msg = f"تم إغلاق التذكرة {tkt['id']} تلقائياً"
                        else:
                            assignee_msg = f"Ticket {tkt['id']} auto-closed"
                        try:
                            await app.send_message(
                                tkt["assigned_to"],
                                f"ℹ️ {assignee_msg}",
                            )
                        except Exception:
                            pass
        except Exception as e:
            logger.error("Auto-close error: %s", e)
        await asyncio.sleep(1800)  # 30 minutes
