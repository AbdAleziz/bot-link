import hashlib
import logging
from datetime import datetime

from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from config import Config
from database import Database
from rbac import RBAC

logger = logging.getLogger(__name__)


def _url_hash(url: str) -> str:
    return hashlib.sha256(url.encode()).hexdigest()[:16]


async def register_voting(app: Client, db: Database):
    @app.on_callback_query(filters.regex(r"^vote_"))
    async def vote_callback(client: Client, cb: CallbackQuery):
        uid = cb.from_user.id
        parts = cb.data.split("_", 2)
        if len(parts) < 3:
            await cb.answer("❌ بيانات غير صالحة.")
            return

        vote_type = parts[1]
        url_hash_val = parts[2]

        if vote_type not in ("safe", "malicious", "warning"):
            await cb.answer("❌ نوع تصويت غير معروف.")
            return

        existing = await db.fetchrow(
            "SELECT vote_type FROM community_votes WHERE user_id = ? AND url_hash = ?",
            (uid, url_hash_val),
        )
        if existing:
            await cb.answer("✅ لقد صوّت مسبقاً على هذا الرابط.", show_alert=True)
            return

        await db.execute(
            "INSERT INTO community_votes (user_id, url_hash, vote_type, created_at) VALUES (?, ?, ?, ?)",
            (uid, url_hash_val, vote_type, datetime.utcnow().isoformat()),
        )

        await cb.answer("✅ تم تسجيل صوتك!", show_alert=True)

        safe_votes = await db.fetchval(
            "SELECT COUNT(*) FROM community_votes WHERE url_hash = ? AND vote_type = 'safe'",
            (url_hash_val,),
        ) or 0
        malicious_votes = await db.fetchval(
            "SELECT COUNT(*) FROM community_votes WHERE url_hash = ? AND vote_type = 'malicious'",
            (url_hash_val,),
        ) or 0
        warning_votes = await db.fetchval(
            "SELECT COUNT(*) FROM community_votes WHERE url_hash = ? AND vote_type = 'warning'",
            (url_hash_val,),
        ) or 0

        total = safe_votes + malicious_votes + warning_votes
        score = safe_votes - malicious_votes

        new_text = (
            f"{cb.message.text}\n\n"
            f"━━━━━━━━━━━━━━\n"
            f"🗳️ <b>تصويت المجتمع</b>\n"
            f"👍 آمن: {safe_votes} | 👎 ضار: {malicious_votes} | ⚠️ تحذير: {warning_votes}\n"
            f"📊 المجموع: {total} صوت"
        )

        show_votes = total >= 3 or RBAC.is_admin(uid)
        if show_votes:
            new_text += f"\n🏆 النتيجة: {score}"

        await cb.message.edit(
            new_text,
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(f"👍 ({safe_votes})", callback_data=f"vote_safe_{url_hash_val}"),
                    InlineKeyboardButton(f"👎 ({malicious_votes})", callback_data=f"vote_malicious_{url_hash_val}"),
                    InlineKeyboardButton(f"⚠️ ({warning_votes})", callback_data=f"vote_warning_{url_hash_val}"),
                ],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
            ]),
        )


def voting_keyboard(url: str) -> InlineKeyboardMarkup:
    url_h = _url_hash(url)
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("👍", callback_data=f"vote_safe_{url_h}"),
            InlineKeyboardButton("👎", callback_data=f"vote_malicious_{url_h}"),
            InlineKeyboardButton("⚠️", callback_data=f"vote_warning_{url_h}"),
        ],
        [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
    ])


async def get_vote_summary(db: Database, url_hash: str) -> dict:
    safe = await db.fetchval(
        "SELECT COUNT(*) FROM community_votes WHERE url_hash = ? AND vote_type = 'safe'",
        (url_hash,),
    ) or 0
    malicious = await db.fetchval(
        "SELECT COUNT(*) FROM community_votes WHERE url_hash = ? AND vote_type = 'malicious'",
        (url_hash,),
    ) or 0
    warning = await db.fetchval(
        "SELECT COUNT(*) FROM community_votes WHERE url_hash = ? AND vote_type = 'warning'",
        (url_hash,),
    ) or 0
    return {"safe": safe, "malicious": malicious, "warning": warning, "score": safe - malicious}


async def get_top_voted(db: Database, limit: int = 10) -> list:
    rows = await db.fetch(
        "SELECT url_hash, COUNT(*) as total_votes, "
        "SUM(CASE WHEN vote_type = 'safe' THEN 1 ELSE 0 END) as safe_votes, "
        "SUM(CASE WHEN vote_type = 'malicious' THEN 1 ELSE 0 END) as malicious_votes "
        "FROM community_votes GROUP BY url_hash "
        "ORDER BY total_votes DESC LIMIT ?",
        (limit,),
    )
    result = []
    for r in rows:
        result.append({
            "url_hash": r["url_hash"],
            "total_votes": r["total_votes"],
            "score": r["safe_votes"] - r["malicious_votes"],
        })
    return result
