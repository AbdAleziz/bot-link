import asyncio
import hashlib
import logging
from pathlib import Path

import httpx

from config import Config

logger = logging.getLogger(__name__)

DATA_DIR = Path(Config.BACKUP_DIR if Config.BACKUP_DIR else "data")
PHISHTANK_URL = "https://raw.githubusercontent.com/mitchellkrogza/Phishing.Database/master/phishing-domains-ACTIVE.txt"
OPENPHISH_URL = "https://openphish.com/feed.txt"
REFRESH_INTERVAL = 21600


def _sha256(url: str) -> str:
    return hashlib.sha256(url.encode("utf-8")).hexdigest()


def _levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i] + [0] * len(b)
        for j, cb in enumerate(b, 1):
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb))
        prev = cur
    return prev[-1]


class BlacklistManager:
    def __init__(self):
        self._hashes: set[str] = set()
        self._urls: list[str] = []
        self._mirror_path = Path(DATA_DIR, "blacklist_mirror.txt")
        self._lock = asyncio.Lock()

    async def refresh(self):
        async with self._lock:
            new_urls = set()

            try:
                async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
                    resp = await client.get(PHISHTANK_URL)
                    if resp.status_code == 200:
                        for line in resp.text.splitlines():
                            line = line.strip().lower()
                            if line and not line.startswith("#"):
                                new_urls.add(line)
                    else:
                        logger.warning("PhishTank fetch returned %s", resp.status_code)
            except Exception as e:
                logger.error("PhishTank fetch failed: %s", e)

            try:
                async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
                    resp = await client.get(OPENPHISH_URL)
                    if resp.status_code == 200:
                        for line in resp.text.splitlines():
                            line = line.strip().lower()
                            if line:
                                new_urls.add(line)
                    else:
                        logger.warning("OpenPhish fetch returned %s", resp.status_code)
            except Exception as e:
                logger.error("OpenPhish fetch failed: %s", e)

            if not new_urls:
                logger.warning("No URLs fetched, keeping existing mirror")
                return

            self._urls = list(new_urls)
            self._hashes = {_sha256(u) for u in self._urls}

            try:
                DATA_DIR.mkdir(parents=True, exist_ok=True)
                self._mirror_path.write_text("\n".join(self._urls), encoding="utf-8")
            except Exception as e:
                logger.error("Failed to write mirror: %s", e)

            logger.info("Blacklist mirror refreshed: %d URLs", len(self._urls))

    async def lookup(self, url: str) -> dict:
        url = url.strip().lower()
        url_hash = _sha256(url)

        if url_hash in self._hashes:
            return {"blocked": True, "match": "exact", "url": url}

        for i, stored in enumerate(self._urls):
            dist = _levenshtein(url, stored)
            if dist <= 3:
                return {
                    "blocked": True,
                    "match": "levenshtein",
                    "distance": dist,
                    "url": url,
                    "matched_url": stored,
                }

        return {"blocked": False}

    async def start_auto_refresh(self, app):
        await self.refresh()

        async def _loop():
            while True:
                await asyncio.sleep(REFRESH_INTERVAL)
                try:
                    await self.refresh()
                except Exception as e:
                    logger.error("Auto-refresh failed: %s", e)

        asyncio.ensure_future(_loop())
