import asyncio
import logging
from urllib.parse import urlparse

import httpx

from config import Config

logger = logging.getLogger(__name__)

MAX_HOPS = 20


async def _geo(host: str) -> str:
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(f"https://ipapi.co/{host}/country/")
            if resp.status_code == 200:
                return resp.text.strip()
    except Exception as e:
        logger.debug("Geo lookup failed for %s: %s", host, e)
    return ""


async def walk(url: str) -> dict:
    hops = []
    result = {
        "original_url": url,
        "hops": hops,
        "final_url": url,
        "total_hops": 0,
        "termination_reason": "completed",
        "risk_flags": [],
    }

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    current = url

    async with httpx.AsyncClient(
        timeout=Config.SCAN_TIMEOUT,
        follow_redirects=False,
        verify=False,
        headers={"User-Agent": "Mozilla/5.0 (compatible; SecurityBot/2.0)"},
    ) as client:

        for hop_num in range(MAX_HOPS):
            try:
                resp = await client.get(current, headers={"User-Agent": "Mozilla/5.0"})
            except Exception as e:
                hops.append({
                    "hop": hop_num + 1,
                    "url": current,
                    "status": 0,
                    "error": str(e),
                    "redirect_type": "error",
                })
                result["termination_reason"] = f"error: {e}"
                break

            location = resp.headers.get("location") or resp.headers.get("Location", "")
            parsed = urlparse(current)
            ip = ""
            try:
                _, writer = await asyncio.wait_for(
                    asyncio.open_connection(parsed.hostname or "", 443 if parsed.scheme == "https" else 80),
                    timeout=5,
                )
                ip = writer.get_extra_info("peername")[0] if writer.get_extra_info("peername") else ""
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

            country = await _geo(ip) if ip else ""

            hop_info = {
                "hop": hop_num + 1,
                "url": current,
                "status": resp.status_code,
                "location": location or None,
                "ip": ip,
                "country": country,
                "server": resp.headers.get("server", ""),
                "content_type": resp.headers.get("content-type", ""),
                "response_size": len(resp.content),
                "redirect_type": "direct" if resp.status_code in (301, 302, 303, 307, 308) else "meta" if location else "final",
            }
            hops.append(hop_info)

            if not location:
                result["final_url"] = current
                result["total_hops"] = hop_num + 1
                break

            if not location.startswith(("http://", "https://")):
                from urllib.parse import urljoin
                location = urljoin(current, location)

            if hop_num >= 10:
                result["risk_flags"].append(f"hop count > 10 ({hop_num + 1})")

            parsed_current = urlparse(current)
            parsed_next = urlparse(location)

            if parsed_current.hostname and parsed_next.hostname:
                if parsed_current.hostname != parsed_next.hostname:
                    prev_country = country
                    next_country = await _geo(parsed_next.hostname)
                    hop_info["country"] = prev_country or ""
                    if prev_country and next_country and prev_country != next_country:
                        result["risk_flags"].append(
                            f"hop {hop_num + 1}: host changed {parsed_current.hostname} ({prev_country}) -> "
                            f"{parsed_next.hostname} ({next_country}) across countries"
                        )

            if 400 <= resp.status_code < 600:
                result["risk_flags"].append(
                    f"hop {hop_num + 1}: {resp.status_code} from {current}"
                )

            current = location

        else:
            result["termination_reason"] = "max hops exceeded"
            result["risk_flags"].append("max hops exceeded")

    result["total_hops"] = len(hops)
    return result
