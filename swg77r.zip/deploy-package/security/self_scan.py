import ast
import logging
import os
import re
from pathlib import Path

import httpx

from config import Config

logger = logging.getLogger(__name__)

RISKY_PATTERNS = {
    "eval": {"pattern": "eval(", "severity": "CRITICAL", "desc": "Arbitrary code execution via eval()"},
    "exec": {"pattern": "exec(", "severity": "CRITICAL", "desc": "Arbitrary code execution via exec()"},
    "compile": {"pattern": "compile(", "severity": "CRITICAL", "desc": "Arbitrary code execution via compile()"},
    "os_system": {"pattern": "os.system(", "severity": "HIGH", "desc": "OS command execution"},
    "subprocess_shell": {"pattern": "subprocess.Popen(shell=True", "severity": "HIGH", "desc": "Shell=True in subprocess"},
    "pickle_loads": {"pattern": "pickle.loads(", "severity": "CRITICAL", "desc": "Insecure deserialization via pickle"},
    "yaml_load": {"pattern": "yaml.load(", "severity": "HIGH", "desc": "YAML load without SafeLoader"},
}

GREP_PATTERNS = {
    "verify_false": {"pattern": r"verify\s*=\s*False", "severity": "MEDIUM", "desc": "SSL verification disabled"},
    "disable_warnings": {"pattern": r"requests\.packages\.urllib3\.disable_warnings", "severity": "LOW", "desc": "SSL warnings suppressed"},
    "bot_token": {"pattern": r"['\"][0-9]+:[A-Za-z0-9_-]{35}['\"]", "severity": "HIGH", "desc": "Hard-coded BOT_TOKEN pattern"},
    "api_key": {"pattern": r"['\"](sk-[A-Za-z0-9]{20,})['\"]", "severity": "HIGH", "desc": "Hard-coded API key pattern"},
}


class SelfScanner:
    def __init__(self, project_root: str | Path = None):
        self.project_root = Path(project_root or os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    async def scan(self) -> list[dict]:
        findings = []
        py_files = list(self.project_root.rglob("*.py"))

        for filepath in py_files:
            rel = filepath.relative_to(self.project_root)
            try:
                content = filepath.read_text(encoding="utf-8", errors="ignore")
            except Exception as e:
                logger.warning("Cannot read %s: %s", rel, e)
                continue

            tree = None
            try:
                tree = ast.parse(content, filename=str(filepath))
            except SyntaxError:
                findings.append({
                    "file": str(rel), "line": 0, "severity": "LOW",
                    "description": "Syntax error in file",
                })
                continue

            for node in ast.walk(tree):
                if isinstance(node, ast.Call):
                    for name, info in RISKY_PATTERNS.items():
                        match = self._match_call(node, info["pattern"])
                        if match:
                            findings.append({
                                "file": str(rel),
                                "line": node.lineno,
                                "severity": info["severity"],
                                "description": info["desc"],
                                "pattern": name,
                            })

            for lineno, line in enumerate(content.splitlines(), 1):
                for name, info in GREP_PATTERNS.items():
                    if re.search(info["pattern"], line):
                        findings.append({
                            "file": str(rel),
                            "line": lineno,
                            "severity": info["severity"],
                            "description": info["desc"],
                            "pattern": name,
                        })

        return findings

    @staticmethod
    def _match_call(node: ast.Call, pattern: str) -> bool:
        if pattern.startswith("subprocess.Popen("):
            if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name):
                if node.func.value.id == "subprocess" and node.func.attr == "Popen":
                    for kw in node.keywords:
                        if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                            return True
            return False

        if pattern == "eval(" and isinstance(node.func, ast.Name) and node.func.id == "eval":
            return True
        if pattern == "exec(" and isinstance(node.func, ast.Name) and node.func.id == "exec":
            return True
        if pattern == "compile(" and isinstance(node.func, ast.Name) and node.func.id == "compile":
            return True
        if pattern == "os.system(":
            if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == "os" and node.func.attr == "system":
                return True
            if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Attribute) and hasattr(node.func.value, "attr"):
                return True
            return False
        if pattern == "pickle.loads(":
            if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == "pickle" and node.func.attr == "loads":
                return True
            return False
        if pattern == "yaml.load(":
            if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == "yaml" and node.func.attr == "load":
                for kw in node.keywords:
                    if kw.arg == "Loader" and isinstance(kw.value, ast.Attribute) and kw.value.attr == "SafeLoader":
                        return False
                return True
            return False

        return False

    async def generate_report(self) -> str:
        findings = await self.scan()
        if not findings:
            return "## Self-Scan Report\n\nNo issues found."

        severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
        findings.sort(key=lambda f: severity_order.get(f["severity"], 99))

        lines = ["# Self-Scan Report", f"Total findings: {len(findings)}", ""]

        for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
            group = [f for f in findings if f["severity"] == sev]
            if not group:
                continue
            lines.append(f"## {sev} ({len(group)})")
            for f in group:
                lines.append(f"- `{f['file']}:{f['line']}` — {f['description']}")
            lines.append("")

        return "\n".join(lines)
