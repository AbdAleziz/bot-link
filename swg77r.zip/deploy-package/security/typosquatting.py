import json
import logging
import unicodedata
from pathlib import Path

logger = logging.getLogger(__name__)

HOMOGLYPH_MAP = {
    "а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "у": "y",
    "х": "x", "А": "A", "Е": "E", "О": "O", "Р": "P", "С": "C",
    "У": "Y", "Х": "X", "і": "i", "І": "I", "ѕ": "s", "Ѕ": "S",
    "α": "a", "ε": "e", "ρ": "p", "ο": "o", "τ": "t", "υ": "y",
    "ａ": "a", "ｂ": "b", "ｃ": "c", "ｄ": "d", "ｅ": "e",
}

DEFAULT_WATCHED = [
    "google.com", "facebook.com", "youtube.com", "instagram.com",
    "whatsapp.com", "telegram.org", "apple.com", "microsoft.com",
    "amazon.com", "paypal.com", "twitter.com", "x.com", "linkedin.com",
    "binance.com", "coinbase.com", "github.com", "discord.com",
    "netflix.com", "spotify.com", "tiktok.com",
]

try:
    from Levenshtein import distance as _lev
    def levenshtein(a: str, b: str) -> int:
        return _lev(a, b)
except ImportError:
    def levenshtein(a: str, b: str) -> int:
        if a == b:
            return 0
        if not a:
            return len(b)
        if not b:
            return len(a)
        prev = list(range(len(b) + 1))
        for i, ca in enumerate(a, 1):
            cur = [i] + [0] * len(b)
            for j, cb in enumerate(b, 1):
                cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb))
            prev = cur
        return prev[-1]


def _normalize(domain: str) -> str:
    return unicodedata.normalize("NFKD", domain)


def _strip_www(domain: str) -> str:
    d = domain.lower().strip()
    if d.startswith("www."):
        d = d[4:]
    return d


def _homoglyph_normalize(domain: str) -> str:
    result = []
    for ch in _normalize(domain):
        result.append(HOMOGLYPH_MAP.get(ch, ch))
    return "".join(result)


def _load_tranco() -> list[str]:
    path = Path("scoring/tranco_top500.json")
    if path.exists():
        try:
            data = json.loads(path.read_text())
            if isinstance(data, list):
                return data
        except Exception as e:
            logger.warning("Failed to load tranco list: %s", e)
    return DEFAULT_WATCHED


async def check(domain: str, watched_domains: list[str] = None) -> dict:
    result = {
        "domain": domain,
        "suspicious": False,
        "looks_like": None,
        "distance": None,
        "homoglyph": False,
        "reasons": [],
    }

    if not domain:
        return result

    if watched_domains is None:
        watched_domains = _load_tranco()

    bare = _strip_www(domain)

    parts = bare.split(".")
    registrable = ".".join(parts[-2:]) if len(parts) >= 2 else bare

    if registrable in watched_domains:
        return result

    homoglyph_normalized = _homoglyph_normalize(registrable)

    closest, closest_dist = None, 99
    for watched in watched_domains:
        w_bare = _strip_www(watched)
        dist = levenshtein(homoglyph_normalized, w_bare)
        if dist < closest_dist:
            closest, closest_dist = w_bare, dist

    if closest and 0 < closest_dist <= 2 and not bare.endswith("." + closest):
        result["suspicious"] = True
        result["looks_like"] = closest
        result["distance"] = closest_dist
        result["reasons"].append(f"distance {closest_dist} from {closest}")

    nfkd_original = _normalize(bare)
    if nfkd_original != bare:
        nfkd_parts = nfkd_original.split(".")
        nfkd_reg = ".".join(nfkd_parts[-2:]) if len(nfkd_parts) >= 2 else nfkd_original
        if nfkd_reg in watched_domains:
            result["suspicious"] = True
            result["homoglyph"] = True
            if "homoglyph attack detected" not in result["reasons"]:
                result["reasons"].append("homoglyph attack detected")

    if _homoglyph_normalize(registrable) != registrable:
        for watched in watched_domains:
            if _homoglyph_normalize(registrable) == _strip_www(watched):
                result["suspicious"] = True
                result["homoglyph"] = True
                if "homoglyph attack detected" not in result["reasons"]:
                    result["reasons"].append("homoglyph attack detected")
                break

    return result
