import logging
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

DANGEROUS_EXTENSIONS = frozenset({
    ".exe", ".scr", ".bat", ".cmd", ".com", ".cpl", ".msi",
    ".jar", ".apk", ".ipa", ".dmg", ".pkg", ".deb", ".rpm",
    ".vbs", ".vbe", ".js", ".jse", ".wsf", ".wsh", ".ps1",
    ".lnk", ".reg", ".iso", ".img", ".vhd", ".hta", ".crt",
    ".html", ".htm", ".svg", ".lnk", ".chm", ".pif",
    ".application", ".gadget", ".msc", ".inf", ".ins", ".isp",
    ".job", ".ws",
})


class ExtensionGuard:
    @staticmethod
    def is_dangerous_extension(path: str) -> str | None:
        if not path:
            return None
        path_lower = path.lower().strip()
        idx = path_lower.rfind(".")
        if idx == -1:
            return None
        ext = path_lower[idx:]
        if ext in DANGEROUS_EXTENSIONS:
            return ext
        return None


async def check(url: str) -> dict:
    result = {
        "url": url,
        "dangerous": False,
        "extension": None,
        "risk_added": 0,
    }

    if not url:
        return result

    parsed = urlparse(url)
    path = parsed.path

    ext = ExtensionGuard.is_dangerous_extension(path)
    if ext:
        result["dangerous"] = True
        result["extension"] = ext
        result["risk_added"] = 40

    return result
