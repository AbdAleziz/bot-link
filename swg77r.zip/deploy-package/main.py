# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import logging
import os
import sys
from datetime import datetime
from urllib.parse import urlparse

_PORT = os.getenv("PORT")
if _PORT:
    os.environ["WEB_PORT"] = _PORT
    os.environ["MCP_PORT"] = str(int(_PORT) + 1)

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQuery,
    InlineQueryResultArticle,
    InputTextMessageContent,
    LabeledPrice,
    Message,
)

from admin_panel import AdminPanel
from config import Config
from database import Database
from logging_setup import LoggerSetup
from qr_system import QRSystem
from queue_system import task_queue, QueueTask, TaskPriority
from rate_limiter import rate_limiter
from rbac import RBAC, Role
from scanner import Scanner
from vip_system import VipSystem
from web_dashboard import WebDashboard
from click_tracker import ClickTracker
from mcp_server import MCPServer
from config.payment_config import ENABLE_STARS_PAYMENT
from services.payment_flow import PaymentFlow, build_duration_keyboard
from backup_system import BackupManager
from invite_system import InviteSystem
import time
try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False
from datetime import timedelta
from logging_setup import log_audit

LoggerSetup.setup(json_format=Config.LOG_JSON)
logger = LoggerSetup.get_logger("main")

app = Client(
    "scanner_bot",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN,
    workers=8,
    sleep_threshold=15,
)

db = Database()
scanner = Scanner(db)
qr_system = QRSystem(db)
vip_system = VipSystem(db)
click_tracker = ClickTracker(db)
admin_panel = AdminPanel(db)
backup_manager = BackupManager()
invite_system = InviteSystem(db, vip_system)
dashboard = None
mcp = None

QR_WIZARD = {}
VCARD_WIZARD = {}

STAGING_APP: Client | None = None

def main_menu_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔍 Scan Link", callback_data="nav_scan")],
        [InlineKeyboardButton("📱 QR Tools", callback_data="nav_qrmenu")],
        [InlineKeyboardButton("👤 My Account", callback_data="nav_account")],
        [InlineKeyboardButton("⭐ Upgrade to VIP", callback_data="nav_vip")],
        [InlineKeyboardButton("🔗 Invite & Earn VIP", callback_data="nav_invite")],
        [InlineKeyboardButton("🛠️ Support", callback_data="nav_support")],
    ])

def back_home_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
    ])

def qr_menu_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔗 URL → QR Code", callback_data="qr_url")],
        [InlineKeyboardButton("🖼️ Decode QR Image", callback_data="qr_decode")],
        [InlineKeyboardButton("📇 vCard → QR", callback_data="qr_vcard")],
        [InlineKeyboardButton("📊 QR Analytics", callback_data="qr_analytics")],
        [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
    ])

def qr_color_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⚫ Black", callback_data="qrcolor_000000"),
         InlineKeyboardButton("🔴 Red", callback_data="qrcolor_FF0000")],
        [InlineKeyboardButton("🔵 Blue", callback_data="qrcolor_0000FF"),
         InlineKeyboardButton("🟢 Green", callback_data="qrcolor_00FF00")],
        [InlineKeyboardButton("🟣 Purple", callback_data="qrcolor_800080"),
         InlineKeyboardButton("🟠 Orange", callback_data="qrcolor_FFA500")],
        [InlineKeyboardButton("Custom Color", callback_data="qrcolor_custom")],
        [InlineKeyboardButton("⬅️ Back", callback_data="nav_qrmenu")],
    ])

def qr_logo_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Yes, add logo", callback_data="qrlogo_yes")],
        [InlineKeyboardButton("❌ No logo", callback_data="qrlogo_no")],
        [InlineKeyboardButton("⬅️ Back", callback_data="nav_qrmenu")],
    ])

def scan_again_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔍 Scan Another", callback_data="nav_scan"),
         InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
    ])

def scan_result_kb(domain: str):
    safe_domain = (domain or "")[:55]
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🚩 إبلاغ عن الرابط", callback_data=f"report_{safe_domain}"),
         InlineKeyboardButton("👁 راقب هذا الدومين", callback_data=f"watch_{safe_domain}")],
        [InlineKeyboardButton("🔍 Scan Another", callback_data="nav_scan"),
         InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
    ])

def vip_pay_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💳 Pay via Google Pay", callback_data="vip_pay")],
        [InlineKeyboardButton("🔙 Back", callback_data="nav_home")],
    ])

def upgrade_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⭐ Upgrade to VIP", callback_data="nav_vip")],
        [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
    ])

async def is_admin(uid: int) -> bool:
    return RBAC.is_admin(uid)

async def daily_scan_count(uid: int) -> int:
    today = datetime.utcnow().date().isoformat()
    row = await db.fetchval(
        "SELECT COUNT(*) FROM scan_history WHERE user_id = ? AND date(scanned_at) = ?",
        (uid, today),
    )
    return row or 0

async def is_vip(uid: int) -> bool:
    return await vip_system.is_vip(uid)

async def notify_domain_watchers(client: Client, domain: str, result: dict, exclude_uid: int = None):
    if not domain:
        return
    try:
        watchers = await db.fetch(
            "SELECT user_id FROM domain_watch WHERE domain = ?", (domain,)
        )
    except Exception as e:
        logger.error(f"Failed to fetch domain watchers for {domain}: {e}")
        return

    if not watchers:
        return

    new_label = "🚫 خطر" if result.get("is_threat") else "✅ آمن"
    text = (
        f"👁 <b>تحديث مراقبة الدومين</b>\n"
        f"🌐 {domain}\n"
        f"📊 التصنيف الجديد: {new_label}\n"
        f"⭐ الثقة: {result.get('trust_score', 0):.1f}%\n"
    )
    for row in watchers:
        watcher_id = row["user_id"]
        if exclude_uid and watcher_id == exclude_uid:
            continue
        try:
            await client.send_message(watcher_id, text)
        except Exception as e:
            logger.warning(f"Could not notify watcher {watcher_id}: {e}")

def format_scan_result(result: dict) -> str:
    emoji = "✅" if not result.get("is_threat") else "🚫"
    status_text = "✅ Safe" if not result.get("is_threat") else f"🚫 Threat ({result.get('threat_type', 'Unknown')})"
    text = (
        f"{emoji} <b>Scan Result</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"🔗 URL: <code>{result.get('url', '')[:100]}</code>\n"
        f"🌐 Domain: {result.get('domain', '')}\n"
        f"📊 Status: {status_text}\n"
        f"⭐ Trust: {result.get('trust_score', 0):.1f}%\n"
    )
    checks = result.get("checks", {})
    vt = checks.get("virustotal", {})
    if isinstance(vt, dict) and vt.get("positives") is not None:
        text += f"🦠 VirusTotal: {vt.get('positives', 0)} positives\n"
    ssl_check = checks.get("ssl", {})
    if isinstance(ssl_check, dict):
        ssl_status = "✅ Valid" if ssl_check.get("valid") else "❌ Invalid"
        text += f"🔐 SSL: {ssl_status}\n"
    whois = checks.get("whois", {})
    if isinstance(whois, dict) and whois.get("registrar"):
        text += f"📅 WHOIS: {whois.get('registrar', '')[:50]}\n"
        if whois.get("age_days"):
            text += f"📆 Domain age: {whois['age_days']} days\n"

    typo = checks.get("typosquatting", {})
    if isinstance(typo, dict) and typo.get("suspicious"):
        text += f"🎭 Typosquatting: يشبه <b>{typo.get('looks_like', '')}</b> (فرق {typo.get('distance', '?')} حرف)\n"

    homograph = checks.get("homograph", {})
    if isinstance(homograph, dict) and homograph.get("suspicious"):
        flags = ", ".join(homograph.get("flags", []))
        text += f"🔤 تحذير Unicode/Homograph: {flags}\n"

    reports = checks.get("community_reports", {})
    if isinstance(reports, dict) and reports.get("count", 0) > 0:
        text += f"🚩 بلاغات المستخدمين: {reports['count']}\n"

    if result.get("reclassified"):
        prev_label = "🚫 خطر" if result.get("previous_verdict") else "✅ آمن"
        new_label = "🚫 خطر" if result.get("is_threat") else "✅ آمن"
        text += f"\n⚠️ <b>تنبيه:</b> تصنيف هذا الرابط تغيّر من {prev_label} إلى {new_label} منذ آخر فحص!\n"

    text += f"\n🕐 {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC"
    return text

@app.on_message(filters.command("start"))
async def start_cmd(client: Client, message: Message):
    user = message.from_user
    await db.execute(
        "INSERT OR IGNORE INTO users (user_id, username, first_name, last_name, joined_at) VALUES (?, ?, ?, ?, ?)",
        (user.id, user.username or "", user.first_name or "", user.last_name or "",
         datetime.utcnow().isoformat()),
    )
    banned = await db.fetchrow("SELECT * FROM banned_users WHERE user_id = ?", (user.id,))
    if banned:
        await message.reply("🚫 You are banned from using this bot.")
        return

    args = message.text.split(maxsplit=1)
    if len(args) > 1:
        arg = args[1].strip()
        if arg.startswith("invite_"):
            code = arg[7:]
            joiner_data = {"user": message.from_user}
            result = await invite_system.process_invite(user.id, code, joiner_data, client)
            if result.get("success"):
                await message.reply(
                    "🎉 <b>مرحباً بك!</b>\n"
                    "━━━━━━━━━━━━━━\n"
                    "تم تسجيل دخولك عبر رابط الدعوة بنجاح.\n"
                    "صاحب الرابط حصل على يوم VIP كمكافأة!\n"
                    "━━━━━━━━━━━━━━\n"
                    "استمتع بميزات البوت:",
                    reply_markup=main_menu_kb(),
                )
                return
            else:
                await message.reply(
                    f"❌ {result.get('reason', 'حدث خطأ')}",
                    reply_markup=main_menu_kb(),
                )
                return
        try:
            qr_code = arg
            link = await click_tracker.resolve_short_url(qr_code)
            if link:
                result = await scanner.scan_url(link, user.id)
                await message.reply(format_scan_result(result), reply_markup=scan_again_kb())
                return
        except Exception:
            pass

    await message.reply(
        "🤖 <b>Welcome to QR & Link Scanner Bot</b>\n\n"
        "Choose from the menu below:\n"
        "━━━━━━━━━━━━━━\n"
        "© 2026 AbdAleziz | @AbdAleziz_1",
        reply_markup=main_menu_kb(),
    )

@app.on_callback_query(filters.regex(r"^nav_"))
async def nav_callback(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    action = cb.data[4:]

    if action in ("home", "back_main"):
        await cb.message.edit(
            "🤖 <b>Welcome to QR & Link Scanner Bot</b>\n\n"
            "Choose from the menu below:",
            reply_markup=main_menu_kb(),
        )

    elif action == "scan":
        await cb.message.edit(
            "🔗 <b>Scan a Link</b>\n\n"
            "Send me a URL and I will scan it with VirusTotal and other security checks.",
            reply_markup=back_home_kb(),
        )

    elif action == "qrmenu":
        await cb.message.edit(
            "📱 <b>QR Code Tools</b>\n\n"
            "• Generate QR codes from URLs\n"
            "• Decode QR images\n"
            "• Create vCard QR codes\n"
            "• Track QR analytics",
            reply_markup=qr_menu_kb(),
        )

    elif action == "account":
        daily = await daily_scan_count(uid)
        vip = await is_vip(uid)
        if vip:
            row = await db.fetchrow("SELECT expires_at, plan FROM vip_users WHERE user_id = ?", (uid,))
            expires = row["expires_at"][:10] if row else "—"
            plan = row["plan"] if row else "—"
            atype = "⭐ VIP"
            limit_txt = "Unlimited"
        else:
            atype = "👤 Free"
            limit_txt = f"{daily}/{Config.FREE_DAILY_LIMIT}"
            expires = "—"
            plan = "—"
        invite_stats = await invite_system.get_invite_stats(uid)
        await cb.message.edit(
            f"👤 <b>My Account</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"🆔 ID: <code>{uid}</code>\n"
            f"📋 Type: {atype}\n"
            f"🔍 Today's scans: {limit_txt}\n"
            f"📅 VIP expires: {expires}\n"
            f"📋 Plan: {plan}\n"
            f"━━━━━━━━━━━━━━\n"
            f"🔗 <b>Invite System:</b>\n"
            f"👥 Invited: {invite_stats['total_uses']}\n"
            f"⭐ Rewards: {invite_stats['total_rewards']} day(s) VIP\n"
            f"⚠️ Warnings: {invite_stats['warnings']}\n"
            f"━━━━━━━━━━━━━━\n"
            f"Use /invite to get your invite link!",
            reply_markup=back_home_kb(),
        )

    elif action == "vip":
        if ENABLE_STARS_PAYMENT:
            if await is_vip(uid):
                row = await db.fetchrow("SELECT expires_at FROM vip_users WHERE user_id = ?", (uid,))
                await cb.message.edit(
                    f"⭐ <b>You are already VIP!</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"✅ Active until {row['expires_at'][:10]}\n"
                    f"Enjoy exclusive features!",
                    reply_markup=back_home_kb(),
                )
            else:
                price_display = Config.VIP_PRICE_CENTS / 100
                await cb.message.edit(
                    f"⭐ <b>Upgrade to VIP</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"📌 Monthly: {Config.VIP_DURATION_DAYS} days\n"
                    f"💵 Price: {price_display:.2f} {Config.VIP_CURRENCY}\n\n"
                    f"✨ <b>Features:</b>\n"
                    f"• Unlimited link scanning\n"
                    f"• QR code generation\n"
                    f"• Bulk scanning\n"
                    f"• Personal API key\n"
                    f"• Priority support\n\n"
                    f"Click below to pay securely:",
                    reply_markup=vip_pay_kb(),
                )
        else:
            if await is_vip(uid):
                row = await db.fetchrow("SELECT expires_at FROM vip_users WHERE user_id = ?", (uid,))
                await cb.message.edit(
                    f"⭐ <b>You are already VIP!</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"✅ Active until {row['expires_at'][:10]}",
                    reply_markup=back_home_kb(),
                )
            else:
                await cb.message.edit(
                    "⭐ <b>Upgrade to VIP</b>\n"
                    "━━━━━━━━━━━━━━\n"
                    "Choose your subscription plan:",
                    reply_markup=build_duration_keyboard(),
                )

    elif action == "invite":
        await cb.message.edit(
            f"🔗 <b>Invite & Earn VIP</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"👤 كل شخص يدخل عبر رابطك تحصل على <b>يوم VIP</b> مجاني!\n\n"
            f"استخدم الأمر /invite للحصول على رابط الدعوة الخاص بك.\n"
            f"━━━━━━━━━━━━━━\n"
            f"⚠️ الرابط محمي من الرشق - فقط الأشخاص الحقيقيين!",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔗 Get My Invite Link", callback_data="invite_gen")],
                [InlineKeyboardButton("📊 My Invite Stats", callback_data="invite_stats")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
            ]),
        )
        await cb.answer()
        return

    elif action == "support":
        await cb.message.edit(
            "🛠️ <b>Support & Help</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"For support, contact the developer:\n\n"
            f"👤 <a href=\"tg://user?id={Config.PRIMARY_ADMIN_ID}\">Click here</a>\n\n"
            f"Or send your message and we will get back to you.",
            reply_markup=back_home_kb(),
        )

    await cb.answer()

@app.on_message(filters.text & filters.private & ~filters.command(["start", "help", "r", "myapi", "grantvip", "panel", "stats", "ban", "unban", "broadcast", "export", "import", "logs", "restart", "clearcache", "addadmin", "deladmin", "vip", "bulkscan", "domainwatch", "whitelist", "report", "invite", "myinvites", "trial", "trial_reset", "backup", "backups", "backupstatus", "health", "language", "pricing_panel", "selfscan", "serverstats", "whoami"]))
async def handle_text(client: Client, message: Message):
    uid = message.from_user.id

    ok = await rate_limiter.check(uid)
    if not ok:
        ban_remaining = await rate_limiter.get_ban_remaining(uid)
        await message.reply(
            f"⏳ You are rate limited. Try again in {ban_remaining} seconds.",
        )
        return

    banned = await db.fetchrow("SELECT * FROM banned_users WHERE user_id = ?", (uid,))
    if banned:
        await message.reply("🚫 You are banned.")
        return

    text = message.text.strip()

    if uid in QR_WIZARD:
        step = QR_WIZARD[uid]
        if step == "awaiting_url":
            QR_WIZARD[uid] = {"url": text, "step": "awaiting_color"}
            await message.reply(
                "🎨 Choose QR code color:",
                reply_markup=qr_color_kb(),
            )
            return
        elif step == "awaiting_custom_color":
            try:
                if len(text) == 6 or (len(text) == 7 and text.startswith("#")):
                    color = text.lstrip("#")
                    int(color, 16)
                    QR_WIZARD[uid]["color"] = color
                    QR_WIZARD[uid]["step"] = "awaiting_logo"
                    await message.reply(
                        "📎 Add logo to QR code?",
                        reply_markup=qr_logo_kb(),
                    )
                    return
                else:
                    await message.reply("❌ Invalid color. Use hex format (e.g., FF0000 for red).")
                    return
            except ValueError:
                await message.reply("❌ Invalid hex color. Use format like FF0000.")
                return
        else:
            QR_WIZARD.pop(uid, None)

    if uid in VCARD_WIZARD:
        step = VCARD_WIZARD[uid].get("step")
        if step == "awaiting_name":
            VCARD_WIZARD[uid]["name"] = text
            VCARD_WIZARD[uid]["step"] = "awaiting_phone"
            await message.reply("📞 Enter phone number (or /skip):")
            return
        elif step == "awaiting_phone":
            if text != "/skip":
                VCARD_WIZARD[uid]["phone"] = text
            VCARD_WIZARD[uid]["step"] = "awaiting_email"
            await message.reply("📧 Enter email (or /skip):")
            return
        elif step == "awaiting_email":
            if text != "/skip":
                VCARD_WIZARD[uid]["email"] = text
            VCARD_WIZARD[uid]["step"] = "awaiting_org"
            await message.reply("🏢 Enter organization (or /skip):")
            return
        elif step == "awaiting_org":
            if text != "/skip":
                VCARD_WIZARD[uid]["org"] = text
            VCARD_WIZARD[uid]["step"] = "done"
            await message.reply(
                "📇 Add logo to vCard QR?",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("✅ Yes, with logo", callback_data="vcard_logoyes")],
                    [InlineKeyboardButton("❌ No logo", callback_data="vcard_logono")],
                    [InlineKeyboardButton("⬅️ Back", callback_data="nav_qrmenu")],
                ]),
            )
            return
        elif step == "done":
            await message.reply(
                "📇 Use the buttons above to finish creating your vCard QR.",
            )
            return

    if not (text.startswith("http://") or text.startswith("https://") or "." in text):
        await message.reply(
            "❌ That doesn't look like a valid URL.\n"
            "Please send a valid URL or use the menu below:",
            reply_markup=main_menu_kb(),
        )
        return

    if not await is_vip(uid):
        daily = await daily_scan_count(uid)
        if daily >= Config.FREE_DAILY_LIMIT:
            await message.reply(
                f"❌ <b>Daily free limit reached</b>\n\n"
                f"📊 Today: {daily}/{Config.FREE_DAILY_LIMIT}\n\n"
                f"⭐ Upgrade to VIP for unlimited scans:",
                reply_markup=upgrade_kb(),
            )
            return

    sent = await message.reply("🔍 Scanning link...")
    try:
        result = await asyncio.wait_for(
            scanner.scan_url(text, uid, priority=await is_vip(uid)),
            timeout=Config.SCAN_TIMEOUT + 2,
        )
        await sent.edit(format_scan_result(result), reply_markup=scan_result_kb(result.get("domain", "")))
        if result.get("reclassified"):
            await notify_domain_watchers(client, result.get("domain", ""), result, exclude_uid=uid)
    except asyncio.TimeoutError:
        await sent.edit(
            "⏰ Scan timeout. The URL is too slow to respond.",
            reply_markup=scan_again_kb(),
        )
    except Exception as e:
        logger.error(f"Scan error for {text}: {e}")
        await sent.edit(
            f"❌ Scan error: {str(e)[:200]}",
            reply_markup=scan_again_kb(),
        )

@app.on_message(filters.photo & filters.private)
async def handle_photo(client: Client, message: Message):
    uid = message.from_user.id

    banned = await db.fetchrow("SELECT * FROM banned_users WHERE user_id = ?", (uid,))
    if banned:
        await message.reply("🚫 You are banned.")
        return

    sent = await message.reply("🖼️ Decoding QR code...")
    try:
        path = await message.download()
        with open(path, "rb") as f:
            img_bytes = f.read()
        os.remove(path)

        decoded = await qr_system.decode_qr(img_bytes)
        if decoded:
            classification = qr_system.classify_qr_content(decoded)
            text = (
                f"{classification['icon']} <b>نوع المحتوى:</b> {classification['label']}\n"
                f"<code>{decoded[:500]}</code>\n"
            )

            if classification["type"] == "url":
                result = await scanner.scan_url(decoded, uid)
                text += f"\n━━━━━━━━━━━━━━\n"
                text += format_scan_result(result)
                await sent.edit(text, reply_markup=scan_result_kb(result.get("domain", "")))
                if result.get("reclassified"):
                    await notify_domain_watchers(client, result.get("domain", ""), result, exclude_uid=uid)
            else:
                if classification["warning"]:
                    text += f"\n{classification['warning']}\n"
                await sent.edit(text, reply_markup=back_home_kb())

            await qr_system.track_qr_scan(hash(decoded) % 1000000, uid)
        else:
            await sent.edit(
                "❌ Could not decode QR code from this image.",
                reply_markup=back_home_kb(),
            )
    except Exception as e:
        logger.error(f"QR decode error: {e}")
        await sent.edit(
            f"❌ Error decoding QR: {str(e)[:200]}",
            reply_markup=back_home_kb(),
        )

@app.on_inline_query()
async def inline_query(client: Client, query: InlineQuery):
    input_str = query.query.strip()
    if not input_str:
        await query.answer(
            results=[],
            switch_pm_text="Send a URL to generate QR code",
            switch_pm_parameter="start",
        )
        return

    results = []
    if input_str.startswith(("http://", "https://")):
        results.append(
            InlineQueryResultArticle(
                title="Generate QR Code",
                description=f"Create QR for: {input_str[:50]}",
                input_message_content=InputTextMessageContent(
                    f"🔗 <b>QR Code for:</b>\n<code>{input_str}</code>\n\n"
                    f"⏳ Generating..."
                ),
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")]
                ]),
            )
        )

        qr_bytes = await qr_system.generate_qr(input_str)
        if qr_bytes:
            import io
            result = InlineQueryResultArticle(
                title="Generate QR Code",
                description=f"QR for: {input_str[:50]}",
                input_message_content=InputTextMessageContent(
                    f"🔗 <b>QR Code for:</b>\n<code>{input_str}</code>"
                ),
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔍 Scan Link", callback_data=f"scan_{input_str[:100]}")],
                    [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")]
                ]),
            )
            results[0] = result

    await query.answer(results, cache_time=1, is_personal=True)

@app.on_callback_query(filters.regex(r"^qr_"))
async def qr_callbacks(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    action = cb.data[3:]

    if action == "url":
        QR_WIZARD[uid] = {"step": "awaiting_url"}
        await cb.message.edit(
            "🔗 <b>URL → QR Code</b>\n\n"
            "Send me the URL you want to convert to QR code.\n"
            "It will also be shortened automatically.",
            reply_markup=back_home_kb(),
        )

    elif action == "decode":
        await cb.message.edit(
            "🖼️ <b>Decode QR Image</b>\n\n"
            "Send me any QR code image and I will:\n"
            "1. Decode the QR code\n"
            "2. Scan the link via VirusTotal\n"
            "3. Return the result",
            reply_markup=back_home_kb(),
        )

    elif action == "vcard":
        VCARD_WIZARD[uid] = {"step": "awaiting_name"}
        await cb.message.edit(
            "📇 <b>vCard → QR Code</b>\n\n"
            "Let's create a vCard QR code step by step.\n\n"
            "Enter the contact's full name:",
            reply_markup=back_home_kb(),
        )

    elif action == "analytics":
        links = await click_tracker.get_all_links(limit=10)
        if not links:
            await cb.message.edit(
                "📊 <b>QR Analytics</b>\n\n"
                "No QR codes generated yet.\n"
                "Generate a QR code with URL → QR option first.",
                reply_markup=back_home_kb(),
            )
            await cb.answer()
            return

        text = "📊 <b>Recent QR Codes</b>\n━━━━━━━━━━━━━━\n"
        for link in links:
            clicks = link.get("clicks", 0)
            short = link.get("short_code", "")
            url = (link.get("original_url", "") or "")[:40]
            text += f"• <code>{short}</code> — {clicks} clicks\n  {url}\n"

        await cb.message.edit(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")]
            ]),
        )

    await cb.answer()

@app.on_callback_query(filters.regex(r"^qrcolor_"))
async def qr_color_callback(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    color = cb.data[8:]

    if color == "custom":
        QR_WIZARD[uid]["step"] = "awaiting_custom_color"
        await cb.message.edit(
            "🎨 Send your custom hex color (e.g., FF5722):",
            reply_markup=back_home_kb(),
        )
        await cb.answer()
        return

    QR_WIZARD[uid]["color"] = color
    QR_WIZARD[uid]["step"] = "awaiting_logo"
    await cb.message.edit(
        "📎 Add logo to QR code?",
        reply_markup=qr_logo_kb(),
    )
    await cb.answer()

@app.on_callback_query(filters.regex(r"^qrlogo_"))
async def qr_logo_callback(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    action = cb.data[7:]
    wizard = QR_WIZARD.get(uid)
    if not wizard or not isinstance(wizard, dict):
        await cb.answer("❌ Session expired. Start again.")
        return

    add_logo = action == "yes"
    url = wizard.get("url", "")
    color = wizard.get("color", Config.QR_DEFAULT_FG_COLOR)

    if not url:
        await cb.answer("❌ No URL found. Start again.")
        QR_WIZARD.pop(uid, None)
        return

    await cb.message.edit("⏳ Generating QR code...")
    try:
        qr_bytes, short_url = await qr_system.generate_short_url_qr(
            original_url=url,
            created_by=uid,
            fg_color=f"#{color}",
            add_logo=add_logo,
        )

        await cb.message.delete()
        import io
        await client.send_photo(
            uid,
            io.BytesIO(qr_bytes),
            caption=(
                f"✅ <b>QR Code Generated!</b>\n"
                f"━━━━━━━━━━━━━━\n"
                f"🔗 Short URL: <code>{short_url}</code>\n"
                f"🔗 Original: <code>{url[:80]}</code>\n"
                f"━━━━━━━━━━━━━━\n"
                f"Scan the QR code to visit the link."
            ),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📊 Track This QR", callback_data=f"qr_track_{short_url.split('/')[-1]}")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
            ]),
        )
    except Exception as e:
        logger.error(f"QR generation error: {e}")
        await client.send_message(
            uid, f"❌ Error generating QR: {str(e)[:200]}"
        )

    QR_WIZARD.pop(uid, None)
    await cb.answer()

@app.on_callback_query(filters.regex(r"^qr_track_"))
async def qr_track_callback(client: Client, cb: CallbackQuery):
    short_code = cb.data[9:]
    stats = await qr_system.get_qr_stats(short_code)
    if not stats:
        await cb.answer("❌ QR code not found.")
        return

    text = (
        f"📊 <b>QR Analytics</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"🔗 Destination: {stats.get('original_url', '')[:50]}\n"
        f"👁️ Total scans: {stats.get('total_clicks', 0)}\n"
        f"🌐 Unique IPs: {stats.get('unique_ips', 0)}\n"
        f"📅 Created: {stats.get('created_at', '')[:10]}\n"
        f"━━━━━━━━━━━━━━"
    )
    await cb.message.edit(text, reply_markup=back_home_kb())
    await cb.answer()

@app.on_callback_query(filters.regex(r"^vcard_"))
async def vcard_callback(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    action = cb.data[6:]

    if action == "generate":
        wizard = VCARD_WIZARD.get(uid)
        if not wizard:
            await cb.answer("❌ Session expired.")
            return

        await cb.message.edit("⏳ Generating vCard QR code...")
        try:
            qr_bytes = await qr_system.generate_vcard_qr(
                name=wizard.get("name", "Contact"),
                phone=wizard.get("phone", ""),
                email=wizard.get("email", ""),
                org=wizard.get("org", ""),
                add_logo=wizard.get("add_logo", False),
            )

            await cb.message.delete()
            if qr_bytes:
                import io
                vcard_text = (
                    f"📇 <b>vCard QR Code</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"👤 Name: {wizard.get('name', '')}\n"
                )
                if wizard.get("phone"):
                    vcard_text += f"📞 Phone: {wizard['phone']}\n"
                if wizard.get("email"):
                    vcard_text += f"📧 Email: {wizard['email']}\n"
                if wizard.get("org"):
                    vcard_text += f"🏢 Org: {wizard['org']}\n"
                vcard_text += "━━━━━━━━━━━━━━\nScan to save contact!"

                await client.send_photo(
                    uid,
                    io.BytesIO(qr_bytes),
                    caption=vcard_text,
                    reply_markup=back_home_kb(),
                )
            else:
                await client.send_message(
                    uid, "❌ Failed to generate vCard QR."
                )
        except Exception as e:
            logger.error(f"vCard QR error: {e}")
            await client.send_message(uid, f"❌ Error: {str(e)[:200]}")

        VCARD_WIZARD.pop(uid, None)

    elif action == "logoyes":
        if uid in VCARD_WIZARD:
            VCARD_WIZARD[uid]["add_logo"] = True
        await cb.message.edit(
            "📇 Ready to generate vCard QR with logo!",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ Generate vCard QR", callback_data="vcard_generate")],
                [InlineKeyboardButton("⬅️ Back", callback_data="nav_qrmenu")],
            ]),
        )

    elif action == "logono":
        if uid in VCARD_WIZARD:
            VCARD_WIZARD[uid]["add_logo"] = False
        await cb.message.edit(
            "📇 Ready to generate vCard QR!",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ Generate vCard QR", callback_data="vcard_generate")],
                [InlineKeyboardButton("⬅️ Back", callback_data="nav_qrmenu")],
            ]),
        )

    await cb.answer()

@app.on_callback_query(filters.regex(r"^vip_pay$"))
async def vip_pay_cb(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    if await is_vip(uid):
        await cb.answer("You are already VIP!", show_alert=True)
        return
    if not Config.PROVIDER_TOKEN:
        await cb.answer("Payment not available. Contact support.", show_alert=True)
        return
    prices = [LabeledPrice(label="VIP Monthly", amount=Config.VIP_PRICE_CENTS)]
    try:
        await client.send_invoice(
            chat_id=uid,
            title="VIP Subscription - Link Scanner",
            description=f"Subscription for {Config.VIP_DURATION_DAYS} days with unlimited features",
            payload=f"vip_{uid}_{int(datetime.utcnow().timestamp())}",
            provider_token=Config.PROVIDER_TOKEN,
            currency=Config.VIP_CURRENCY,
            prices=prices,
            start_parameter="vip_subscription",
        )
    except Exception as e:
        logger.error(f"sendInvoice error: {e}")
        await cb.answer(f"Error: {str(e)[:50]}", show_alert=True)
    await cb.answer()

@app.on_pre_checkout_query()
async def pre_checkout_handler(client: Client, query):
    await query.answer(ok=True)

@app.on_message(filters.successful_payment)
async def payment_success(client: Client, message: Message):
    uid = message.from_user.id
    pay = message.successful_payment
    total = pay.total_amount / 100
    currency = pay.currency
    pid = f"INV-{uid}-{int(datetime.utcnow().timestamp())}"

    await vip_system.grant_vip(uid, "month")

    await message.reply(
        "✅ <b>Payment successful!</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"⭐ VIP activated for {Config.VIP_DURATION_DAYS} days\n"
        f"💰 {total:.2f} {currency}\n"
        f"🆔 {pid}\n"
        f"━━━━━━━━━━━━━━\n"
        f"Enjoy the exclusive features!"
    )

@app.on_message(filters.command("help"))
async def help_cmd(client: Client, message: Message):
    await message.reply(
        "📚 <b>Bot Help</b>\n\n"
        "This bot works entirely through interactive buttons.\n"
        "Send /start to open the main menu.\n\n"
        "You can send a URL directly to scan it.\n"
        "Send a QR image to decode it.\n\n"
        "<b>Commands:</b>\n"
        "/start - Main menu\n"
        "/help - This message\n"
        "/panel - Admin panel (admins only)\n"
        "/r <code> - Resolve a short URL\n"
        "/report <url> [reason] - Report a malicious/suspicious link\n"
        "/domainwatch add|remove|list <domain> - Get alerted if a domain's verdict changes\n"
        "/bulkscan <links, one per line> - Scan multiple links at once\n"
        "/invite - Get your personal invite link (earn 1 day VIP per referral)\n"
        "/myinvites - View your invite stats\n"
        "/trial - Activate trial VIP (once per user)",
        reply_markup=back_home_kb(),
    )

@app.on_message(filters.command("invite") & filters.private)
async def invite_cmd(client: Client, message: Message):
    uid = message.from_user.id
    banned = await db.fetchrow("SELECT * FROM banned_users WHERE user_id = ?", (uid,))
    if banned:
        await message.reply("🚫 You are banned.")
        return
    await invite_system.ensure_tables()
    result = await invite_system.generate_invite(uid)
    stats = await invite_system.get_invite_stats(uid)
    await message.reply(
        f"🔗 <b>رابط الدعوة الخاص بك</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"👤 كل شخص يدخل عبر رابطك تحصل على <b>يوم VIP</b> مجاني!\n\n"
        f"🔗 <code>{result['link']}</code>\n\n"
        f"📊 <b>إحصائياتك:</b>\n"
        f"• إجمالي الدعوات: {stats['total_uses']}\n"
        f"• المكافآت المحصلة: {stats['total_rewards']}\n"
        f"• التحذيرات: {stats['warnings']}\n"
        f"━━━━━━━━━━━━━━\n"
        f"⚠️ رابط الدعوة محمي من الرشق - فقط الأشخاص الحقيقيين!"
    )

@app.on_message(filters.command("myinvites") & filters.private)
async def myinvites_cmd(client: Client, message: Message):
    uid = message.from_user.id
    await invite_system.ensure_tables()
    stats = await invite_system.get_invite_stats(uid)
    invites = await db.fetch(
        "SELECT * FROM invite_links WHERE user_id = ? ORDER BY created_at DESC LIMIT 5", (uid,)
    )
    text = (
        f"📊 <b>إحصائيات الدعوات</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"🔗 إجمالي الدعوات: {stats['total_invites']}\n"
        f"👥 إجمالي الاستخدامات: {stats['total_uses']}\n"
        f"⭐ المكافآت المحصلة: {stats['total_rewards']} يوم VIP\n"
        f"⚠️ التحذيرات: {stats['warnings']}\n"
        f"━━━━━━━━━━━━━━\n"
    )
    if invites:
        text += "🆕 <b>آخر روابطك:</b>\n"
        for inv in invites[:3]:
            c = inv.get("code", "")[:12]
            u = inv.get("uses", 0)
            text += f"• <code>{c}...</code> — {u} استخدامات\n"
    await message.reply(text, reply_markup=back_home_kb())

@app.on_message(filters.command("r"))
async def resolve_short(client: Client, message: Message):
    text = message.text.split(maxsplit=1)
    if len(text) < 2:
        await message.reply("❌ Use: /r <short_code>")
        return
    code = text[1].strip()
    original = await click_tracker.resolve_short_url(code)
    if original:
        await message.reply(f"🔗 Original URL: {original}")
    else:
        await message.reply("❌ URL not found or expired")

@app.on_callback_query(filters.regex(r"^report_"))
async def report_callback(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    domain = cb.data[len("report_"):]
    if not domain:
        await cb.answer("❌ لا يوجد دومين لهذا الرابط", show_alert=True)
        return
    result = await scanner.report_url(url=domain, domain=domain, reported_by=uid, reason="via inline button")
    await cb.answer(
        f"✅ تم إرسال بلاغك عن {domain}\nإجمالي البلاغات: {result['total_reports']}",
        show_alert=True,
    )

@app.on_callback_query(filters.regex(r"^watch_"))
async def watch_callback(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    domain = cb.data[len("watch_"):]
    if not domain:
        await cb.answer("❌ لا يوجد دومين لهذا الرابط", show_alert=True)
        return
    try:
        await db.execute(
            "INSERT OR IGNORE INTO domain_watch (domain, user_id, added_at) VALUES (?, ?, ?)",
            (domain, uid, datetime.utcnow().isoformat()),
        )
        await cb.answer(f"👁 صرت تراقب {domain}. راح تنبَّه لو تغير تصنيفه.", show_alert=True)
    except Exception as e:
        await cb.answer(f"❌ خطأ: {str(e)[:100]}", show_alert=True)

@app.on_message(filters.command("report") & filters.private)
async def report_cmd(client: Client, message: Message):
    parts = message.text.split(maxsplit=2)
    if len(parts) < 2:
        await message.reply("❌ استخدام: /report <رابط> [سبب البلاغ]")
        return

    url = parts[1].strip()
    reason = parts[2].strip() if len(parts) > 2 else ""
    parsed = urlparse(url if "://" in url else "https://" + url)
    domain = parsed.netloc.lower()
    if not domain:
        await message.reply("❌ رابط غير صالح.")
        return

    result = await scanner.report_url(url=url, domain=domain, reported_by=message.from_user.id, reason=reason)
    await message.reply(
        f"🚩 تم تسجيل بلاغك عن <code>{domain}</code>\n"
        f"📊 إجمالي البلاغات لهذا الدومين: {result['total_reports']}",
        reply_markup=back_home_kb(),
    )

@app.on_message(filters.command("domainwatch") & filters.private)
async def domainwatch_cmd(client: Client, message: Message):
    uid = message.from_user.id
    parts = message.text.split(maxsplit=2)
    if len(parts) < 2:
        await message.reply(
            "👁 <b>مراقبة الدومينات</b>\n\n"
            "/domainwatch add <دومين> — راقب دومين وتنبَّه لو تغير تصنيفه\n"
            "/domainwatch remove <دومين> — أوقف المراقبة\n"
            "/domainwatch list — عرض قائمتك"
        )
        return

    sub = parts[1].lower()
    if sub == "list":
        rows = await db.fetch("SELECT domain FROM domain_watch WHERE user_id = ?", (uid,))
        if not rows:
            await message.reply("📭 ما عندك دومينات مراقَبة حاليًا.")
            return
        listing = "\n".join(f"• {r['domain']}" for r in rows)
        await message.reply(f"👁 <b>الدومينات المراقَبة:</b>\n{listing}")
        return

    if sub in ("add", "remove"):
        if len(parts) < 3:
            await message.reply(f"❌ استخدام: /domainwatch {sub} <دومين>")
            return
        domain = parts[2].strip().lower()
        if sub == "add":
            await db.execute(
                "INSERT OR IGNORE INTO domain_watch (domain, user_id, added_at) VALUES (?, ?, ?)",
                (domain, uid, datetime.utcnow().isoformat()),
            )
            await message.reply(f"👁 صرت تراقب <code>{domain}</code>. راح تنبَّه لو تغير تصنيفه.")
        else:
            await db.execute(
                "DELETE FROM domain_watch WHERE domain = ? AND user_id = ?", (domain, uid)
            )
            await message.reply(f"🗑 تم إيقاف مراقبة <code>{domain}</code>.")
        return

    await message.reply("❌ أمر غير معروف. استخدم add / remove / list")

@app.on_message(filters.command("bulkscan") & filters.private)
async def bulkscan_cmd(client: Client, message: Message):
    uid = message.from_user.id

    ok = await rate_limiter.check(uid)
    if not ok:
        await message.reply("⏳ تم تجاوز الحد المسموح، حاول لاحقًا.")
        return

    banned = await db.fetchrow("SELECT * FROM banned_users WHERE user_id = ?", (uid,))
    if banned:
        await message.reply("🚫 You are banned.")
        return

    raw = message.text.split(maxsplit=1)
    links_text = raw[1] if len(raw) > 1 else ""

    # Also allow replying to a message that contains a list of links
    if not links_text.strip() and message.reply_to_message and message.reply_to_message.text:
        links_text = message.reply_to_message.text

    if not links_text.strip():
        await message.reply(
            "❌ استخدام:\n/bulkscan\nرابط1\nرابط2\n...\n\n"
            f"(أو رد بالأمر على رسالة تحتوي على قائمة روابط — الحد الأقصى {Config.MAX_BATCH_SIZE} رابط)"
        )
        return

    links = [l.strip() for l in links_text.splitlines() if l.strip()]
    links = links[:Config.MAX_BATCH_SIZE]
    if not links:
        await message.reply("❌ ما لقيت أي روابط صالحة.")
        return

    vip = await is_vip(uid)
    if not vip:
        daily = await daily_scan_count(uid)
        remaining = max(0, Config.FREE_DAILY_LIMIT - daily)
        if len(links) > remaining:
            await message.reply(
                f"❌ عدد الروابط ({len(links)}) يتجاوز حصتك اليومية المتبقية ({remaining}).\n"
                f"ترقّ لـ VIP للفحص الجماعي غير المحدود:",
                reply_markup=upgrade_kb(),
            )
            return

    sent = await message.reply(f"🔍 جارٍ فحص {len(links)} رابط بالتوازي...")

    sem = asyncio.Semaphore(5)

    async def _scan_one(link: str) -> dict:
        async with sem:
            try:
                return await asyncio.wait_for(
                    scanner.scan_url(link, uid, priority=vip),
                    timeout=Config.SCAN_TIMEOUT + 2,
                )
            except Exception as e:
                return {"url": link, "error": str(e)}

    results = await asyncio.gather(*[_scan_one(l) for l in links])

    safe_count = sum(1 for r in results if not r.get("error") and not r.get("is_threat"))
    threat_count = sum(1 for r in results if not r.get("error") and r.get("is_threat"))
    error_count = sum(1 for r in results if r.get("error"))

    lines = [
        f"📊 <b>نتائج الفحص الجماعي</b> ({len(links)} رابط)",
        f"✅ آمن: {safe_count} | 🚫 خطر: {threat_count} | ⚠️ خطأ: {error_count}",
        "━━━━━━━━━━━━━━",
    ]
    for r in results:
        if r.get("error"):
            lines.append(f"⚠️ {r.get('url', '')[:60]} — خطأ: {r['error'][:60]}")
        else:
            icon = "🚫" if r.get("is_threat") else "✅"
            lines.append(f"{icon} {r.get('url', '')[:60]} — ثقة {r.get('trust_score', 0):.0f}%")

    report = "\n".join(lines)

    if len(report) > 3800:
        import io
        buf = io.BytesIO(report.encode("utf-8"))
        buf.name = "bulkscan_report.txt"
        await sent.delete()
        await message.reply_document(buf, caption=f"📊 نتائج فحص {len(links)} رابط")
    else:
        await sent.edit(report, reply_markup=scan_again_kb())

@app.on_message(filters.command("myapi") & filters.private)
async def myapi_cmd(client: Client, message: Message):
    uid = message.from_user.id
    if not await is_vip(uid):
        await message.reply("❌ VIP only feature.\nUse /vip to subscribe.")
        return
    key = await db.fetchrow("SELECT * FROM api_keys WHERE user_id = ?", (uid,))
    if not key:
        import secrets
        new_key = f"sb_{secrets.token_hex(16)}"
        await db.execute(
            "INSERT INTO api_keys (key, user_id, permissions, created_at) VALUES (?, ?, ?, ?)",
            (new_key, uid, "read", datetime.utcnow().isoformat()),
        )
        key = {"key": new_key}
    endpoint = f"{Config.WEB_URL}/api/scan"
    await message.reply(
        f"🔑 <b>Your API Key</b>\n\n"
        f"Key: <code>{key['key']}</code>\n"
        f"Endpoint: {endpoint}\n\n"
        f"<b>Usage:</b>\n"
        f"<pre>curl -X POST {endpoint} \\\n"
        f"  -H \"Authorization: Bearer {key['key']}\" \\\n"
        f"  -H \"Content-Type: application/json\" \\\n"
        f"  -d '{{\"url\":\"https://example.com\"}}'</pre>"
    )

BACKUPS_PAGE_SIZE = 5


@app.on_message(filters.command("backup") & filters.private)
async def backup_cmd(client: Client, message: Message):
    uid = message.from_user.id
    if not RBAC.is_admin(uid):
        return
    sent = await message.reply("⏳ Creating backup...")
    try:
        path = await backup_manager.create_backup(label="manual")
        caption = (
            f"📦 <b>Backup Created</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"📄 {path.name}\n"
            f"📏 {path.stat().st_size / 1024:.1f} KB"
        )
        await client.send_document(
            chat_id=message.chat.id,
            document=str(path),
            caption=caption,
        )
        await sent.delete()
    except Exception as e:
        logger.error(f"Manual backup failed: {e}")
        await sent.edit(f"❌ Backup failed: {str(e)[:200]}")


@app.on_message(filters.command("backups") & filters.private)
async def backups_list_cmd(client: Client, message: Message):
    uid = message.from_user.id
    if not RBAC.is_admin(uid):
        return
    backups = backup_manager.list_backups()
    if not backups:
        await message.reply("📂 No backups found.")
        return
    total = len(backups)
    page = 0
    buttons = []
    for b in backups[page * BACKUPS_PAGE_SIZE:(page + 1) * BACKUPS_PAGE_SIZE]:
        size_kb = b["size_bytes"] / 1024
        buttons.append([InlineKeyboardButton(
            f"{b['label']} — {size_kb:.1f} KB ({b['mtime_iso'][:10]})",
            callback_data=f"backup_view_{b['id']}",
        )])
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("◀️", callback_data=f"backup_page_{page - 1}"))
    nav.append(InlineKeyboardButton(f"📄 {page + 1}/{max(1, (total + BACKUPS_PAGE_SIZE - 1) // BACKUPS_PAGE_SIZE)}", callback_data="backup_info"))
    if (page + 1) * BACKUPS_PAGE_SIZE < total:
        nav.append(InlineKeyboardButton("▶️", callback_data=f"backup_page_{page + 1}"))
    if nav:
        buttons.append(nav)
    await message.reply(
        f"📂 <b>Available Backups</b> ({total})",
        reply_markup=InlineKeyboardMarkup(buttons),
    )


@app.on_callback_query(filters.regex(r"^backup_page_"))
async def backup_page_cb(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    if not RBAC.is_admin(uid):
        await cb.answer("❌ Unauthorized", show_alert=True)
        return
    page = int(cb.data.split("_")[-1])
    backups = backup_manager.list_backups()
    if not backups:
        await cb.answer("No backups.", show_alert=True)
        return
    total = len(backups)
    buttons = []
    for b in backups[page * BACKUPS_PAGE_SIZE:(page + 1) * BACKUPS_PAGE_SIZE]:
        size_kb = b["size_bytes"] / 1024
        buttons.append([InlineKeyboardButton(
            f"{b['label']} — {size_kb:.1f} KB ({b['mtime_iso'][:10]})",
            callback_data=f"backup_view_{b['id']}",
        )])
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("◀️", callback_data=f"backup_page_{page - 1}"))
    nav.append(InlineKeyboardButton(f"📄 {page + 1}/{max(1, (total + BACKUPS_PAGE_SIZE - 1) // BACKUPS_PAGE_SIZE)}", callback_data="backup_info"))
    if (page + 1) * BACKUPS_PAGE_SIZE < total:
        nav.append(InlineKeyboardButton("▶️", callback_data=f"backup_page_{page + 1}"))
    if nav:
        buttons.append(nav)
    await cb.message.edit(
        f"📂 <b>Available Backups</b> ({total})",
        reply_markup=InlineKeyboardMarkup(buttons),
    )
    await cb.answer()


@app.on_callback_query(filters.regex(r"^backup_view_"))
async def backup_view_cb(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    if not RBAC.is_admin(uid):
        await cb.answer("❌ Unauthorized", show_alert=True)
        return
    backup_id = cb.data[len("backup_view_"):]
    backups = backup_manager.list_backups()
    match = next((b for b in backups if b["id"] == backup_id), None)
    if not match:
        await cb.answer("❌ Backup not found.", show_alert=True)
        return
    size_kb = match["size_bytes"] / 1024
    text = (
        f"📦 <b>Backup Details</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"📄 File: {match['filename']}\n"
        f"🏷️ Label: {match['label']}\n"
        f"📏 Size: {size_kb:.1f} KB\n"
        f"🕐 Created: {match['mtime_iso']}\n"
        f"━━━━━━━━━━━━━━"
    )
    buttons = [
        [InlineKeyboardButton("⤓ Download", callback_data=f"backup_dl_{backup_id}"),
         InlineKeyboardButton("♻️ Restore", callback_data=f"backup_restore_{backup_id}")],
        [InlineKeyboardButton("🗑 Delete", callback_data=f"backup_del_{backup_id}")],
        [InlineKeyboardButton("🔙 Back to list", callback_data="backup_list")],
    ]
    await cb.message.edit(text, reply_markup=InlineKeyboardMarkup(buttons))
    await cb.answer()


@app.on_callback_query(filters.regex(r"^backup_restore_(?!yes_)"))
async def backup_restore_cb(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    if not RBAC.is_admin(uid):
        await cb.answer("❌ Unauthorized", show_alert=True)
        return
    backup_id = cb.data[len("backup_restore_"):]
    backups = backup_manager.list_backups()
    match = next((b for b in backups if b["id"] == backup_id), None)
    if not match:
        await cb.answer("❌ Backup not found.", show_alert=True)
        return
    text = (
        f"⚠️ <b>High Risk Operation</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"This will <b>OVERWRITE</b> the current bot state with:\n"
        f"📄 {match['filename']}\n\n"
        f"<b>Are you sure?</b>"
    )
    buttons = [
        [InlineKeyboardButton("⚠️ YES, restore", callback_data=f"backup_restore_yes_{backup_id}")],
        [InlineKeyboardButton("❌ Cancel", callback_data="backup_list")],
    ]
    await cb.message.edit(text, reply_markup=InlineKeyboardMarkup(buttons))
    await cb.answer()


@app.on_callback_query(filters.regex(r"^backup_restore_yes_"))
async def backup_restore_yes_cb(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    if not RBAC.is_admin(uid):
        await cb.answer("❌ Unauthorized", show_alert=True)
        return
    backup_id = cb.data[len("backup_restore_yes_"):]
    backups = backup_manager.list_backups()
    match = next((b for b in backups if b["id"] == backup_id), None)
    if not match:
        await cb.answer("❌ Backup not found.", show_alert=True)
        return
    await cb.answer("♻️ Restoring...", show_alert=False)
    archive_path = backup_manager.backup_dir / match["filename"]
    success = await backup_manager.restore_backup(archive_path, app)
    if success:
        text = "✅ <b>Restore completed.</b>\nRestarting..."
        await cb.message.edit(text)
        logger.info("Restore successful, stopping bot for restart")
        await app.stop()
    else:
        await cb.message.edit("❌ <b>Restore failed.</b>\nCheck logs for details.")


@app.on_callback_query(filters.regex(r"^backup_del_(?!yes_)"))
async def backup_delete_cb(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    if not RBAC.is_admin(uid):
        await cb.answer("❌ Unauthorized", show_alert=True)
        return
    backup_id = cb.data[len("backup_del_"):]
    backups = backup_manager.list_backups()
    match = next((b for b in backups if b["id"] == backup_id), None)
    if not match:
        await cb.answer("❌ Backup not found.", show_alert=True)
        return
    text = (
        f"🗑 <b>Delete Backup?</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"Are you sure you want to delete:\n"
        f"📄 {match['filename']}\n\n"
        f"This cannot be undone."
    )
    buttons = [
        [InlineKeyboardButton("✅ YES, delete", callback_data=f"backup_del_yes_{backup_id}")],
        [InlineKeyboardButton("❌ Cancel", callback_data=f"backup_view_{backup_id}")],
    ]
    await cb.message.edit(text, reply_markup=InlineKeyboardMarkup(buttons))
    await cb.answer()


@app.on_callback_query(filters.regex(r"^backup_del_yes_"))
async def backup_delete_yes_cb(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    if not RBAC.is_admin(uid):
        await cb.answer("❌ Unauthorized", show_alert=True)
        return
    backup_id = cb.data[len("backup_del_yes_"):]
    backups = backup_manager.list_backups()
    match = next((b for b in backups if b["id"] == backup_id), None)
    if not match:
        await cb.answer("❌ Backup not found.", show_alert=True)
        return
    ok = backup_manager.delete_backup(match["filename"])
    if ok:
        await cb.message.edit(f"✅ <b>Deleted:</b> {match['filename']}")
    else:
        await cb.message.edit(f"❌ <b>Failed to delete:</b> {match['filename']}")
    await cb.answer()


@app.on_callback_query(filters.regex(r"^backup_dl_"))
async def backup_download_cb(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    if not RBAC.is_admin(uid):
        await cb.answer("❌ Unauthorized", show_alert=True)
        return
    backup_id = cb.data[len("backup_dl_"):]
    backups = backup_manager.list_backups()
    match = next((b for b in backups if b["id"] == backup_id), None)
    if not match:
        await cb.answer("❌ Backup not found.", show_alert=True)
        return
    archive_path = backup_manager.backup_dir / match["filename"]
    await cb.answer("⤓ Sending...")
    try:
        caption = (
            f"📦 <b>Backup</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"📄 {match['filename']}\n"
            f"🏷️ {match['label']}\n"
            f"🕐 {match['mtime_iso']}"
        )
        await client.send_document(
            chat_id=uid,
            document=str(archive_path),
            caption=caption,
        )
    except Exception as e:
        logger.error(f"Backup download failed: {e}")
        await cb.message.reply(f"❌ Error: {str(e)[:200]}")


@app.on_callback_query(filters.regex(r"^backup_list$"))
async def backup_list_cb(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    if not RBAC.is_admin(uid):
        await cb.answer("❌ Unauthorized", show_alert=True)
        return
    await backups_list_cmd(client, cb.message)
    await cb.answer()


@app.on_callback_query(filters.regex(r"^backup_info$"))
async def backup_info_cb(client: Client, cb: CallbackQuery):
    await cb.answer()


@app.on_callback_query(filters.regex(r"^invite_"))
async def invite_callbacks(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    action = cb.data[7:]
    if action == "gen":
        await invite_system.ensure_tables()
        result = await invite_system.generate_invite(uid)
        stats = await invite_system.get_invite_stats(uid)
        await cb.message.edit(
            f"🔗 <b>رابط الدعوة الخاص بك</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"👤 كل شخص يدخل عبر رابطك تحصل على <b>يوم VIP</b> مجاني!\n\n"
            f"🔗 <code>{result['link']}</code>\n\n"
            f"📊 <b>إحصائياتك:</b>\n"
            f"• إجمالي الدعوات: {stats['total_uses']}\n"
            f"• المكافآت: {stats['total_rewards']} يوم VIP\n"
            f"• التحذيرات: {stats['warnings']}\n"
            f"━━━━━━━━━━━━━━\n"
            f"⚠️ رابط الدعوة محمي من الرشق!",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")]
            ]),
        )
    elif action == "stats":
        await invite_system.ensure_tables()
        stats = await invite_system.get_invite_stats(uid)
        await cb.message.edit(
            f"📊 <b>إحصائيات الدعوات</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"🔗 إجمالي الدعوات: {stats['total_invites']}\n"
            f"👥 إجمالي الاستخدامات: {stats['total_uses']}\n"
            f"⭐ المكافآت: {stats['total_rewards']} يوم VIP\n"
            f"⚠️ التحذيرات: {stats['warnings']}\n"
            f"━━━━━━━━━━━━━━",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔗 Get My Link", callback_data="invite_gen")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
            ]),
        )
    await cb.answer()

async def webhook_handler(request):
    from aiohttp import web
    try:
        data = await request.json()
        secret = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
        if Config.WEBHOOK_SECRET and secret != Config.WEBHOOK_SECRET:
            return web.Response(status=403)
        await app.process_update(data)
        return web.Response(status=200)
    except Exception as e:
        logger.error(f"Webhook error: {e}")
        return web.Response(status=500)

async def start_webhook():
    try:
        webhook_url = Config.WEBHOOK_URL
        if not webhook_url:
            public_url = os.getenv("PUBLIC_URL", "").rstrip("/")
            if public_url:
                webhook_url = public_url + Config.WEBHOOK_PATH
            else:
                logger.warning("No WEBHOOK_URL or PUBLIC_URL set, webhook disabled")
                return
        await app.set_webhook(
            url=webhook_url,
            secret_token=Config.WEBHOOK_SECRET or None,
            max_connections=40,
        )
        logger.info(f"Webhook set to {webhook_url}")
    except Exception as e:
        logger.error(f"Webhook setup failed: {e}")

async def start_dashboard():
    global dashboard
    try:
        dashboard = WebDashboard(db, bot=app)
        await dashboard.start()
        logger.info("Web dashboard started")
    except Exception as e:
        logger.error(f"Dashboard start failed: {e}")

async def start_mcp():
    global mcp
    try:
        mcp = MCPServer(bot=app, db=db, dashboard=dashboard, scanner=scanner)
        from aiohttp import web
        mcp_app = web.Application()
        async def mcp_handler(request):
            data = await request.json()
            result = await mcp.handle_request(data)
            return web.json_response(result)
        mcp_app.router.add_post("/mcp", mcp_handler)
        runner = web.AppRunner(mcp_app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", Config.MCP_PORT)
        await site.start()
        logger.info(f"MCP server on port {Config.MCP_PORT}")
    except Exception as e:
        logger.error(f"MCP server start failed: {e}")

async def notify_admins(client: Client, text: str, reply_markup=None):
    for admin_id in list(set(Config.SUDO_USERS + Config.SUB_DEVS)):
        try:
            await client.send_message(admin_id, text, reply_markup=reply_markup)
        except Exception as e:
            logger.error(f"Failed to notify admin {admin_id}: {e}")

async def start_staging_bot():
    global STAGING_APP
    if not Config.STAGING_ENABLED or not Config.STAGING_BOT_TOKEN:
        logger.info("Staging bot not configured, skipping")
        return

    try:
        STAGING_APP = Client(
            "staging_bot",
            api_id=Config.API_ID,
            api_hash=Config.API_HASH,
            bot_token=Config.STAGING_BOT_TOKEN,
            workers=4,
        )
        await STAGING_APP.start()
        bot_info = await STAGING_APP.get_me()
        logger.info(f"Staging bot started: @{bot_info.username}")

        @STAGING_APP.on_message(filters.command("start"))
        async def staging_start(client: Client, message: Message):
            await message.reply(
                "🧪 <b>Staging Bot</b>\n\n"
                "This is a testing environment for new features.\n"
                "Changes here may not reflect the production bot.",
            )

        @STAGING_APP.on_message(filters.command("panel"))
        async def staging_panel(client: Client, message: Message):
            uid = message.from_user.id
            if RBAC.is_admin(uid):
                await message.reply(
                    "🧪 <b>Staging Admin Panel</b>\n\n"
                    "Use this bot to test new features before release.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("📊 Stats", callback_data="adm_stats")],
                        [InlineKeyboardButton("🏠 Main", callback_data="nav_home")],
                    ]),
                )
    except Exception as e:
        logger.error(f"Staging bot failed: {e}")

async def cleanup_expired_links():
    while True:
        try:
            await click_tracker.cleanup_expired()
        except Exception as e:
            logger.error(f"Cleanup error: {e}")
        await asyncio.sleep(3600)



@app.on_message(filters.command("serverstats") & filters.user(Config.SUDO_USERS))
async def server_stats_cmd(client: Client, message: Message):
    """Show server performance stats (CPU, RAM, Disk, Uptime)."""
    import os
    ram_bytes = os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES') if hasattr(os, 'sysconf') else 0
    ram_gb = ram_bytes / (1024**3) if ram_bytes else 0
    
    try:
        import psutil
        cpu = psutil.cpu_percent(interval=0.5)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        boot = datetime.fromtimestamp(psutil.boot_time())
        uptime = datetime.utcnow() - boot.replace(tzinfo=None) if boot.tzinfo else datetime.now() - boot
        uptime_str = str(uptime).split('.')[0]
        text = (
            f"🖥️ <b>Server Statistics</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"⚡ CPU: {cpu}% ({psutil.cpu_count()} cores)\n"
            f"🧠 RAM: {mem.used/1024**3:.1f}GB / {mem.total/1024**3:.1f}GB ({mem.percent}%)\n"
            f"💾 Disk: {disk.used/1024**3:.1f}GB / {disk.total/1024**3:.1f}GB ({disk.percent}%)\n"
            f"⏱️ Uptime: {uptime_str}\n"
            f"🐍 Python: {os.sys.version.split()[0]}\n"
            f"━━━━━━━━━━━━━━\n"
            f"🤖 @AbdAleziz_1 | v{Config.BOT_VERSION}"
        )
    except ImportError:
        text = (
            f"🖥️ <b>Server Statistics</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"⚠️ psutil not installed\n"
            f"Install: pip install psutil\n"
            f"━━━━━━━━━━━━━━\n"
            f"🤖 @AbdAleziz_1 | v{Config.BOT_VERSION}"
        )
    
    await message.reply(text)
    await log_audit(db, message.from_user.id, "serverstats", details="Viewed server stats")


@app.on_message(filters.command("backupstatus") & filters.user(Config.SUDO_USERS))
async def backup_status_cmd(client: Client, message: Message):
    """Show backup system status."""
    backups = backup_manager.list_backups()
    total_size = sum(b["size_bytes"] for b in backups)
    last_backup = backups[0] if backups else None
    
    cloud_status = []
    if Config.BACKUP_CLOUD_S3_ENABLED:
        cloud_status.append("☁️ S3: configured")
    if Config.BACKUP_CLOUD_B2_ENABLED:
        cloud_status.append("☁️ B2: configured")
    if not cloud_status:
        cloud_status.append("☁️ Cloud: disabled")
    
    text = (
        f"📦 <b>Backup System Status</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"📂 Directory: {backup_manager.backup_dir}\n"
        f"📊 Total backups: {len(backups)}\n"
        f"💾 Total size: {total_size/1024:.1f} KB\n"
        f"🔐 Encryption: {'Enabled' if Config.BACKUP_ENCRYPT else 'Disabled'}\n"
        f"🔄 Auto backup: {'Enabled' if Config.BACKUP_AUTO_ENABLED else 'Disabled'} (hour {Config.BACKUP_AUTO_HOUR}:00 UTC)\n"
        f"🔄 Key rotation: every {Config.BACKUP_KEY_ROTATION_DAYS} days\n"
    )
    if last_backup:
        text += f"📅 Last backup: {last_backup['mtime_iso']} ({last_backup['label']})\n"
    text += "\n".join(cloud_status) + "\n"
    text += f"━━━━━━━━━━━━━━\n🤖 @AbdAleziz_1"
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 Backup Now", callback_data="bkp_now"),
         InlineKeyboardButton("📋 List Backups", callback_data="bkp_list")],
        [InlineKeyboardButton("🔍 Verify Last", callback_data="bkp_verify"),
         InlineKeyboardButton("⚙️ Settings", callback_data="bkp_settings")],
    ])
    
    await message.reply(text, reply_markup=keyboard)
    await log_audit(db, message.from_user.id, "backupstatus", details="Viewed backup status")


@app.on_callback_query(filters.regex(r"^bkp_"))
async def backup_status_cb(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    if not RBAC.is_admin(uid):
        await cb.answer("❌ Unauthorized", show_alert=True)
        return
    
    action = cb.data.replace("bkp_", "")
    
    if action == "now":
        await cb.message.edit("🔄 Creating backup...")
        try:
            path = await backup_manager.create_backup(label="manual")
            await cb.message.edit(f"✅ Backup created: {path.name}")
        except Exception as e:
            await cb.message.edit(f"❌ Backup failed: {e}")
    
    elif action == "list":
        backups = backup_manager.list_backups()
        if not backups:
            await cb.message.edit("📭 No backups found")
            await cb.answer()
            return
        text = "📋 <b>Backups:</b>\n━━━━━━━━━━━━━━\n"
        for i, b in enumerate(backups[:10], 1):
            text += f"{i}. {b['label']} | {b['size_bytes']/1024:.1f}KB | {b['mtime_iso'][:19]}\n"
        text += f"\n━━━━━━━━━━━━━━\n🤖 @AbdAleziz_1"
        await cb.message.edit(text)
    
    elif action == "verify":
        backups = backup_manager.list_backups()
        if not backups:
            await cb.message.edit("📭 No backups to verify")
            await cb.answer()
            return
        await cb.message.edit("🔄 Verifying latest backup...")
        result = await backup_manager.verify_backup(backup_manager.backup_dir / backups[0]["filename"])
        status = "✅ Valid" if result["valid"] else "❌ Invalid"
        text = (
            f"🔍 <b>Backup Verification</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"File: {backups[0]['filename']}\n"
            f"Status: {status}\n"
            f"SHA256: <code>{result.get('sha256', 'N/A')[:16]}...</code>\n"
            f"Files: {result.get('file_count', 0)}\n"
        )
        if result.get("errors"):
            text += "❌ Errors:\n" + "\n".join(f"• {e}" for e in result["errors"][:5])
        await cb.message.edit(text)
    
    elif action == "settings":
        text = (
            f"⚙️ <b>Backup Settings</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"Auto backup: {'✅' if Config.BACKUP_AUTO_ENABLED else '❌'}\n"
            f"Hour: {Config.BACKUP_AUTO_HOUR}:00 UTC\n"
            f"Keep last: {Config.BACKUP_KEEP_LAST}\n"
            f"Encryption: {'✅' if Config.BACKUP_ENCRYPT else '❌'}\n"
            f"Key rotation: {Config.BACKUP_KEY_ROTATION_DAYS}d\n"
            f"S3 cloud: {'✅' if Config.BACKUP_CLOUD_S3_ENABLED else '❌'}\n"
            f"B2 cloud: {'✅' if Config.BACKUP_CLOUD_B2_ENABLED else '❌'}\n"
        )
        await cb.message.edit(text)
    
    await cb.answer()


@app.on_message(filters.command("health"))
async def health_cmd(client: Client, message: Message):
    """System health check."""
    checks = []
    try:
        await db.fetchval("SELECT 1")
        checks.append("✅ Database: Connected")
    except Exception:
        checks.append("❌ Database: Disconnected")
    
    if backup_manager.backup_dir.exists():
        checks.append("✅ Backup dir: Exists")
    else:
        checks.append("❌ Backup dir: Missing")
    
    try:
        if HAS_PSUTIL:
            disk = psutil.disk_usage('/')
            checks.append(f"💾 Disk: {disk.percent}% used")
    except Exception:
        pass
    
    try:
        if HAS_PSUTIL:
            mem = psutil.virtual_memory()
            checks.append(f"🧠 RAM: {mem.percent}% used")
    except Exception:
        pass
    
    queue_depth = len(task_queue._queue) if hasattr(task_queue, '_queue') else 0
    checks.append(f"📊 Queue depth: {queue_depth}")
    checks.append(f"🤖 Bot version: {Config.BOT_VERSION}")
    
    text = "🩺 <b>Health Check</b>\n━━━━━━━━━━━━━━\n" + "\n".join(checks) + "\n━━━━━━━━━━━━━━"
    await message.reply(text)


@app.on_message(filters.command("language"))
async def language_cmd(client: Client, message: Message):
    uid = message.from_user.id
    from i18n import t
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🇸🇦 العربية", callback_data="lang_ar"),
         InlineKeyboardButton("🇬🇧 English", callback_data="lang_en")],
    ])
    await message.reply(t("language.prompt", lang="ar"), reply_markup=kb)


@app.on_callback_query(filters.regex(r"^lang_"))
async def lang_callback(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    lang = cb.data.split("_")[1]
    await db.execute(
        "INSERT OR REPLACE INTO user_language (user_id, lang) VALUES (?, ?)",
        (uid, lang)
    )
    from i18n import set_user_lang
    set_user_lang(uid, lang)
    await cb.answer(f"Language set to {'العربية' if lang == 'ar' else 'English'}")
    await cb.message.edit(
        f"🌐 Language changed to {'العربية' if lang == 'ar' else 'English'}.\n"
        f"Use /start to see the menu in your language."
    )


@app.on_message(filters.command("whoami"))
async def whoami_cmd(client: Client, message: Message):
    uid = message.from_user.id
    from i18n import t
    role = RBAC.get_role(uid)
    role_name = role.name
    vip = await vip_system.is_vip(uid)
    vip_info = None
    if vip:
        vip_info = await vip_system.get_vip_info(uid)
    daily = await daily_scan_count(uid)
    total_scans = await db.fetchval(
        "SELECT COUNT(*) FROM scan_history WHERE user_id = ?", (uid,)
    ) or 0
    lang_row = await db.fetchrow(
        "SELECT lang FROM user_language WHERE user_id = ?", (uid,)
    )
    lang = lang_row["lang"] if lang_row and "lang" in lang_row else "ar"
    user = await db.fetchrow(
        "SELECT joined_at FROM users WHERE user_id = ?", (uid,)
    )
    
    text = f"👤 <b>{t('whoami.title', lang)}</b>\n━━━━━━━━━━━━━━\n"
    text += f"{t('whoami.id', lang)}: <code>{uid}</code>\n"
    text += f"{t('whoami.role', lang)}: {role_name}\n"
    text += f"{t('whoami.vip', lang)}: {'✅ Active' if vip else '❌ Inactive'}\n"
    if vip_info:
        text += f"📅 Expires: {vip_info['expires_at'][:10]}\n"
        text += f"📋 Plan: {vip_info.get('plan', 'N/A')}\n"
    text += f"{t('whoami.scans', lang)}: {total_scans} (today: {daily})\n"
    text += f"{t('whoami.language', lang)}: {'العربية' if lang == 'ar' else 'English'}\n"
    if user:
        text += f"📅 Joined: {user['joined_at'][:10]}\n"
    await message.reply(text, reply_markup=back_home_kb())


@app.on_message(filters.command("selfscan") & filters.user(Config.SUDO_USERS))
async def selfscan_cmd(client: Client, message: Message):
    sent = await message.reply("🔍 Self-scanning project files...")
    try:
        from security.self_scan import SelfScanner
        scanner_mod = SelfScanner()
        results = scanner_mod.scan()
        report = "🔍 <b>Self-Scan Report</b>\n━━━━━━━━━━━━━━\n"
        if not results:
            report += "✅ No issues found.\n"
        else:
            for r in results:
                icon = {"LOW": "⚠️", "MEDIUM": "⚡", "HIGH": "🚨", "CRITICAL": "💥"}.get(r.get("severity", "LOW"), "⚠️")
                report += f"{icon} <b>{r['severity']}</b>: {r['file']}:{r.get('line', '?')}\n"
                report += f"  <code>{r.get('pattern', '')[:100]}</code>\n"
        report += f"━━━━━━━━━━━━━━\n🤖 @AbdAleziz_1"
        if len(report) > 4000:
            import io
            buf = io.BytesIO(report.encode())
            buf.name = "selfscan_report.txt"
            await sent.delete()
            await message.reply_document(buf, caption="🔍 Self-Scan Report")
        else:
            await sent.edit(report)
    except Exception as e:
        await sent.edit(f"❌ Self-scan failed: {e}")
    await log_audit(db, message.from_user.id, "selfscan", details="Ran self-scan")


@app.on_message(filters.command("pricing_panel") & filters.user(Config.SUDO_USERS))
async def pricing_panel_cmd(client: Client, message: Message):
    uid = message.from_user.id
    if not RBAC.is_admin(uid):
        await message.reply("❌ Admin only.")
        return
    try:
        from vip_extensions.pricing_admin import PricingAdmin
        pa = PricingAdmin(db)
        await pa.show_panel(client, message)
    except Exception as e:
        await message.reply(f"❌ Error: {e}")
    await log_audit(db, uid, "pricing_panel", details="Viewed pricing panel")


async def main():
    logger.info("Starting bot...")
    await db.init()

    # ── v3 upgrade: background subsystem initialisation ──────────────
    try:
        from ops.watchdog import MemoryWatchdog
        mem_watchdog = MemoryWatchdog(db=db)
        asyncio.create_task(mem_watchdog.run())
        logger.info("Memory watchdog started")
    except Exception as e:
        logger.warning(f"Memory watchdog init failed: {e}")

    try:
        from security.blacklist import BlacklistManager
        bl_manager = BlacklistManager()
        asyncio.create_task(bl_manager.start_auto_refresh(app))
        logger.info("Blacklist auto-refresh started")
    except Exception as e:
        logger.warning(f"Blacklist init failed: {e}")

    try:
        from ops.archive import ArchiveManager
        archive_mgr = ArchiveManager()
        asyncio.create_task(archive_mgr.schedule(db))
        logger.info("Archive scheduler started")
    except Exception as e:
        logger.warning(f"Archive init failed: {e}")

    try:
        from vip_extensions.reminders import start_reminder_loop
        asyncio.create_task(start_reminder_loop(app, db))
        logger.info("VIP reminder service started")
    except Exception as e:
        logger.warning(f"Reminder service init failed: {e}")

    try:
        from admin_extensions.csv_export import register_csv_export
        register_csv_export(app, db)
        logger.info("CSV export scheduler started")
    except Exception as e:
        logger.warning(f"CSV export init failed: {e}")

    await invite_system.ensure_tables()

    rate_limiter.start_cleanup()

    await task_queue.init_redis()

    async def task_handler(task: QueueTask):
        logger.info(f"Processing task: {task.name} ({task.id})")

    asyncio.create_task(task_queue.process_tasks(task_handler))

    await app.start()

    admin_panel.register(app)
    AdminPanel.register_admin_commands(app, db)

    from flood_captcha import FloodCaptcha
    flood = FloodCaptcha(db)
    flood.register(app)

    if ENABLE_STARS_PAYMENT:
        from vip_handlers import VipHandler
        VipHandler(db).register(app)
        logger.info("VIP: Telegram Stars payment mode")
    else:
        payment_flow = PaymentFlow(db, vip_system)
        payment_flow.register(app)
        logger.info("VIP: Iraqi manual payment mode")

    bot_info = await app.get_me()
    invite_system.set_bot_username(bot_info.username or "scanner_bot")
    logger.info(f"Bot started: @{bot_info.username}")

    if Config.ENABLE_DASHBOARD:
        asyncio.create_task(start_dashboard())
        await asyncio.sleep(1)

    if Config.STAGING_ENABLED:
        asyncio.create_task(start_staging_bot())

    from aiohttp import web

    if Config.WEBHOOK_MODE:
        webhook_app = web.Application()
        webhook_app.router.add_post(Config.WEBHOOK_PATH, webhook_handler)
        webhook_app.router.add_get("/health", lambda r: web.json_response({
            "status": "healthy",
            "mode": "webhook",
            "timestamp": datetime.utcnow().isoformat(),
        }))
        if dashboard:
            webhook_app.router.add_routes(dashboard.app.router.routes())
        runner = web.AppRunner(webhook_app)
        await runner.setup()
        site = web.TCPSite(runner, Config.WEB_HOST, Config.WEB_PORT)
        await site.start()
        logger.info(f"Webhook+dashboard on {Config.WEB_HOST}:{Config.WEB_PORT}")
        if Config.WEBHOOK_URL:
            await start_webhook()
        if dashboard and hasattr(dashboard, "runner") and dashboard.runner:
            await dashboard.runner.cleanup()
            dashboard.runner = None
    else:
        logger.info("Running in polling mode")

    if Config.ENABLE_MCP:
        asyncio.create_task(start_mcp())

    asyncio.create_task(cleanup_expired_links())

    if not ENABLE_STARS_PAYMENT:
        async def payment_cleanup_loop():
            while True:
                from services.payment_flow import PaymentFlow
                pf = PaymentFlow(db, vip_system)
                await pf.cleanup_expired_requests()
                await asyncio.sleep(300)
        asyncio.create_task(payment_cleanup_loop())

    LoggerSetup.set_alert_bot(app, Config.ALERT_LOG_CHANNEL)

    if Config.BACKUP_AUTO_ENABLED:
        backup_manager.init()
        try:
            await backup_manager.auto_recover(app)
        except Exception as e:
            logger.error(f"Auto-recovery failed: {e}")
        await backup_manager.start_scheduler(app)

    # ── v3 upgrade: register new handlers ────────────────────────────
    try:
        from vip_extensions.pricing_admin import register_pricing_admin
        register_pricing_admin(app, db)
        logger.info("Pricing admin registered")
    except Exception as e:
        logger.warning(f"Pricing admin init failed: {e}")

    try:
        from admin_extensions.audit_log import register_audit_log
        register_audit_log(app, db)
        logger.info("Audit log handlers registered")
    except Exception as e:
        logger.warning(f"Audit log init failed: {e}")

    try:
        from scanner_extensions.batch_scanner import register_batch_scanner
        register_batch_scanner(app, db)
        logger.info("Batch scanner registered")
    except Exception as e:
        logger.warning(f"Batch scanner init failed: {e}")

    try:
        from vip_extensions.trial_guard import register_trial_guard
        register_trial_guard(app, db)
        logger.info("Trial guard registered")
    except Exception as e:
        logger.warning(f"Trial guard init failed: {e}")

    # ── Support team system ────────────────────────────────────────────
    try:
        from support.handlers import register_support_handlers
        register_support_handlers(app, db)
        logger.info("Support handlers registered")
    except Exception as e:
        logger.warning(f"Support handlers init failed: {e}")

    if Config.SUPPORT_AUTO_CLOSE_HOURS > 0:
        try:
            from support.jobs import run_auto_close_loop
            asyncio.create_task(run_auto_close_loop(app, db))
            logger.info("Support auto-close job started")
        except Exception as e:
            logger.warning(f"Support auto-close init failed: {e}")

    logger.info("Bot is ready!")
    await idle()

    logger.info("Shutting down...")
    rate_limiter.stop()
    await task_queue.stop()
    if dashboard:
        await dashboard.stop()
    if STAGING_APP:
        await STAGING_APP.stop()
    await backup_manager.stop_scheduler()
    await scanner.close()
    await db.close()
    await app.stop()

if __name__ == "__main__":
    try:
        os.makedirs("data", exist_ok=True)
        os.makedirs("uploads", exist_ok=True)
        os.makedirs("static", exist_ok=True)
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except ImportError as e:
        logger.error(f"Missing module: {e}")
        logger.error("Run: pip install -r requirements.txt")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)
