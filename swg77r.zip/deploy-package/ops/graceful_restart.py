# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import json
import logging
import os
import sys
from datetime import datetime
from pathlib import Path

from config import Config

logger = logging.getLogger(__name__)


async def graceful_restart(app, db, queue):
    logger.info("Starting graceful restart...")

    await _save_pending_writes(queue)

    await db.close()

    await _flush_queue(queue)

    logger.info("State saved, re-spawning worker...")
    _re_spawn()


async def _save_pending_writes(queue):
    pending_dir = Path("data")
    pending_dir.mkdir(parents=True, exist_ok=True)
    pending_path = pending_dir / "pending_writes.jsonl"

    try:
        pending = []
        if hasattr(queue, "_queue"):
            while not queue._queue.empty():
                try:
                    item = queue._queue.get_nowait()
                    pending.append(item)
                except Exception:
                    break

        with open(pending_path, "w", encoding="utf-8") as f:
            for item in pending:
                f.write(json.dumps(item, ensure_ascii=False) + "\n")

        logger.info("Saved %d pending writes to %s", len(pending), pending_path)
    except Exception as e:
        logger.error("Failed to save pending writes: %s", e)


async def _flush_queue(queue):
    if hasattr(queue, "flush"):
        try:
            await queue.flush()
            logger.info("Queue flushed")
        except Exception as e:
            logger.error("Queue flush error: %s", e)


def _re_spawn():
    logger.info("Re-spawning process: %s", " ".join(sys.argv))
    try:
        import sdnotify
        sdnotify.SystemdNotifier().notify("RELOADING=1")
    except ImportError:
        pass
    os.execv(sys.executable, [sys.executable] + sys.argv)
