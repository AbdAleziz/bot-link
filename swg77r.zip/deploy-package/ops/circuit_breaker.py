# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import logging
import time
from enum import Enum
from functools import wraps

from config import Config

logger = logging.getLogger(__name__)


class CircuitState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    def __init__(self):
        self._state: dict[str, CircuitState] = {}
        self._failures: dict[str, list[float]] = {}
        self._open_until: dict[str, float] = {}
        self._locks: dict[str, asyncio.Lock] = {}
        self._lock = asyncio.Lock()

    async def _get_lock(self, service_name: str) -> asyncio.Lock:
        async with self._lock:
            if service_name not in self._locks:
                self._locks[service_name] = asyncio.Lock()
            return self._locks[service_name]

    def _get_state(self, service_name: str) -> CircuitState:
        state = self._state.get(service_name, CircuitState.CLOSED)
        if state == CircuitState.OPEN:
            open_until = self._open_until.get(service_name, 0)
            if time.monotonic() > open_until:
                self._state[service_name] = CircuitState.HALF_OPEN
                return CircuitState.HALF_OPEN
        return state

    async def _record_failure(self, service_name: str):
        now = time.monotonic()
        window = getattr(Config, "CB_FAILURE_THRESHOLD", 5)
        failures = self._failures.setdefault(service_name, [])
        failures.append(now)
        cutoff = now - 60
        self._failures[service_name] = [f for f in failures if f > cutoff]
        if len(self._failures[service_name]) >= window:
            self._state[service_name] = CircuitState.OPEN
            duration = getattr(Config, "CB_OPEN_DURATION_SEC", 30)
            self._open_until[service_name] = time.monotonic() + duration
            logger.warning(
                "Circuit breaker OPEN for %s (%d failures in 60s)",
                service_name,
                len(self._failures[service_name]),
            )

    def _on_success(self, service_name: str):
        self._failures.pop(service_name, None)
        self._state[service_name] = CircuitState.CLOSED
        self._open_until.pop(service_name, None)

    async def call(self, service_name: str, func, fallback=None):
        lock = await self._get_lock(service_name)
        async with lock:
            state = self._get_state(service_name)

            if state == CircuitState.OPEN:
                logger.debug("Circuit OPEN for %s, returning fallback", service_name)
                if fallback is not None:
                    return fallback() if callable(fallback) else fallback
                raise Exception(f"Circuit breaker open for {service_name}")

            try:
                result = await func()
                self._on_success(service_name)
                return result
            except Exception as e:
                await self._record_failure(service_name)
                if fallback is not None:
                    return fallback() if callable(fallback) else fallback
                raise


circuit_breaker = CircuitBreaker()


def with_circuit_breaker(service_name: str, fallback=None):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            async def _call():
                return await func(*args, **kwargs)
            return await circuit_breaker.call(service_name, _call, fallback=fallback)
        return wrapper
    return decorator
