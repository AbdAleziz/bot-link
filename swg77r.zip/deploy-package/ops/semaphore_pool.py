# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import logging

logger = logging.getLogger(__name__)

_DEFAULT_LIMITS = {
    "external_http": 20,
    "whois": 5,
    "db_write": 10,
}


class SemaphorePool:
    def __init__(self, limits: dict[str, int] | None = None):
        self._limits = limits or _DEFAULT_LIMITS
        self._semaphores: dict[str, asyncio.Semaphore] = {}

    def _get(self, pool_name: str) -> asyncio.Semaphore:
        if pool_name not in self._semaphores:
            limit = self._limits.get(pool_name, 10)
            self._semaphores[pool_name] = asyncio.Semaphore(limit)
            logger.debug("Created semaphore pool '%s' with limit %d", pool_name, limit)
        return self._semaphores[pool_name]

    async def acquire(self, pool_name: str):
        sem = self._get(pool_name)
        await sem.acquire()

    def release(self, pool_name: str):
        sem = self._get(pool_name)
        sem.release()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        pass


_pool = SemaphorePool()


async def acquire(pool_name: str):
    await _pool.acquire(pool_name)


def release(pool_name: str):
    _pool.release(pool_name)
