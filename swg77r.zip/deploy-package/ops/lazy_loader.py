# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import logging

logger = logging.getLogger(__name__)

_LOADED: dict[str, object] = {}


class LazyLoader:
    def __init__(self, name: str):
        self._name = name
        self._module = None

    def __getattr__(self, attr: str):
        if self._module is None:
            if self._name not in _LOADED:
                logger.debug("Lazy-loading module: %s", self._name)
                _LOADED[self._name] = __import__(self._name)
            self._module = _LOADED[self._name]
        return getattr(self._module, attr)

    def __bool__(self):
        return True


PIL = LazyLoader("PIL")
pyzbar = LazyLoader("pyzbar")
fpdf2 = LazyLoader("fpdf2")
whois = LazyLoader("whois")
qrcode = LazyLoader("qrcode")
httpx = LazyLoader("httpx")
psutil = LazyLoader("psutil")
