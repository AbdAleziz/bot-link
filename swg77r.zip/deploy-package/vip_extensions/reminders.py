import asyncio
import logging
from datetime import datetime, timedelta

from pyrogram import Client
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from config import Config
from database import Database

logger = logging.getLogger(__name__)


async def start_reminder_loop(app: Client, db: Database):
    await db.execute("""
        CREATE TABLE IF NOT EXISTS vip_reminders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            reminder_sent_at TEXT,
            created_at TEXT NOT NULL
        )
    """)

    while True:
        try:
            await _check_expiry_reminders(app, db)
        except Exception as e:
            logger.error(f"Reminder check error: {e}")
        await asyncio.sleep(3600)


async def _check_expiry_reminders(app: Client, db: Database):
    now = datetime.utcnow()
    three_days = now + timedelta(days=3)

    rows = await db.fetch(
        "SELECT vu.user_id, vu.expires_at, vu.plan "
        "FROM vip_users vu "
        "LEFT JOIN vip_reminders vr ON vu.user_id = vr.user_id "
        "WHERE vu.expires_at > ? AND vu.expires_at <= ? "
        "AND (vr.reminder_sent_at IS NULL OR vr.user_id IS NULL)",
        (now.isoformat(), three_days.isoformat()),
    )

    for row in rows:
        uid = row["user_id"]
        expires_at = row["expires_at"]
        plan = row.get("plan", "unknown")

        try:
            expires_dt = datetime.fromisoformat(expires_at)
            remaining = (expires_dt - now).days
            if remaining < 0:
                continue
        except Exception:
            continue

        try:
            text = (
                f"⏰ <b>تنبيه انتهاء الاشتراك</b>\n"
                f"━━━━━━━━━━━━━━\n"
                f"⭐ باقي {remaining} يوم على انتهاء اشتراكك VIP.\n"
                f"📋 الخطة: {plan}\n"
                f"📅 ينتهي: {expires_at[:19]}\n\n"
                f"قم بتجديد الاشتراك للاستمرار في الاستمتاع بالميزات الحصرية!"
            )

            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("⭐ تجديد الاشتراك", callback_data="nav_vip")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
            ])

            await app.send_message(uid, text, reply_markup=kb)
            logger.info(f"Expiry reminder sent to {uid} ({remaining} days remaining)")

            await db.execute(
                "INSERT OR REPLACE INTO vip_reminders (user_id, reminder_sent_at, created_at) VALUES (?, ?, ?)",
                (uid, datetime.utcnow().isoformat(), datetime.utcnow().isoformat()),
            )
        except Exception as e:
            logger.warning(f"Failed to send reminder to {uid}: {e}")
