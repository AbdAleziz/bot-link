import logging
from datetime import datetime

from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from config import Config
from database import Database
from rbac import RBAC

logger = logging.getLogger(__name__)


async def register_pricing_admin(app: Client, db: Database):
    await db.execute("""
        CREATE TABLE IF NOT EXISTS vip_pricing (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            plan_name TEXT NOT NULL,
            duration_days INTEGER NOT NULL,
            price_cents INTEGER NOT NULL,
            currency TEXT DEFAULT 'USD',
            stars_price INTEGER DEFAULT 0,
            active INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT,
            updated_by INTEGER
        )
    """)

    existing = await db.fetchval("SELECT COUNT(*) FROM vip_pricing")
    if existing == 0:
        defaults = [
            ("week", 7, 200, "USD", 100, 1),
            ("month", 30, 500, "USD", 300, 1),
            ("quarter", 90, 1200, "USD", 700, 1),
            ("year", 365, 4000, "USD", 2500, 1),
            ("lifetime", 36500, 10000, "USD", 5000, 1),
        ]
        for p in defaults:
            await db.execute(
                "INSERT INTO vip_pricing (plan_name, duration_days, price_cents, currency, stars_price, active, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (*p, datetime.utcnow().isoformat()),
            )

    @app.on_message(filters.command("pricing_panel") & filters.private)
    async def pricing_panel_cmd(client: Client, message: Message):
        uid = message.from_user.id
        if not RBAC.is_admin(uid):
            await message.reply("❌ هذا الأمر خاص بالمشرفين.")
            return
        await _show_pricing_panel(client, message, db)

    @app.on_callback_query(filters.regex(r"^price_"))
    async def pricing_callback(client: Client, cb: CallbackQuery):
        uid = cb.from_user.id
        if not RBAC.is_admin(uid):
            await cb.answer("❌ غير مصرح.", show_alert=True)
            return

        action = cb.data[len("price_"):]

        if action == "list":
            await _show_pricing_list(client, cb, db)

        elif action == "add":
            await cb.message.reply(
                "📝 <b>إضافة خطة جديدة</b>\n\n"
                "أرسل البيانات بالتنسيق:\n"
                "<code>الاسم, المدة_بالأيام, السعر_بسنت, العملة, سعر_النجوم</code>\n\n"
                "مثال:\n"
                "<code>half_year, 180, 2200, USD, 1200</code>"
            )

        elif action.startswith("edit_"):
            plan_id = int(action.split("_")[1])
            await cb.message.reply(
                f"✏️ <b>تعديل الخطة</b> (ID: {plan_id})\n\n"
                "أرسل البيانات الجديدة بالتنسيق:\n"
                "<code>الاسم, المدة_بالأيام, السعر_بسنت, العملة, سعر_النجوم, نشط(1/0)</code>"
            )

        elif action.startswith("toggle_"):
            plan_id = int(action.split("_")[1])
            row = await db.fetchrow("SELECT active FROM vip_pricing WHERE id = ?", (plan_id,))
            if row:
                new_active = 0 if row["active"] else 1
                await db.execute(
                    "UPDATE vip_pricing SET active = ?, updated_at = ?, updated_by = ? WHERE id = ?",
                    (new_active, datetime.utcnow().isoformat(), uid, plan_id),
                )
                logger.info(f"Pricing plan {plan_id} toggled to {'active' if new_active else 'inactive'} by {uid}")
            await _show_pricing_list(client, cb, db)

        elif action == "back":
            await _show_pricing_panel(client, cb.message, db)

        await cb.answer()

    @app.on_message(filters.text & filters.private & ~filters.command([]), group=999)
    async def pricing_text_handler(client: Client, message: Message):
        uid = message.from_user.id
        if not RBAC.is_admin(uid):
            return

        text = message.text.strip()
        parts = [p.strip() for p in text.split(",")]
        if len(parts) < 5:
            return

        try:
            plan_name = parts[0].lower()
            duration = int(parts[1])
            price = int(parts[2])
            currency = parts[3].upper()
            stars = int(parts[4])
            active = int(parts[5]) if len(parts) > 5 else 1

            if 7 <= duration <= 36500 and price > 0:
                await db.execute(
                    "INSERT INTO vip_pricing (plan_name, duration_days, price_cents, currency, stars_price, active, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (plan_name, duration, price, currency, stars, active, datetime.utcnow().isoformat()),
                )
                await message.reply(f"✅ تم إضافة الخطة <b>{plan_name}</b> بنجاح!")
                logger.info(f"New pricing plan '{plan_name}' added by {uid}")
            else:
                await message.reply("❌ قيم غير صالحة.")
        except (ValueError, IndexError):
            pass


async def _show_pricing_panel(client, message, db):
    text = (
        "💰 <b>لوحة إدارة الأسعار</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"اختر إجراءً من الأزرار أدناه:\n"
        f"━━━━━━━━━━━━━━"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("📋 عرض الخطط", callback_data="price_list")],
        [InlineKeyboardButton("➕ إضافة خطة", callback_data="price_add")],
        [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
    ])
    await message.reply(text, reply_markup=kb)


async def _show_pricing_list(client, cb, db):
    rows = await db.fetch("SELECT * FROM vip_pricing ORDER BY duration_days ASC")
    if not rows:
        await cb.message.edit(
            "❌ لا توجد خطط أسعار.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("➕ إضافة خطة", callback_data="price_add")],
                [InlineKeyboardButton("🔙 رجوع", callback_data="price_back")],
            ]),
        )
        return

    text = "💰 <b>خطط الأسعار</b>\n━━━━━━━━━━━━━━\n"
    for r in rows:
        status = "✅" if r["active"] else "❌"
        text += (
            f"\n{status} <b>{r['plan_name']}</b> (ID: {r['id']})\n"
            f"   📅 {r['duration_days']} يوم\n"
            f"   💵 {r['price_cents'] / 100:.2f} {r['currency']}\n"
            f"   ⭐ {r['stars_price']} Stars\n"
        )
    text += "\n━━━━━━━━━━━━━━"

    buttons = []
    for r in rows:
        buttons.append([
            InlineKeyboardButton(
                f"✏️ {r['plan_name']}",
                callback_data=f"price_edit_{r['id']}",
            ),
            InlineKeyboardButton(
                f"{'❌ تعطيل' if r['active'] else '✅ تفعيل'}",
                callback_data=f"price_toggle_{r['id']}",
            ),
        ])
    buttons.append([InlineKeyboardButton("➕ إضافة خطة", callback_data="price_add")])
    buttons.append([InlineKeyboardButton("🔙 رجوع", callback_data="price_back")])

    await cb.message.edit(text, reply_markup=InlineKeyboardMarkup(buttons))
