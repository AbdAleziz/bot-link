import logging
import os
from datetime import datetime

from config import Config

logger = logging.getLogger(__name__)


async def generate_invoice_pdf(
    user_id: int,
    plan: str,
    amount: int,
    currency: str,
    payment_method: str,
    tx_hash: str,
) -> str | None:
    try:
        from fpdf import FPDF
        import qrcode
        from io import BytesIO

        now = datetime.utcnow()
        month = now.strftime("%Y%m")
        inv_count = await _get_invoice_count(month)
        inv_number = f"INV-{month}-{inv_count:04d}"

        pdf = FPDF()
        pdf.add_page()

        pdf.set_font("Arial", "B", 20)
        pdf.cell(0, 15, "scanner_bot", ln=True, align="C")
        pdf.set_font("Arial", "", 8)
        pdf.cell(0, 5, "Telegram URL Scanner & QR Generator", ln=True, align="C")
        pdf.ln(10)

        pdf.set_draw_color(0, 120, 200)
        pdf.set_line_width(0.5)
        pdf.line(10, pdf.get_y(), 200, pdf.get_y())
        pdf.ln(5)

        pdf.set_font("Arial", "B", 14)
        pdf.cell(0, 10, "INVOICE", ln=True, align="C")
        pdf.ln(5)

        pdf.set_font("Arial", "", 10)
        pdf.cell(0, 7, f"Invoice #: {inv_number}", ln=True)
        pdf.cell(0, 7, f"Date: {now.strftime('%Y-%m-%d %H:%M:%S')} UTC", ln=True)
        pdf.cell(0, 7, f"User ID: {user_id}", ln=True)
        pdf.ln(5)

        pdf.set_font("Arial", "B", 11)
        pdf.cell(0, 8, "Payment Details", ln=True)
        pdf.set_font("Arial", "", 10)
        pdf.cell(0, 7, f"Plan: {plan}", ln=True)
        pdf.cell(0, 7, f"Amount: {amount / 100:.2f} {currency}", ln=True)
        pdf.cell(0, 7, f"Payment Method: {payment_method}", ln=True)
        pdf.cell(0, 7, f"Transaction Hash: {tx_hash}", ln=True)
        pdf.ln(5)

        pdf.set_draw_color(0, 120, 200)
        pdf.line(10, pdf.get_y(), 200, pdf.get_y())
        pdf.ln(5)

        verify_url = f"{Config.WEB_URL}/invoice/verify/{inv_number}"
        pdf.set_font("Arial", "", 9)
        pdf.cell(0, 7, f"Verify at: {verify_url}", ln=True)
        pdf.ln(5)

        qr = qrcode.make(verify_url)
        qr_buf = BytesIO()
        qr.save(qr_buf, format="PNG")
        qr_buf.seek(0)
        qr_path = f"/tmp/inv_qr_{inv_number}.png"
        with open(qr_path, "wb") as f:
            f.write(qr_buf.getvalue())
        pdf.image(qr_path, x=160, y=pdf.get_y(), w=30)
        os.remove(qr_path)

        pdf.ln(35)
        pdf.set_font("Arial", "I", 8)
        pdf.cell(0, 5, f"© {now.year} scanner_bot | @AbdAleziz_1", ln=True, align="C")

        os.makedirs("data/invoices", exist_ok=True)
        pdf_path = f"data/invoices/{inv_number}.pdf"
        pdf.output(pdf_path)
        logger.info(f"Invoice PDF generated: {pdf_path}")
        return pdf_path

    except ImportError as e:
        logger.warning(f"PDF generation libraries not available: {e}")
        return None
    except Exception as e:
        logger.error(f"Invoice PDF generation error: {e}")
        return None


async def _get_invoice_count(month: str) -> int:
    try:
        import glob
        existing = glob.glob(f"data/invoices/INV-{month}-*.pdf")
        return len(existing) + 1
    except Exception:
        return 1
