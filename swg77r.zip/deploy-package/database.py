# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import json
import logging
import os
import sqlite3
import time
from datetime import datetime
from pathlib import Path

from config import Config

logger = logging.getLogger("database")


class CacheLayer:
    def __init__(self):
        self._memory = {}
        self._ttl = {}
        self._redis = None
        self._redis_available = False

    async def init(self):
        if Config.REDIS_URL:
            try:
                import redis.asyncio as aioredis
                self._redis = aioredis.from_url(Config.REDIS_URL, decode_responses=True)
                await self._redis.ping()
                self._redis_available = True
                logger.info("Redis cache connected")
            except Exception as e:
                logger.warning(f"Redis unavailable, using memory cache: {e}")

    async def get(self, key: str) -> str | None:
        if self._redis_available:
            try:
                return await self._redis.get(key)
            except Exception:
                pass
        val = self._memory.get(key)
        if val and key in self._ttl:
            if time.time() > self._ttl[key]:
                self._memory.pop(key, None)
                self._ttl.pop(key, None)
                return None
        return val

    async def set(self, key: str, value: str, ttl: int = Config.CACHE_TTL):
        if self._redis_available:
            try:
                await self._redis.setex(key, ttl, value)
                return
            except Exception:
                pass
        self._memory[key] = value
        self._ttl[key] = time.time() + ttl

    async def delete(self, key: str):
        if self._redis_available:
            try:
                await self._redis.delete(key)
                return
            except Exception:
                pass
        self._memory.pop(key, None)
        self._ttl.pop(key, None)

    async def close(self):
        if self._redis_available and self._redis:
            await self._redis.close()


class Database:
    def __init__(self):
        self._pool = None
        self._sqlite_conn = None
        self._lock = asyncio.Lock()
        self.cache = CacheLayer()
        self._postgres = (
            Config.USE_POSTGRES
            and bool(Config.DATABASE_URL and "postgres" in Config.DATABASE_URL)
        )

    async def init(self):
        await self.cache.init()
        self._turso = None
        if "libsql" in Config.DATABASE_URL:
            await self._init_turso()
        elif self._postgres:
            await self._init_postgres()
        else:
            await self._init_sqlite()
        await self._run_migrations()

    async def _init_turso(self):
        try:
            import libsql_experimental as libsql
            self._turso = libsql.connect(
                database=Config.DATABASE_URL,
                auth_token=os.getenv("TURSO_AUTH_TOKEN", ""),
            )
            logger.info("Turso/libSQL database initialized")
        except ImportError:
            logger.warning("libsql-experimental not installed, falling back to SQLite")
            await self._init_sqlite()
        except Exception as e:
            logger.error(f"Turso init failed, falling back to SQLite: {e}")
            await self._init_sqlite()

    async def _init_sqlite(self):
        db_path = Config.DATABASE_URL.replace("sqlite+aiosqlite:///", "")
        if not db_path:
            db_path = "data/bot.db"
        db_path = Path(db_path)
        db_path.parent.mkdir(parents=True, exist_ok=True)

        self._conn = sqlite3.connect(str(db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.execute("PRAGMA synchronous=1")
        self._conn.execute("PRAGMA cache_size=-8000")
        self._conn.execute("PRAGMA foreign_keys=ON")

        logger.info(f"SQLite database initialized: {db_path}")

    async def _init_postgres(self):
        try:
            import asyncpg
            self._pool = await asyncpg.create_pool(
                Config.DATABASE_URL, min_size=2, max_size=Config.DB_POOL_SIZE
            )
            logger.info("PostgreSQL database initialized")
        except Exception as e:
            logger.error(f"PostgreSQL init failed, falling back to SQLite: {e}")
            self._postgres = False
            await self._init_sqlite()

    async def _run_migrations(self):
        await self.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                is_banned INTEGER DEFAULT 0,
                joined_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS banned_users (
                user_id INTEGER PRIMARY KEY,
                reason TEXT,
                banned_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS vip_users (
                user_id INTEGER PRIMARY KEY,
                expires_at TEXT,
                plan TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS scan_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT,
                domain TEXT,
                user_id INTEGER,
                is_threat INTEGER DEFAULT 0,
                threat_type TEXT,
                trust_score REAL,
                vt_positives INTEGER,
                scanner_result TEXT,
                scanned_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS blacklist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern TEXT UNIQUE,
                reason TEXT,
                added_by INTEGER,
                added_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS whitelist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern TEXT UNIQUE,
                added_by INTEGER,
                added_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS domain_watch (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                domain TEXT,
                user_id INTEGER,
                added_at TEXT,
                UNIQUE(domain, user_id)
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS url_reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT,
                domain TEXT,
                reported_by INTEGER,
                reason TEXT,
                created_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS support_tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                message TEXT,
                reply TEXT,
                status TEXT DEFAULT 'open',
                created_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS pending_payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                plan TEXT,
                amount INTEGER,
                currency TEXT,
                invoice_id TEXT,
                status TEXT DEFAULT 'pending',
                created_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS short_links (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                short_code TEXT UNIQUE,
                original_url TEXT,
                created_by INTEGER,
                expires_at TEXT,
                created_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS click_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                link_id INTEGER,
                ip TEXT,
                user_agent TEXT,
                referer TEXT,
                clicked_at TEXT,
                FOREIGN KEY (link_id) REFERENCES short_links(id)
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS qr_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                short_code TEXT UNIQUE,
                original_url TEXT,
                created_by INTEGER,
                fg_color TEXT DEFAULT '#000000',
                bg_color TEXT DEFAULT '#FFFFFF',
                has_logo INTEGER DEFAULT 0,
                scan_count INTEGER DEFAULT 0,
                created_at TEXT,
                FOREIGN KEY (short_code) REFERENCES short_links(short_code)
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS import_export_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action TEXT,
                user_id INTEGER,
                filename TEXT,
                record_count INTEGER,
                created_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS api_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT UNIQUE,
                user_id INTEGER,
                permissions TEXT DEFAULT 'read',
                is_active INTEGER DEFAULT 1,
                created_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS payment_methods (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                icon TEXT,
                contact_info TEXT NOT NULL DEFAULT '',
                account_holder TEXT,
                currency TEXT DEFAULT 'IQD',
                instructions TEXT,
                active INTEGER DEFAULT 1,
                sort_order INTEGER DEFAULT 0
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS payment_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                reference_code TEXT UNIQUE NOT NULL,
                amount INTEGER NOT NULL,
                currency TEXT NOT NULL,
                method_id INTEGER NOT NULL,
                plan TEXT NOT NULL,
                duration_days INTEGER NOT NULL,
                status TEXT DEFAULT 'pending',
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                verified_at TEXT,
                verified_by INTEGER,
                notes TEXT,
                FOREIGN KEY (method_id) REFERENCES payment_methods(id)
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS rate_limit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                action TEXT,
                timestamp TEXT
            )
        """)

        await self.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                action TEXT,
                target_type TEXT,
                target_id TEXT,
                details TEXT,
                ip TEXT,
                created_at TEXT
            )
        """)

        await self.execute("""
            CREATE TABLE IF NOT EXISTS perf_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                metric TEXT,
                value REAL,
                unit TEXT,
                created_at TEXT
            )
        """)

        await self.execute("""
            CREATE TABLE IF NOT EXISTS command_blacklist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                command TEXT,
                blocked_by INTEGER,
                created_at TEXT,
                UNIQUE(user_id, command)
            )
        """)

        await self.execute("""
            CREATE TABLE IF NOT EXISTS backup_schedules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                hour INTEGER,
                minute INTEGER,
                label TEXT,
                enabled INTEGER DEFAULT 1,
                created_at TEXT
            )
        """)

        await self.execute("""
            CREATE TABLE IF NOT EXISTS user_2fa (
                user_id INTEGER PRIMARY KEY,
                secret TEXT,
                enabled INTEGER DEFAULT 0,
                created_at TEXT
            )
        """)

        await self.execute("""
            CREATE TABLE IF NOT EXISTS weekly_reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sent_at TEXT,
                period_start TEXT,
                period_end TEXT,
                report_data TEXT,
                status TEXT DEFAULT 'sent'
            )
        """)

        existing_methods = await self.fetch(
            "SELECT COUNT(*) as cnt FROM payment_methods"
        )
        if existing_methods and existing_methods[0]["cnt"] == 0:
            from config.payment_config import PAYMENT_CONTACTS
            default_methods = [
                ("mastercard", "Mastercard/Visa (تحويل بنكي)", "💳",
                 PAYMENT_CONTACTS.get("mastercard", ""), "", "IQD", "", 1, 0),
                ("zain_cash", "Zain Cash", "📱",
                 PAYMENT_CONTACTS.get("zain_cash", ""), "", "IQD", "", 1, 1),
                ("fib", "FIB (البنك العراقي)", "🏦",
                 PAYMENT_CONTACTS.get("fib", ""), "", "IQD", "", 1, 2),
                ("qicard", "QiCard", "💳",
                 PAYMENT_CONTACTS.get("qicard", ""), "", "IQD", "", 1, 3),
            ]
            for m in default_methods:
                await self.execute(
                    "INSERT OR IGNORE INTO payment_methods (code, name, icon, contact_info, account_holder, currency, instructions, active, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    m,
                )

        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_scan_history_scanned_at ON scan_history(scanned_at)"
        )
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_scan_history_url ON scan_history(url)"
        )
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_short_links_code ON short_links(short_code)"
        )
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_url_reports_domain ON url_reports(domain)"
        )
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_domain_watch_domain ON domain_watch(domain)"
        )
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_click_logs_link ON click_logs(link_id)"
        )
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_payment_requests_user ON payment_requests(user_id)"
        )
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_payment_requests_ref ON payment_requests(reference_code)"
        )
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_payment_requests_status ON payment_requests(status)"
        )
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_qr_codes_short ON qr_codes(short_code)"
        )
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_audit_log_created ON audit_log(created_at)"
        )

        # --- support team: new tables ---
        await self.execute("""
            CREATE TABLE IF NOT EXISTS support_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id TEXT NOT NULL,
                sender_id INTEGER NOT NULL,
                is_agent INTEGER NOT NULL DEFAULT 0,
                body TEXT NOT NULL,
                sent_at TEXT NOT NULL,
                FOREIGN KEY (ticket_id) REFERENCES support_tickets(id)
            )
        """)
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_messages_ticket ON support_messages(ticket_id)"
        )

        # Add new columns to existing support_tickets if missing (SQLite)
        for col, dtype in [("assigned_to", "INTEGER"), ("subject", "TEXT"), ("updated_at", "TEXT"), ("closed_at", "TEXT"), ("closed_by", "INTEGER")]:
            try:
                await self.execute(f"ALTER TABLE support_tickets ADD COLUMN {col} {dtype}")
            except Exception:
                pass  # column already exists

        # --- v3 upgrade: new tables ---
        await self.execute("""
            CREATE TABLE IF NOT EXISTS user_language (
                user_id INTEGER PRIMARY KEY,
                lang TEXT NOT NULL DEFAULT 'ar'
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS admin_audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                command TEXT,
                args_json TEXT,
                ip TEXT,
                result TEXT,
                created_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS trial_attempts (
                user_id INTEGER PRIMARY KEY,
                ip TEXT,
                ip_first_octets TEXT,
                ua_hash TEXT,
                used_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS vip_pricing (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plan_name TEXT NOT NULL,
                duration_days INTEGER NOT NULL,
                price_cents INTEGER NOT NULL,
                currency TEXT DEFAULT 'USD',
                stars_price INTEGER DEFAULT 0,
                mode TEXT DEFAULT 'auto',
                active INTEGER DEFAULT 1,
                created_at TEXT,
                updated_at TEXT,
                updated_by INTEGER
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS whois_cache (
                domain TEXT PRIMARY KEY,
                result_json TEXT,
                cached_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS community_votes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                url_hash TEXT,
                vote TEXT,
                created_at TEXT,
                UNIQUE(user_id, url_hash)
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS vip_reminders (
                user_id INTEGER,
                reminder_sent_at TEXT,
                PRIMARY KEY (user_id)
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS typosquat_watch (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                domain TEXT UNIQUE,
                added_by INTEGER,
                added_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS scan_cache (
                url_hash TEXT PRIMARY KEY,
                result_json TEXT,
                scanned_at TEXT,
                expires_at TEXT
            )
        """)
        await self.execute("""
            CREATE INDEX IF NOT EXISTS idx_community_votes_hash ON community_votes(url_hash)
        """)
        await self.execute("""
            CREATE INDEX IF NOT EXISTS idx_scan_cache_expires ON scan_cache(expires_at)
        """)
        await self.execute("""
            CREATE INDEX IF NOT EXISTS idx_whois_cache_domain ON whois_cache(domain)
        """)

        logger.info("Database migrations complete")

    async def _run_turso(self, query: str, *args):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._turso.execute, query, args)

    async def execute(self, query: str, *args, **kwargs):
        if self._turso is not None:
            try:
                return await self._run_turso(query, *args)
            except Exception as e:
                logger.error(f"Turso execute error, falling back to SQLite: {e}")
                self._turso = None
                await self._init_sqlite()
        if self._postgres and self._pool:
            async with self._pool.acquire() as conn:
                return await conn.execute(query, *args)
        else:
            async with self._lock:
                loop = asyncio.get_event_loop()
                cur = await loop.run_in_executor(
                    None, self._conn.execute, query, args
                )
                self._conn.commit()
                return cur

    async def fetchval(self, query: str, *args):
        if self._turso is not None:
            try:
                cur = await self._run_turso(query, *args)
                row = cur.fetchone()
                return row[0] if row else None
            except Exception as e:
                logger.error(f"Turso fetchval error, falling back to SQLite: {e}")
                self._turso = None
                await self._init_sqlite()
        if self._postgres and self._pool:
            async with self._pool.acquire() as conn:
                return await conn.fetchval(query, *args)
        else:
            async with self._lock:
                loop = asyncio.get_event_loop()
                cur = await loop.run_in_executor(
                    None, self._conn.execute, query, args
                )
                row = cur.fetchone()
                return row[0] if row else None

    async def fetchrow(self, query: str, *args):
        if self._turso is not None:
            try:
                cur = await self._run_turso(query, *args)
                row = cur.fetchone()
                return dict(row) if row else None
            except Exception as e:
                logger.error(f"Turso fetchrow error, falling back to SQLite: {e}")
                self._turso = None
                await self._init_sqlite()
        if self._postgres and self._pool:
            async with self._pool.acquire() as conn:
                row = await conn.fetchrow(query, *args)
                return dict(row) if row else None
        else:
            async with self._lock:
                loop = asyncio.get_event_loop()
                cur = await loop.run_in_executor(
                    None, self._conn.execute, query, args
                )
                row = cur.fetchone()
                return dict(row) if row else None

    async def fetch(self, query: str, *args):
        if self._turso is not None:
            try:
                cur = await self._run_turso(query, *args)
                rows = cur.fetchall()
                return [dict(r) for r in rows]
            except Exception as e:
                logger.error(f"Turso fetch error, falling back to SQLite: {e}")
                self._turso = None
                await self._init_sqlite()
        if self._postgres and self._pool:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(query, *args)
                return [dict(r) for r in rows]
        else:
            async with self._lock:
                loop = asyncio.get_event_loop()
                cur = await loop.run_in_executor(
                    None, self._conn.execute, query, args
                )
                rows = cur.fetchall()
                return [dict(r) for r in rows]

    async def export_to_json(self, tables: list[str] = None) -> str:
        if tables is None:
            tables = [
                "users", "vip_users", "blacklist", "whitelist",
                "banned_users", "short_links", "qr_codes",
            ]
        data = {}
        for table in tables:
            try:
                rows = await self.fetch(f"SELECT * FROM {table}")
                data[table] = rows
            except Exception:
                data[table] = []
        return json.dumps(data, ensure_ascii=False, indent=2)

    async def import_from_json(self, json_str: str, user_id: int = None) -> dict:
        result = {"imported": 0, "errors": 0, "tables": {}}
        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            return {"error": "Invalid JSON"}

        for table, rows in data.items():
            if not rows:
                continue
            count = 0
            for row in rows:
                try:
                    columns = ", ".join(row.keys())
                    placeholders = ", ".join(["?"] * len(row))
                    await self.execute(
                        f"INSERT OR REPLACE INTO {table} ({columns}) VALUES ({placeholders})",
                        *row.values(),
                    )
                    count += 1
                except Exception:
                    result["errors"] += 1
            result["tables"][table] = count
            result["imported"] += count

        if user_id:
            await self.execute(
                "INSERT INTO import_export_log (action, user_id, record_count, created_at) VALUES (?, ?, ?, ?)",
                ("import", user_id, result["imported"], datetime.utcnow().isoformat()),
            )

        return result

    async def close(self):
        await self.cache.close()
        if self._postgres and self._pool:
            await self._pool.close()
        elif self._turso is not None:
            self._turso.close()
        elif hasattr(self, "_conn"):
            self._conn.close()
        logger.info("Database closed")
