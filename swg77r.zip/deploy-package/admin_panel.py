# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import io
import logging
import os
import platform
from datetime import datetime

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from config import Config
from database import Database
from rbac import RBAC, Role

logger = logging.getLogger("admin_panel")


class AdminPanel:
    def __init__(self, db: Database):
        self.db = db

    def _owner_kb(self) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("📊 Stats", callback_data="adm_stats"),
             InlineKeyboardButton("📢 Broadcast", callback_data="adm_broadcast")],
            [InlineKeyboardButton("🚫 Ban", callback_data="adm_ban"),
             InlineKeyboardButton("✅ Unban", callback_data="adm_unban")],
            [InlineKeyboardButton("🗑️ Clear Cache", callback_data="adm_clearcache"),
             InlineKeyboardButton("📦 Export DB", callback_data="adm_export")],
            [InlineKeyboardButton("⭐ Grant VIP", callback_data="adm_grantvip"),
             InlineKeyboardButton("📋 Logs", callback_data="adm_logs")],
            [InlineKeyboardButton("👥 Sub-Devs", callback_data="adm_subdevs"),
             InlineKeyboardButton("♻️ Restart", callback_data="adm_restart")],
            [InlineKeyboardButton("📋 Audit Log", callback_data="adm_auditlog"),
             InlineKeyboardButton("📊 Weekly Report", callback_data="adm_weekly")],
            [InlineKeyboardButton("📧 Alert Settings", callback_data="adm_alerts"),
             InlineKeyboardButton("🚫 Command Blacklist", callback_data="adm_blacklist")],
            [InlineKeyboardButton("🖥️ Server Stats", callback_data="adm_serverstats"),
             InlineKeyboardButton("🔐 2FA Settings", callback_data="adm_2fa")],
            [InlineKeyboardButton("🌐 Web Dashboard", url=Config.WEB_URL)],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
        ])

    def _subdev_kb(self) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("📊 Stats", callback_data="adm_stats"),
             InlineKeyboardButton("📢 Broadcast", callback_data="adm_broadcast")],
            [InlineKeyboardButton("🚫 Ban User", callback_data="adm_ban"),
             InlineKeyboardButton("✅ Unban User", callback_data="adm_unban")],
            [InlineKeyboardButton("🗑️ Clear Cache", callback_data="adm_clearcache"),
             InlineKeyboardButton("📋 Logs", callback_data="adm_logs")],
            [InlineKeyboardButton("📋 Audit Log", callback_data="adm_auditlog"),
             InlineKeyboardButton("📊 Weekly Report", callback_data="adm_weekly")],
            [InlineKeyboardButton("🖥️ Server Stats", callback_data="adm_serverstats")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
        ])

    def register(self, app: Client):
        @app.on_message(filters.command("panel") & filters.private)
        async def panel_cmd(client: Client, message: Message):
            uid = message.from_user.id
            if not RBAC.is_admin(uid):
                await message.reply("❌ Unauthorized.")
                return
            role = RBAC.get_role(uid)
            kb = self._owner_kb() if role == Role.OWNER else self._subdev_kb()
            role_name = "👑 Owner" if role == Role.OWNER else "🛠️ Sub-Developer"
            await message.reply(
                f"{role_name} <b>Admin Panel</b>\n"
                f"━━━━━━━━━━━━━━\n"
                f"ID: <code>{uid}</code>\n"
                f"━━━━━━━━━━━━━━",
                reply_markup=kb,
            )

        @app.on_callback_query(filters.regex(r"^adm_"))
        async def admin_cb(client: Client, cb: CallbackQuery):
            uid = cb.from_user.id
            if not RBAC.is_admin(uid):
                await cb.answer("❌ Unauthorized", show_alert=True)
                return

            action = cb.data.replace("adm_", "")

            if action == "stats":
                await self._stats(client, cb)
            elif action == "broadcast":
                await cb.message.reply(
                    "📢 Reply to a message with /broadcast to send it to all users.\n"
                    f"Or forward a message and reply with /broadcast."
                )
                await cb.answer()
            elif action == "ban":
                await cb.message.reply(
                    "🚫 Use: /ban <user_id> <reason>\n"
                    "Or reply to a user's message with /ban <reason>"
                )
                await cb.answer()
            elif action == "unban":
                await cb.message.reply("✅ Use: /unban <user_id>")
                await cb.answer()
            elif action == "clearcache":
                await self._clear_cache(client, cb)
            elif action == "export":
                await self._export(client, cb)
            elif action == "grantvip":
                await cb.message.reply(
                    "⭐ Use: /grantvip <user_id> <months>"
                )
                await cb.answer()
            elif action == "logs":
                await self._logs(client, cb)
            elif action == "subdevs":
                await self._subdevs(client, cb, uid)
            elif action == "restart":
                if not RBAC.is_owner(uid):
                    await cb.answer("❌ Owner only", show_alert=True)
                    return
                await cb.answer("♻️ Restarting...")
                import asyncio
                asyncio.get_event_loop().stop()
            elif action == "auditlog":
                await self._audit_log(client, cb)
            elif action == "weekly":
                await self._weekly_report(client, cb)
            elif action == "alerts":
                await self._alert_settings(client, cb)
            elif action == "blacklist":
                await self._blacklist(client, cb)
            elif action == "serverstats":
                await self._server_stats(client, cb)
            elif action == "2fa":
                await self._twofa_settings(client, cb)
            elif action == "back":
                kb = self._owner_kb() if RBAC.get_role(uid) == Role.OWNER else self._subdev_kb()
                role_name = "👑 Owner" if RBAC.get_role(uid) == Role.OWNER else "🛠️ Sub-Developer"
                await cb.message.edit(
                    f"{role_name} <b>Admin Panel</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"ID: <code>{uid}</code>\n"
                    f"━━━━━━━━━━━━━━",
                    reply_markup=kb,
                )
                await cb.answer()
            elif action.startswith("mmaudit_page_"):
                parts = cb.data.split("_")
                if len(parts) >= 4:
                    try:
                        filter_uid = int(parts[2]) if parts[2] != "0" else None
                        page = int(parts[3])
                        await self._show_audit_page(client, cb, filter_uid, page)
                    except (ValueError, IndexError):
                        await cb.answer("❌ Invalid page data", show_alert=True)
                await cb.answer()
            else:
                await cb.answer()

        @app.on_callback_query(filters.regex(r"^admmaudit_page_"))
        async def audit_page_cb(client: Client, cb: CallbackQuery):
            uid = cb.from_user.id
            if not RBAC.is_admin(uid):
                await cb.answer("❌ Unauthorized", show_alert=True)
                return
            parts = cb.data.split("_")
            if len(parts) >= 4:
                try:
                    filter_uid = int(parts[2]) if parts[2] != "0" else None
                    page = int(parts[3])
                    await self._show_audit_page(client, cb, filter_uid, page)
                except (ValueError, IndexError):
                    await cb.answer("❌ Invalid page data", show_alert=True)
            await cb.answer()

    # ── Existing Helper Methods ─────────────────────────────────────────────

    async def _stats(self, client: Client, cb: CallbackQuery):
        users = await self.db.fetchval("SELECT COUNT(*) FROM users") or 0
        vips = (
            await self.db.fetchval(
                "SELECT COUNT(*) FROM vip_users WHERE expires_at > datetime('now')"
            )
            or 0
        )
        scans_today = (
            await self.db.fetchval(
                "SELECT COUNT(*) FROM scan_history WHERE date(scanned_at) = date('now')"
            )
            or 0
        )
        total_scans = (
            await self.db.fetchval("SELECT COUNT(*) FROM scan_history") or 0
        )
        threats = (
            await self.db.fetchval(
                "SELECT COUNT(*) FROM scan_history WHERE is_threat = 1"
            )
            or 0
        )
        banned = (
            await self.db.fetchval("SELECT COUNT(*) FROM banned_users") or 0
        )
        short_links = (
            await self.db.fetchval("SELECT COUNT(*) FROM short_links") or 0
        )

        text = (
            f"📊 <b>Bot Statistics</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"👥 Users: {users}\n"
            f"⭐ VIP: {vips}\n"
            f"🔍 Today's scans: {scans_today}\n"
            f"📈 Total scans: {total_scans}\n"
            f"🛡️ Threats: {threats}\n"
            f"🚫 Banned: {banned}\n"
            f"🔗 Short links: {short_links}\n"
            f"━━━━━━━━━━━━━━"
        )
        await cb.message.edit(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
            ]),
        )
        await cb.answer()

    async def _clear_cache(self, client: Client, cb: CallbackQuery):
        keys = [k for k in list(self.db.cache._memory.keys()) if k.startswith("scan:")]
        for k in keys:
            await self.db.cache.delete(k)
        await cb.message.edit(
            "✅ Cache cleared.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
            ]),
        )
        await cb.answer()

    async def _export(self, client: Client, cb: CallbackQuery):
        await cb.message.edit("📦 Exporting data...")
        try:
            data = await self.db.export_to_json()
            f = io.BytesIO(data.encode())
            f.name = f"bot_backup_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
            await client.send_document(cb.from_user.id, f, caption="✅ DB Export")
        except Exception as e:
            await client.send_message(cb.from_user.id, f"❌ Export error: {e}")
        await cb.answer()

    async def _logs(self, client: Client, cb: CallbackQuery):
        try:
            if os.path.exists(Config.LOG_FILE):
                with open(Config.LOG_FILE, "r", encoding="utf-8") as f:
                    content = f.read()
                if len(content) > 3500:
                    content = content[-3500:]
                await cb.message.edit(
                    f"📋 <b>Recent Logs:</b>\n<pre>{content}</pre>",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
                    ]),
                )
            else:
                await cb.message.edit(
                    "❌ Log file not found.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
                    ]),
                )
        except Exception as e:
            await cb.message.edit(f"❌ Error: {e}")
        await cb.answer()

    async def _subdevs(self, client: Client, cb: CallbackQuery, uid: int):
        if not RBAC.is_owner(uid):
            await cb.answer("❌ Owner only", show_alert=True)
            return

        sub_devs = Config.SUB_DEVS
        text = "👥 <b>Sub-Developers:</b>\n━━━━━━━━━━━━━━\n"
        if sub_devs:
            for sd in sub_devs:
                text += f"• <code>{sd}</code>\n"
        else:
            text += "No sub-developers configured.\n"
        text += "\nSet SUB_DEVS env var to add more."
        await cb.message.edit(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
            ]),
        )
        await cb.answer()

    # ── New Helper Methods ──────────────────────────────────────────────────

    async def _audit_log(self, client: Client, cb: CallbackQuery):
        await self._show_audit_page(client, cb, filter_uid=None, page=0)

    async def _show_audit_page(self, client: Client, cb: CallbackQuery, filter_uid: int = None, page: int = 0):
        page_size = 10
        offset = page * page_size
        if filter_uid:
            rows = await self.db.fetch(
                "SELECT * FROM audit_log WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?",
                filter_uid, page_size, offset
            )
            total = await self.db.fetchval(
                "SELECT COUNT(*) FROM audit_log WHERE user_id = ?", filter_uid
            ) or 0
        else:
            rows = await self.db.fetch(
                "SELECT * FROM audit_log ORDER BY created_at DESC LIMIT ? OFFSET ?",
                page_size, offset
            )
            total = await self.db.fetchval("SELECT COUNT(*) FROM audit_log") or 0

        if not rows:
            await cb.message.edit(
                "📋 No audit log entries found.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
                ]),
            )
            return

        total_pages = max(1, (total + page_size - 1) // page_size)
        text = f"📋 <b>Audit Log</b> (page {page + 1}/{total_pages})\n━━━━━━━━━━━━━━\n"
        for r in rows:
            uid = r.get("user_id", "?")
            action = r.get("action", "?")
            details = r.get("details", "") or ""
            ts = str(r.get("created_at", ""))[:19]
            text += f"• <code>{uid}</code> → {action}"
            if details:
                text += f": {details[:50]}"
            text += f"\n  🕐 {ts}\n"
        text += "━━━━━━━━━━━━━━"

        nav_row = []
        if page > 0:
            nav_row.append(InlineKeyboardButton("⬅️ Previous", callback_data=f"admmaudit_page_{filter_uid or 0}_{page - 1}"))
        if offset + page_size < total:
            nav_row.append(InlineKeyboardButton("Next ➡️", callback_data=f"admmaudit_page_{filter_uid or 0}_{page + 1}"))
        kb_buttons = []
        if nav_row:
            kb_buttons.append(nav_row)
        kb_buttons.append([InlineKeyboardButton("🔙 Back", callback_data="adm_back")])

        await cb.message.edit(text, reply_markup=InlineKeyboardMarkup(kb_buttons))

    async def _weekly_report(self, client: Client, cb: CallbackQuery):
        from datetime import timedelta
        week_ago_dt = (datetime.utcnow() - timedelta(days=7)).isoformat()
        new_users = await self.db.fetchval(
            "SELECT COUNT(*) FROM users WHERE joined_at >= ?", week_ago_dt
        ) or 0
        scans = await self.db.fetchval(
            "SELECT COUNT(*) FROM scan_history WHERE scanned_at >= ?", week_ago_dt
        ) or 0
        threats = await self.db.fetchval(
            "SELECT COUNT(*) FROM scan_history WHERE is_threat = 1 AND scanned_at >= ?", week_ago_dt
        ) or 0
        vips = await self.db.fetchval(
            "SELECT COUNT(*) FROM vip_users WHERE expires_at > datetime('now')"
        ) or 0
        total_users = await self.db.fetchval("SELECT COUNT(*) FROM users") or 0

        text = (
            f"📊 <b>Weekly Report</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"📅 Period: last 7 days\n"
            f"👥 New users: {new_users}\n"
            f"🔍 Scans: {scans}\n"
            f"🛡️ Threats: {threats}\n"
            f"⭐ Total VIP: {vips}\n"
            f"👤 Total users: {total_users}\n"
            f"━━━━━━━━━━━━━━\n"
            f"🤖 @AbdAleziz_1 | scanner_bot v{Config.BOT_VERSION}"
        )
        await cb.message.edit(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
            ]),
        )
        await cb.answer()

    async def _alert_settings(self, client: Client, cb: CallbackQuery):
        telegram_status = "✅ Configured" if Config.ALERT_LOG_CHANNEL else "❌ Not configured"
        email_status = "✅ Enabled" if Config.ALERT_EMAIL_ENABLED else "❌ Disabled"
        slack_status = "✅ Configured" if Config.ALERT_SLACK_WEBHOOK else "❌ Not configured"
        discord_status = "✅ Configured" if Config.ALERT_DISCORD_WEBHOOK else "❌ Not configured"

        text = (
            f"📧 <b>Alert Settings</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"📡 Telegram: {telegram_status}\n"
            f"📧 Email: {email_status}\n"
            f"💬 Slack: {slack_status}\n"
            f"🔊 Discord: {discord_status}\n"
            f"━━━━━━━━━━━━━━\n"
            f"Configure via environment variables."
        )
        await cb.message.edit(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
            ]),
        )
        await cb.answer()

    async def _blacklist(self, client: Client, cb: CallbackQuery):
        rows = await self.db.fetch(
            "SELECT * FROM command_blacklist ORDER BY created_at DESC LIMIT 50"
        )
        if not rows:
            text = "🚫 <b>Command Blacklist</b>\n━━━━━━━━━━━━━━\n✅ No blacklisted commands."
        else:
            text = "🚫 <b>Command Blacklist</b>\n━━━━━━━━━━━━━━\n"
            for r in rows:
                text += f"• User <code>{r['user_id']}</code> → /{r['command']}\n"
            text += "━━━━━━━━━━━━━━\n"
            text += "Use /blacklist <user_id> <command> to add."
        await cb.message.edit(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
            ]),
        )
        await cb.answer()

    async def _server_stats(self, client: Client, cb: CallbackQuery):
        import psutil
        try:
            cpu = psutil.cpu_percent(interval=0.5)
            mem = psutil.virtual_memory()
            disk = psutil.disk_usage("/")
            boot_time = datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")
            text = (
                f"🖥️ <b>Server Stats</b>\n"
                f"━━━━━━━━━━━━━━\n"
                f"💻 OS: {platform.system()} {platform.release()}\n"
                f"🐍 Python: {platform.python_version()}\n"
                f"⚙️ CPU: {cpu}%\n"
                f"🧠 RAM: {mem.used // (1024**3)}GB / {mem.total // (1024**3)}GB ({mem.percent}%)\n"
                f"💾 Disk: {disk.used // (1024**3)}GB / {disk.total // (1024**3)}GB ({disk.percent}%)\n"
                f"🔄 Boot: {boot_time}\n"
                f"━━━━━━━━━━━━━━"
            )
        except ImportError:
            text = (
                f"🖥️ <b>Server Stats</b>\n"
                f"━━━━━━━━━━━━━━\n"
                f"💻 OS: {platform.system()} {platform.release()}\n"
                f"🐍 Python: {platform.python_version()}\n"
                f"━━━━━━━━━━━━━━\n"
                f"Install psutil for detailed stats."
            )
        except Exception as e:
            text = f"❌ Error fetching server stats: {e}"

        await cb.message.edit(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
            ]),
        )
        await cb.answer()

    async def _twofa_settings(self, client: Client, cb: CallbackQuery):
        total_enabled = await self.db.fetchval(
            "SELECT COUNT(*) FROM user_2fa WHERE enabled = 1"
        ) or 0
        text = (
            f"🔐 <b>2FA Settings</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"👥 Users with 2FA enabled: {total_enabled}\n"
            f"━━━━━━━━━━━━━━\n"
            f"2FA can be managed by individual users via bot settings."
        )
        await cb.message.edit(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
            ]),
        )
        await cb.answer()

    @staticmethod
    def register_admin_commands(app: Client, db: Database):
        @app.on_message(filters.command("broadcast") & filters.private)
        async def broadcast_cmd(client: Client, message: Message):
            uid = message.from_user.id
            if not RBAC.is_admin(uid):
                return

            if not message.reply_to_message:
                await message.reply("❌ Reply to a message to broadcast.")
                return

            msg_text = (
                message.reply_to_message.text
                or message.reply_to_message.caption
                or ""
            )
            if not msg_text:
                await message.reply("❌ Message is empty.")
                return

            preview = msg_text[:200] + "..." if len(msg_text) > 200 else msg_text
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ Confirm", callback_data="bcconfirm"),
                 InlineKeyboardButton("❌ Cancel", callback_data="bccancel")]
            ])
            await message.reply(
                f"📢 <b>Broadcast Preview:</b>\n━━━━━━━━━━━━━━\n{preview}\n━━━━━━━━━━━━━━\n"
                f"Send this to all users?",
                reply_markup=kb
            )
            # store pending broadcast data on the db object for callback access
            if not hasattr(db, "_pending_broadcast"):
                db._pending_broadcast = {}
            db._pending_broadcast[str(uid)] = {"text": msg_text, "uid": uid}

        @app.on_callback_query(filters.regex(r"^bc(cancel|confirm)$"))
        async def broadcast_cb(client: Client, cb: CallbackQuery):
            uid = cb.from_user.id
            if not RBAC.is_admin(uid):
                await cb.answer("❌ Unauthorized", show_alert=True)
                return

            action = cb.data[2:]
            if not hasattr(db, "_pending_broadcast") or str(uid) not in db._pending_broadcast:
                await cb.answer("❌ Session expired", show_alert=True)
                return

            if action == "cancel":
                db._pending_broadcast.pop(str(uid), None)
                await cb.message.edit("❌ Broadcast cancelled.")
                await cb.answer()
                return

            data = db._pending_broadcast.pop(str(uid), None)
            if not data:
                await cb.answer("❌ Session expired", show_alert=True)
                return

            msg_text = data["text"]
            sent_msg = await cb.message.edit("📢 Broadcasting...")
            users = await db.fetch("SELECT user_id FROM users")
            sent = 0
            failed = 0
            for u in users:
                try:
                    await client.send_message(u["user_id"], msg_text)
                    sent += 1
                    await asyncio.sleep(0.05)
                except Exception:
                    failed += 1
            await sent_msg.edit(
                f"✅ Sent to {sent} users\n❌ Failed: {failed}"
            )
            try:
                await db.execute(
                    "CREATE TABLE IF NOT EXISTS broadcast_history ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    "text TEXT, sent_count INTEGER, failed_count INTEGER, "
                    "broadcasted_by INTEGER, created_at TEXT)"
                )
                await db.execute(
                    "INSERT INTO broadcast_history (text, sent_count, failed_count, broadcasted_by, created_at) "
                    "VALUES (?, ?, ?, ?, ?)",
                    msg_text[:500], sent, failed, uid, datetime.utcnow().isoformat()
                )
            except Exception as e:
                logger.error(f"Failed to log broadcast history: {e}")
            await cb.answer()

        @app.on_message(filters.command("ban") & filters.private)
        async def ban_cmd(client: Client, message: Message):
            uid = message.from_user.id
            if not RBAC.is_admin(uid):
                return

            target_id = None
            reason = "No reason"

            if message.reply_to_message:
                target_id = message.reply_to_message.from_user.id
                parts = message.text.split(maxsplit=1)
                if len(parts) > 1:
                    reason = parts[1]
            else:
                parts = message.text.split()
                if len(parts) >= 2:
                    try:
                        target_id = int(parts[1])
                    except ValueError:
                        await message.reply("❌ Invalid user ID.")
                        return
                    if len(parts) >= 3:
                        reason = " ".join(parts[2:])

            if not target_id:
                await message.reply("❌ Reply to a user or provide user ID.")
                return

            await db.execute(
                "INSERT OR REPLACE INTO banned_users (user_id, reason, banned_at) VALUES (?, ?, ?)",
                (target_id, reason, datetime.utcnow().isoformat()),
            )
            await message.reply(f"✅ Banned <code>{target_id}</code>\nReason: {reason}")

        @app.on_message(filters.command("unban") & filters.private)
        async def unban_cmd(client: Client, message: Message):
            uid = message.from_user.id
            if not RBAC.is_admin(uid):
                return

            if message.reply_to_message:
                target_id = message.reply_to_message.from_user.id
            else:
                parts = message.text.split()
                if len(parts) >= 2:
                    try:
                        target_id = int(parts[1])
                    except ValueError:
                        await message.reply("❌ Invalid user ID.")
                        return
                else:
                    await message.reply("❌ Reply to a user or provide /unban <user_id>.")
                    return

            await db.execute(
                "DELETE FROM banned_users WHERE user_id = ?", (target_id,)
            )
            await message.reply(f"✅ Unbanned <code>{target_id}</code>")
