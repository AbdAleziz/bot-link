# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import logging
import pyotp
import qrcode
import io
from datetime import datetime

from config import Config

logger = logging.getLogger("two_factor")

class TwoFactorAuth:
    def __init__(self, db):
        self.db = db
    
    async def generate_secret(self, user_id: int) -> str:
        secret = pyotp.random_base32()
        await self.db.execute(
            "INSERT OR REPLACE INTO user_2fa (user_id, secret, enabled, created_at) VALUES (?, ?, 0, ?)",
            user_id, secret, datetime.utcnow().isoformat()
        )
        return secret
    
    async def enable(self, user_id: int) -> bool:
        row = await self.db.fetchrow("SELECT secret FROM user_2fa WHERE user_id = ?", (user_id,))
        if not row or not row["secret"]:
            return False
        await self.db.execute("UPDATE user_2fa SET enabled = 1 WHERE user_id = ?", (user_id,))
        return True
    
    async def disable(self, user_id: int):
        await self.db.execute("UPDATE user_2fa SET enabled = 0 WHERE user_id = ?", (user_id,))
    
    async def is_enabled(self, user_id: int) -> bool:
        row = await self.db.fetchrow("SELECT enabled FROM user_2fa WHERE user_id = ?", (user_id,))
        return bool(row and row["enabled"])
    
    async def verify(self, user_id: int, code: str) -> bool:
        row = await self.db.fetchrow("SELECT secret FROM user_2fa WHERE user_id = ? AND enabled = 1", (user_id,))
        if not row or not row["secret"]:
            return True
        totp = pyotp.TOTP(row["secret"])
        return totp.verify(code)
    
    def get_qr(self, secret: str, user_id: int) -> bytes:
        uri = pyotp.totp.TOTP(secret).provisioning_uri(
            name=str(user_id),
            issuer_name=f"ScannerBot_{Config.BOT_OWNER_NAME}"
        )
        img = qrcode.make(uri)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()
