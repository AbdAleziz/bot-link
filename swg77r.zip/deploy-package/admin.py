# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import io
import logging
import os
from datetime import datetime, timedelta

from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from config import Config
from database import Database

logger = logging.getLogger("admin")


# ── Multi-channel Alert Functions ──────────────────────────────────────────

async def send_alert_telegram(app, message: str, chat_id: int = None):
    target = chat_id or Config.ALERT_LOG_CHANNEL
    if target and app:
        try:
            await app.send_message(target, message[:4000])
        except Exception as e:
            logger.error(f"Telegram alert failed: {e}")


async def send_alert_email(subject: str, body: str):
    if not Config.ALERT_EMAIL_ENABLED:
        return
    try:
        import smtplib
        from email.message import EmailMessage
        msg = EmailMessage()
        msg.set_content(body)
        msg["Subject"] = subject
        msg["From"] = Config.ALERT_EMAIL_USER
        msg["To"] = Config.ALERT_EMAIL_TO
        with smtplib.SMTP(Config.ALERT_EMAIL_SMTP, Config.ALERT_EMAIL_PORT) as server:
            server.starttls()
            server.login(Config.ALERT_EMAIL_USER, Config.ALERT_EMAIL_PASS)
            server.send_message(msg)
        logger.info(f"Email alert sent: {subject}")
    except Exception as e:
        logger.error(f"Email alert failed: {e}")


async def send_alert_slack(message: str):
    if not Config.ALERT_SLACK_WEBHOOK:
        return
    try:
        import aiohttp
        async with aiohttp.ClientSession() as session:
            await session.post(Config.ALERT_SLACK_WEBHOOK, json={"text": message})
    except Exception as e:
        logger.error(f"Slack alert failed: {e}")


async def send_alert_discord(message: str):
    if not Config.ALERT_DISCORD_WEBHOOK:
        return
    try:
        import aiohttp
        async with aiohttp.ClientSession() as session:
            await session.post(Config.ALERT_DISCORD_WEBHOOK, json={"content": message[:2000]})
    except Exception as e:
        logger.error(f"Discord alert failed: {e}")


async def send_multi_alert(app, subject: str, message: str):
    await send_alert_telegram(app, message)
    await send_alert_email(subject, message)
    await send_alert_slack(message)
    await send_alert_discord(message)


# ── Weekly Report Generator ────────────────────────────────────────────────

async def generate_weekly_report(db) -> str:
    week_ago = (datetime.utcnow() - timedelta(days=7)).isoformat()
    new_users = await db.fetchval("SELECT COUNT(*) FROM users WHERE joined_at >= ?", (week_ago,)) or 0
    scans = await db.fetchval("SELECT COUNT(*) FROM scan_history WHERE scanned_at >= ?", (week_ago,)) or 0
    threats = await db.fetchval("SELECT COUNT(*) FROM scan_history WHERE is_threat = 1 AND scanned_at >= ?", (week_ago,)) or 0
    vips = await db.fetchval("SELECT COUNT(*) FROM vip_users WHERE expires_at > datetime('now')") or 0
    total_users = await db.fetchval("SELECT COUNT(*) FROM users") or 0
    text = (
        f"📊 <b>Weekly Report</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"📅 Period: last 7 days\n"
        f"👥 New users: {new_users}\n"
        f"🔍 Scans: {scans}\n"
        f"🛡️ Threats: {threats}\n"
        f"⭐ Total VIP: {vips}\n"
        f"👤 Total users: {total_users}\n"
        f"━━━━━━━━━━━━━━\n"
        f"🤖 @AbdAleziz_1 | scanner_bot v{Config.BOT_VERSION}"
    )
    return text


class AdminHandler:
    def __init__(self, db: Database):
        self.db = db
        self._pending_broadcast = None

    def register(self, app: Client):
        @app.on_message(filters.command("addadmin") & filters.user(Config.SUDO_USERS))
        async def add_admin(client: Client, message: Message):
            if not message.reply_to_message:
                await message.reply("❌ يرجى الرد على رسالة المستخدم")
                return
            uid = message.reply_to_message.from_user.id
            await message.reply(f"✅ تمت إضافة {uid} كمسؤول\nملاحظة: صلاحية المسؤول تتحكم بها فقط متغير SUDO_USERS في البيئة")

        @app.on_message(filters.command("deladmin") & filters.user(Config.SUDO_USERS))
        async def del_admin(client: Client, message: Message):
            if not message.reply_to_message:
                await message.reply("❌ يرجى الرد على رسالة المستخدم")
                return
            uid = message.reply_to_message.from_user.id
            await message.reply(f"✅ تمت إزالة {uid} من المسؤولين")

        @app.on_message(filters.command("ban") & filters.user(Config.SUDO_USERS))
        async def ban_user(client: Client, message: Message):
            if not message.reply_to_message:
                await message.reply("❌ يرجى الرد على رسالة المستخدم")
                return
            uid = message.reply_to_message.from_user.id
            reason = message.text.split(maxsplit=1)[1] if len(message.text.split()) > 1 else "بدون سبب"
            await self.db.execute(
                "INSERT OR REPLACE INTO banned_users (user_id, reason, banned_at) VALUES (?, ?, ?)",
                (uid, reason, datetime.utcnow().isoformat()))
            await message.reply(f"✅ تم حظر المستخدم {uid}\nالسبب: {reason}")

        @app.on_message(filters.command("unban") & filters.user(Config.SUDO_USERS))
        async def unban_user(client: Client, message: Message):
            if not message.reply_to_message:
                await message.reply("❌ يرجى الرد على رسالة المستخدم")
                return
            uid = message.reply_to_message.from_user.id
            await self.db.execute("DELETE FROM banned_users WHERE user_id = ?", (uid,))
            await message.reply(f"✅ تم إلغاء حظر المستخدم {uid}")

        @app.on_message(filters.command("broadcast") & filters.user(Config.SUDO_USERS))
        async def broadcast(client: Client, message: Message):
            if not message.reply_to_message:
                await message.reply("❌ يرجى الرد على رسالة للإذاعة")
                return
            msg = message.reply_to_message.text or message.reply_to_message.caption or ""
            if not msg:
                await message.reply("❌ الرسالة فارغة")
                return
            preview = msg[:200] + "..." if len(msg) > 200 else msg
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ تأكيد", callback_data="broadcast_confirm"),
                 InlineKeyboardButton("❌ إلغاء", callback_data="broadcast_cancel")]
            ])
            await message.reply(
                f"📢 <b>معاينة الإذاعة:</b>\n━━━━━━━━━━━━━━\n{preview}\n━━━━━━━━━━━━━━\n"
                f"هل تريد إرسال هذه الرسالة لجميع المستخدمين؟",
                reply_markup=kb
            )
            self._pending_broadcast = {"text": msg, "user_id": message.from_user.id}

        @app.on_callback_query(filters.regex(r"^broadcast_"))
        async def broadcast_callback(client: Client, callback: CallbackQuery):
            action = callback.data.replace("broadcast_", "")
            if action == "cancel":
                await callback.message.edit("❌ تم إلغاء الإذاعة")
                self._pending_broadcast = None
                await callback.answer()
                return
            if action == "confirm":
                if not self._pending_broadcast:
                    await callback.answer("❌ انتهت صلاحية الطلب", show_alert=True)
                    return
                data = self._pending_broadcast
                self._pending_broadcast = None
                msg_text = data["text"]
                sent_msg = await callback.message.edit("📢 جاري الإذاعة...")
                users = await self.db.fetch("SELECT user_id FROM users")
                sent = 0
                failed = 0
                for u in users:
                    try:
                        await client.send_message(u["user_id"], msg_text)
                        sent += 1
                        await asyncio.sleep(0.05)
                    except Exception:
                        failed += 1
                await sent_msg.edit(f"✅ تم الإرسال لـ {sent} مستخدم\n❌ فشل: {failed}")
                try:
                    await self.db.execute(
                        "CREATE TABLE IF NOT EXISTS broadcast_history ("
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                        "text TEXT, sent_count INTEGER, failed_count INTEGER, "
                        "broadcasted_by INTEGER, created_at TEXT)"
                    )
                    await self.db.execute(
                        "INSERT INTO broadcast_history (text, sent_count, failed_count, broadcasted_by, created_at) "
                        "VALUES (?, ?, ?, ?, ?)",
                        msg_text[:500], sent, failed, data["user_id"], datetime.utcnow().isoformat()
                    )
                except Exception as e:
                    logger.error(f"Failed to log broadcast history: {e}")
                await callback.answer()

        @app.on_message(filters.command("stats") & filters.user(Config.SUDO_USERS))
        async def stats_cmd(client: Client, message: Message):
            users = await self.db.fetchval("SELECT COUNT(*) FROM users") or 0
            vips = await self.db.fetchval(
                "SELECT COUNT(*) FROM vip_users WHERE expires_at > datetime('now')") or 0
            scans_today = await self.db.fetchval(
                "SELECT COUNT(*) FROM scan_history WHERE date(scanned_at) = date('now')") or 0
            total_scans = await self.db.fetchval("SELECT COUNT(*) FROM scan_history") or 0
            threats = await self.db.fetchval("SELECT COUNT(*) FROM scan_history WHERE is_threat = 1") or 0
            banned = await self.db.fetchval("SELECT COUNT(*) FROM banned_users") or 0

            text = (
                f"📊 إحصائيات البوت\n"
                f"━━━━━━━━━━━━━━\n"
                f"👥 المستخدمين: {users}\n"
                f"⭐ VIP: {vips}\n"
                f"🔍 فحوصات اليوم: {scans_today}\n"
                f"📈 إجمالي الفحوصات: {total_scans}\n"
                f"🛡️ تهديدات: {threats}\n"
                f"🚫 محظورين: {banned}\n"
                f"🌐 لوحة التحكم: {Config.WEB_URL}\n"
                f"📡 Webhook: {'مفعل' if Config.WEBHOOK_MODE else 'غير مفعل'}\n"
                f"⚡ MCP: {'مفعل' if Config.ENABLE_MCP else 'غير مفعل'}\n"
                f"━━━━━━━━━━━━━━"
            )
            await message.reply(text)

        @app.on_message(filters.command("export") & filters.user(Config.SUDO_USERS))
        async def export_cmd(client: Client, message: Message):
            sent_msg = await message.reply("📦 جاري تصدير البيانات...")
            try:
                data = await self.db.export_to_json()
                f = io.BytesIO(data.encode())
                f.name = f"bot_backup_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
                await message.reply_document(f, caption="✅ نسخة احتياطية للبيانات")
                await self.db.execute(
                    "INSERT INTO import_export_log (action, user_id, record_count, created_at) VALUES (?, ?, ?, ?)",
                    ("export", message.from_user.id, 0, datetime.utcnow().isoformat()))
                await sent_msg.delete()
            except Exception as e:
                await sent_msg.edit(f"❌ خطأ في التصدير: {e}")

        @app.on_message(filters.command("import") & filters.user(Config.SUDO_USERS))
        async def import_cmd(client: Client, message: Message):
            if not message.reply_to_message or not message.reply_to_message.document:
                await message.reply("❌ يرجى الرد على ملف JSON للاستيراد")
                return
            sent_msg = await message.reply("📦 جاري استيراد البيانات...")
            try:
                file = await message.reply_to_message.download()
                with open(file, "r", encoding="utf-8") as f:
                    data = f.read()
                result = await self.db.import_from_json(data, message.from_user.id)
                os.remove(file)
                await sent_msg.edit(
                    f"✅ تم الاستيراد بنجاح\n"
                    f"📥 السجلات المستوردة: {result.get('imported', 0)}\n"
                    f"❌ الأخطاء: {result.get('errors', 0)}")
            except Exception as e:
                await sent_msg.edit(f"❌ خطأ في الاستيراد: {e}")

        @app.on_message(filters.command("logs") & filters.user(Config.SUDO_USERS))
        async def logs_cmd(client: Client, message: Message):
            try:
                if os.path.exists(Config.LOG_FILE):
                    with open(Config.LOG_FILE, "r", encoding="utf-8") as f:
                        content = f.read()
                    if len(content) > 4000:
                        content = content[-4000:]
                    await message.reply(f"📋 آخر السجلات:\n<pre>{content}</pre>")
                else:
                    await message.reply("❌ ملف السجلات غير موجود")
            except Exception as e:
                await message.reply(f"❌ خطأ: {e}")

        @app.on_message(filters.command("restart") & filters.user(Config.SUDO_USERS))
        async def restart_cmd(client: Client, message: Message):
            await message.reply("♻️ جاري إعادة التشغيل...")
            asyncio.get_event_loop().stop()

        @app.on_message(filters.command("clearcache") & filters.user(Config.SUDO_USERS))
        async def clearcache_cmd(client: Client, message: Message):
            await message.reply("🗑️ جاري مسح الذاكرة المؤقتة...")
            keys_to_delete = [k for k in list(self.db.cache._memory.keys()) if k.startswith("scan:")]
            for k in keys_to_delete:
                await self.db.cache.delete(k)
            if self.db.cache._redis_available and self.db.cache._redis:
                try:
                    keys = await self.db.cache._redis.keys("scan:*")
                    if keys:
                        await self.db.cache._redis.delete(*keys)
                except Exception:
                    pass
            await message.reply("✅ تم مسح الكاش")

        @app.on_message(filters.command("admin") & filters.user(Config.SUDO_USERS))
        async def admin_panel(client: Client, message: Message):
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("📊 إحصائيات", callback_data="admin_stats"),
                 InlineKeyboardButton("📢 إذاعة", callback_data="admin_broadcast")],
                [InlineKeyboardButton("📦 تصدير", callback_data="admin_export"),
                 InlineKeyboardButton("📥 استيراد", callback_data="admin_import")],
                [InlineKeyboardButton("🚫 حظر", callback_data="admin_ban"),
                 InlineKeyboardButton("✅ إلغاء حظر", callback_data="admin_unban")],
                [InlineKeyboardButton("🗑️ مسح كاش", callback_data="admin_clearcache"),
                 InlineKeyboardButton("♻️ إعادة تشغيل", callback_data="admin_restart")],
                [InlineKeyboardButton("⭐ منح VIP", callback_data="admin_grantvip"),
                 InlineKeyboardButton("🌐 لوحة الويب", url=Config.WEB_URL)],
            ])
            await message.reply("🛠️ لوحة تحكم المشرف", reply_markup=keyboard)

        @app.on_callback_query(filters.regex(r"^admin_"))
        async def admin_callback(client: Client, callback: CallbackQuery):
            action = callback.data.replace("admin_", "")
            if action == "stats":
                await stats_cmd(client, callback.message)
            elif action == "export":
                await export_cmd(client, callback.message)
            elif action == "clearcache":
                await clearcache_cmd(client, callback.message)
            elif action == "restart":
                await restart_cmd(client, callback.message)
            elif action == "grantvip":
                await callback.message.reply("📝 استخدم الأمر: /grantvip <معرف_المستخدم> <عدد_الأشهر>\nمثال: /grantvip 123456789 3")
            elif action in ("broadcast", "ban", "unban", "import"):
                await callback.message.reply(f"📝 استخدم الأمر /{action} بالطريقة الصحيحة")
            await callback.answer()

        # ── Audit Log (Feature 5) ──────────────────────────────────────────

        @app.on_message(filters.command("auditlog") & filters.user(Config.SUDO_USERS))
        async def auditlog_cmd(client: Client, message: Message):
            args = message.text.split(maxsplit=1)
            filter_uid = None
            if len(args) > 1:
                try:
                    filter_uid = int(args[1])
                except ValueError:
                    pass
            await self._show_audit_log(client, message, filter_uid, page=0, edit=False)

        @app.on_callback_query(filters.regex(r"^audit_page_"))
        async def audit_page_cb(client: Client, callback: CallbackQuery):
            parts = callback.data.split("_")
            if len(parts) >= 4:
                try:
                    filter_uid = int(parts[2]) if parts[2] != "0" else None
                    page = int(parts[3])
                    await self._show_audit_log(client, callback.message, filter_uid, page, edit=True)
                except (ValueError, IndexError):
                    await callback.answer("❌ Invalid page data", show_alert=True)
                    return
            await callback.answer()

        # ── Weekly Report (Feature 3) ──────────────────────────────────────

        @app.on_message(filters.command("weekly") & filters.user(Config.SUDO_USERS))
        async def weekly_cmd(client: Client, message: Message):
            report = await generate_weekly_report(self.db)
            await message.reply(report)

        @app.on_message(filters.command("report") & filters.user(Config.SUDO_USERS))
        async def report_cmd(client: Client, message: Message):
            report = await generate_weekly_report(self.db)
            await send_multi_alert(client, "Weekly Bot Report", report)
            await message.reply("✅ Report sent to all channels")

        # ── Command Blacklist (Feature 17) ─────────────────────────────────

        @app.on_message(filters.command("blacklist") & filters.user(Config.SUDO_USERS))
        async def blacklist_cmd(client: Client, message: Message):
            args = message.text.split(maxsplit=2)
            if len(args) < 3:
                rows = await self.db.fetch("SELECT * FROM command_blacklist ORDER BY created_at DESC LIMIT 50")
                if not rows:
                    await message.reply("✅ No blacklisted commands")
                    return
                text = "🚫 <b>Command Blacklist:</b>\n━━━━━━━━━━━━━━\n"
                for r in rows:
                    text += f"• User <code>{r['user_id']}</code> → /{r['command']}\n"
                await message.reply(text)
                return
            try:
                uid = int(args[1])
                cmd = args[2].lstrip("/")
                await self.db.execute(
                    "INSERT OR REPLACE INTO command_blacklist (user_id, command, blocked_by, created_at) VALUES (?, ?, ?, ?)",
                    uid, cmd, message.from_user.id, datetime.utcnow().isoformat()
                )
                await message.reply(f"✅ Blocked /{cmd} for user {uid}")
            except ValueError:
                await message.reply("❌ Invalid user ID")

        @app.on_message(filters.command("unblacklist") & filters.user(Config.SUDO_USERS))
        async def unblacklist_cmd(client: Client, message: Message):
            args = message.text.split(maxsplit=2)
            if len(args) < 3:
                await message.reply("Usage: /unblacklist <user_id> <command>")
                return
            try:
                uid = int(args[1])
                cmd = args[2].lstrip("/")
                await self.db.execute("DELETE FROM command_blacklist WHERE user_id = ? AND command = ?", uid, cmd)
                await message.reply(f"✅ Unblocked /{cmd} for user {uid}")
            except ValueError:
                await message.reply("❌ Invalid user ID")

        # ── Export/Import Config (Feature 16) ───────────────────────────────

        @app.on_message(filters.command("exportconfig") & filters.user(Config.SUDO_USERS))
        async def exportconfig_cmd(client: Client, message: Message):
            sent = await message.reply("📦 Exporting config...")
            try:
                config_vars = {}
                for attr in dir(Config):
                    if attr.isupper() and not attr.startswith("_"):
                        val = getattr(Config, attr)
                        if not callable(val):
                            if "KEY" in attr or "SECRET" in attr or "PASS" in attr or "TOKEN" in attr:
                                config_vars[attr] = "***REDACTED***"
                            else:
                                config_vars[attr] = str(val)
                import json
                data = json.dumps(config_vars, indent=2, ensure_ascii=False)
                f = io.BytesIO(data.encode())
                f.name = f"config_export_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
                await message.reply_document(f, caption="✅ Config exported (secrets redacted)")
                await sent.delete()
            except Exception as e:
                await sent.edit(f"❌ Config export error: {e}")

        @app.on_message(filters.command("importconfig") & filters.user(Config.SUDO_USERS))
        async def importconfig_cmd(client: Client, message: Message):
            if not message.reply_to_message or not message.reply_to_message.document:
                await message.reply("❌ Reply to a JSON config file to import")
                return
            sent = await message.reply("📦 Importing config...")
            try:
                file = await message.reply_to_message.download()
                import json
                with open(file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                os.remove(file)
                if not isinstance(data, dict):
                    await sent.edit("❌ Invalid config format: expected JSON object")
                    return
                env_path = os.path.join(os.getcwd(), ".env")
                lines = []
                if os.path.exists(env_path):
                    with open(env_path, "r") as f:
                        lines = f.read().splitlines()
                existing_keys = {}
                for line in lines:
                    if "=" in line and not line.strip().startswith("#"):
                        k, _, v = line.partition("=")
                        existing_keys[k.strip()] = v.strip()
                for key, val in data.items():
                    if key.isupper() and not key.startswith("_"):
                        existing_keys[key] = str(val)
                with open(env_path, "w") as f:
                    for k, v in existing_keys.items():
                        f.write(f"{k}={v}\n")
                from config import Config
                for key, val in existing_keys.items():
                    if hasattr(Config, key):
                        original = getattr(Config, key)
                        if isinstance(original, bool):
                            val = val.lower() in ('true', '1', 'yes')
                        elif isinstance(original, int):
                            try:
                                val = int(val)
                            except (ValueError, TypeError):
                                pass
                        elif isinstance(original, list):
                            pass  # keep as string, list parsing is complex
                        setattr(Config, key, val)
                await sent.edit(f"✅ Config imported ({len(data)} keys written to .env)")
            except Exception as e:
                await sent.edit(f"❌ Config import error: {e}")

    # ── Audit Log Helper with Pagination ────────────────────────────────────

    async def _show_audit_log(self, client, target, filter_uid: int = None, page: int = 0, edit: bool = False):
        page_size = 10
        offset = page * page_size
        if filter_uid:
            rows = await self.db.fetch(
                "SELECT * FROM audit_log WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?",
                filter_uid, page_size, offset
            )
            total = await self.db.fetchval(
                "SELECT COUNT(*) FROM audit_log WHERE user_id = ?", filter_uid
            ) or 0
        else:
            rows = await self.db.fetch(
                "SELECT * FROM audit_log ORDER BY created_at DESC LIMIT ? OFFSET ?",
                page_size, offset
            )
            total = await self.db.fetchval("SELECT COUNT(*) FROM audit_log") or 0

        if not rows:
            text = "📋 No audit log entries found."
            if edit:
                await target.edit(text)
            else:
                await target.reply(text)
            return

        total_pages = max(1, (total + page_size - 1) // page_size)
        text = f"📋 <b>Audit Log</b> (page {page + 1}/{total_pages})\n━━━━━━━━━━━━━━\n"
        for r in rows:
            uid = r.get("user_id", "?")
            action = r.get("action", "?")
            details = r.get("details", "") or ""
            ts = str(r.get("created_at", ""))[:19]
            text += f"• <code>{uid}</code> → {action}"
            if details:
                text += f": {details[:50]}"
            text += f"\n  🕐 {ts}\n"
        text += "━━━━━━━━━━━━━━"

        kb_buttons = []
        nav_row = []
        if page > 0:
            nav_row.append(InlineKeyboardButton("⬅️ Previous", callback_data=f"audit_page_{filter_uid or 0}_{page - 1}"))
        if offset + page_size < total:
            nav_row.append(InlineKeyboardButton("Next ➡️", callback_data=f"audit_page_{filter_uid or 0}_{page + 1}"))
        if nav_row:
            kb_buttons.append(nav_row)

        kb = InlineKeyboardMarkup(kb_buttons) if kb_buttons else None

        if edit:
            await target.edit(text, reply_markup=kb)
        else:
            await target.reply(text, reply_markup=kb)
