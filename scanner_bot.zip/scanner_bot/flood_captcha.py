import asyncio
import logging
import random
import string
import time
from collections import defaultdict
from datetime import datetime, timedelta

from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, ChatPermissions
from pyrogram.enums import ChatType

from config import Config
from database import Database

logger = logging.getLogger("flood_captcha")


class FloodCaptcha:
    def __init__(self, db: Database):
        self.db = db
        self._message_counts = defaultdict(list)
        self._captcha_store = {}
        self._quarantine_store = {}

    def register(self, app: Client):
        @app.on_message(filters.group & ~filters.service & ~filters.me)
        async def anti_flood(client: Client, message: Message):
            if not message.from_user:
                return

            user_id = message.from_user.id
            now = time.time()
            chat_id = message.chat.id

            # Track messages per user
            self._message_counts[user_id].append(now)

            # Keep only recent messages within time window
            self._message_counts[user_id] = [
                t for t in self._message_counts[user_id]
                if now - t < Config.TIME_WINDOW
            ]

            # Check flood threshold
            if len(self._message_counts[user_id]) > Config.MAX_MESSAGES:
                logger.warning(f"Flood detected: {user_id} in {chat_id}")

                # Capture captcha
                captcha_text = "".join(random.choices(string.ascii_uppercase + string.digits, k=5))
                self._captcha_store[user_id] = captcha_text

                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("🤖 تحقق", callback_data=f"captcha_{user_id}")]
                ])

                await message.reply(
                    f"⚠️ <b>تم اكتشاف نشاط غير طبيعي</b>\n\n"
                    f"@{(message.from_user.username or message.from_user.first_name or 'user')}\n"
                    f"يرجى حل الكابتشا للمتابعة\n\n"
                    f"<code>أرسل: {captcha_text}</code>",
                    reply_markup=keyboard
                )

                # Restrict user
                try:
                    await client.restrict_chat_member(
                        chat_id, user_id,
                        permissions=ChatPermissions(can_send_messages=False),
                        until_date=datetime.utcnow() + timedelta(minutes=5)
                    )
                except Exception:
                    pass

                # Delete original message
                try:
                    await message.delete()
                except Exception:
                    pass

                self._message_counts[user_id] = []

        @app.on_callback_query(filters.regex(r"^captcha_"))
        async def captcha_callback(client: Client, callback: CallbackQuery):
            user_id = int(callback.data.split("_")[1])
            if callback.from_user.id != user_id:
                await callback.answer("❌ هذا ليس كابتشا الخاص بك", show_alert=True)
                return

            captcha = self._captcha_store.get(user_id, "")
            if not captcha:
                await callback.answer("✅ تم التحقق مسبقاً", show_alert=True)
                return

            await callback.message.edit(
                f"🧩 <b>حل الكابتشا</b>\n\n"
                f"أرسل هذا النص للتحقق:\n"
                f"<code>{captcha}</code>"
            )
            await callback.answer()

        @app.on_message(filters.group & filters.text)
        async def captcha_solver(client: Client, message: Message):
            if not message.from_user:
                return

            user_id = message.from_user.id
            captcha = self._captcha_store.get(user_id)

            if captcha and message.text.strip() == captcha:
                del self._captcha_store[user_id]

                # Unrestrict user
                try:
                    await client.unban_chat_member(message.chat.id, user_id)
                except Exception:
                    pass

                try:
                    await message.reply("✅ تم التحقق بنجاح!")
                    await asyncio.sleep(2)
                    await message.delete()
                except Exception:
                    pass

        @app.on_message(filters.command("quarantine") & filters.group)
        async def quarantine_cmd(client: Client, message: Message):
            if not message.reply_to_message:
                await message.reply("❌ يرجى الرد على رسالة المستخدم")
                return

            target = message.reply_to_message.from_user
            if not target:
                return

            # Restrict user (read only)
            try:
                await client.restrict_chat_member(
                    message.chat.id, target.id,
                    permissions=ChatPermissions(can_send_messages=False),
                    until_date=datetime.utcnow() + timedelta(hours=24)
                )
                await message.reply(f"✅ تم وضع {target.mention} في الحجر الصحي")
            except Exception as e:
                await message.reply(f"❌ خطأ: {e}")

        @app.on_message(filters.command("unquarantine") & filters.group)
        async def unquarantine_cmd(client: Client, message: Message):
            if not message.reply_to_message:
                await message.reply("❌ يرجى الرد على رسالة المستخدم")
                return

            target = message.reply_to_message.from_user
            if not target:
                return

            try:
                await client.unban_chat_member(message.chat.id, target.id)
                await message.reply(f"✅ تم إلغاء الحجر الصحي عن {target.mention}")
            except Exception as e:
                await message.reply(f"❌ خطأ: {e}")
