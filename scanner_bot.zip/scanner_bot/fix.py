#!/usr/bin/env python3
"""Fix common deployment issues for justrunmy.app"""
import os
import sys
import subprocess
from pathlib import Path

def check_imports():
    missing = []
    for lib in ["pyrogram", "aiohttp", "aiosqlite", "jinja2", "aiohttp_jinja2",
                "httpx", "whois", "cryptography", "PIL", "yaml", "humanize"]:
        try:
            __import__(lib.replace("-", "_"))
        except ImportError:
            missing.append(lib)
    return missing

def fix():
    print("🔧 Fixing deployment...")
    
    # 1. Create data directory
    Path("data").mkdir(parents=True, exist_ok=True)
    print("✅ data/ directory created")
    
    # 2. Create uploads directory
    Path("uploads").mkdir(parents=True, exist_ok=True)
    print("✅ uploads/ directory created")
    
    # 3. Check environment variables
    required = ["BOT_TOKEN", "API_ID", "API_HASH", "SUDO_USERS"]
    for var in required:
        if not os.getenv(var):
            print(f"⚠️  Missing env var: {var}")
    
    # 4. Check imports
    missing = check_imports()
    if missing:
        print(f"📦 Installing missing packages: {', '.join(missing)}")
        subprocess.check_call([sys.executable, "-m", "pip", "install", *missing])
        print("✅ Packages installed")
    else:
        print("✅ All imports OK")
    
    # 5. Fix config if PORT env var is set (justrunmy.app)
    port = os.getenv("PORT")
    if port:
        os.environ["WEB_PORT"] = port
        print(f"✅ Using PORT={port} from environment")
    
    # 6. Disable MCP if not configured
    if os.getenv("ENABLE_MCP", "false") != "true":
        print("✅ MCP disabled")
    
    print("\n✅ All fixes applied. Run: python main.py")

if __name__ == "__main__":
    fix()
