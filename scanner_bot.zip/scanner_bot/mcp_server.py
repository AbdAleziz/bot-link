import json
import logging
from datetime import datetime

from config import Config

logger = logging.getLogger("mcp_server")


class MCPServer:
    def __init__(self, bot=None, db=None, dashboard=None, scanner=None):
        self.bot = bot
        self.db = db
        self.dashboard = dashboard
        self.scanner = scanner

    def _get_tools(self) -> list:
        return [
            {
                "name": "get_bot_stats",
                "description": "Get bot statistics (users, VIPs, scans, threats)",
                "inputSchema": {"type": "object", "properties": {}}
            },
            {
                "name": "scan_url",
                "description": "Scan a URL for threats",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "url": {"type": "string", "description": "URL to scan"}
                    },
                    "required": ["url"]
                }
            },
            {
                "name": "broadcast_message",
                "description": "Send a broadcast message to all users",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "message": {"type": "string", "description": "Message text"}
                    },
                    "required": ["message"]
                }
            },
            {
                "name": "get_user_info",
                "description": "Get user information by Telegram ID",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "user_id": {"type": "number", "description": "Telegram user ID"}
                    },
                    "required": ["user_id"]
                }
            },
            {
                "name": "ban_user",
                "description": "Ban a user from using the bot",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "user_id": {"type": "number", "description": "Telegram user ID"},
                        "reason": {"type": "string", "description": "Ban reason"}
                    },
                    "required": ["user_id"]
                }
            },
            {
                "name": "unban_user",
                "description": "Unban a user",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "user_id": {"type": "number", "description": "Telegram user ID"}
                    },
                    "required": ["user_id"]
                }
            },
            {
                "name": "add_vip",
                "description": "Grant VIP status to a user",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "user_id": {"type": "number", "description": "Telegram user ID"},
                        "duration": {"type": "string", "description": "Duration: week, month, lifetime"}
                    },
                    "required": ["user_id", "duration"]
                }
            },
            {
                "name": "get_recent_scans",
                "description": "Get recent scan results",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "limit": {"type": "number", "description": "Number of results (default 10)"}
                    }
                }
            },
            {
                "name": "get_blacklist",
                "description": "Get the current blacklist",
                "inputSchema": {"type": "object", "properties": {}}
            },
            {
                "name": "restart_bot",
                "description": "Restart the bot (trigger graceful shutdown)",
                "inputSchema": {"type": "object", "properties": {}}
            },
        ]

    async def handle_request(self, request: dict) -> dict:
        method = request.get("method", "")
        req_id = request.get("id")

        if method == "tools/list":
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {"tools": self._get_tools()}
            }

        if method == "tools/call":
            params = request.get("params", {})
            tool_name = params.get("name", "")
            tool_args = params.get("arguments", {})

            result = await self._execute_tool(tool_name, tool_args)
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {"content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}]}
            }

        if method == "initialize":
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "protocolVersion": "2025-03-26",
                    "serverInfo": {"name": "scan_bot", "version": "2.0.0"},
                    "capabilities": {"tools": {}}
                }
            }

        if method == "ping":
            return {"jsonrpc": "2.0", "id": req_id, "result": "pong"}

        return {"jsonrpc": "2.0", "id": req_id, "error": {"code": -32601, "message": "Method not found"}}

    async def _execute_tool(self, name: str, args: dict) -> dict:
        if name == "get_bot_stats":
            if not self.dashboard:
                return {"error": "dashboard not available"}
            return await self.dashboard._get_stats()

        if name == "scan_url":
            if not self.scanner:
                return {"error": "scanner not available"}
            url = args.get("url", "")
            if not url:
                return {"error": "url required"}
            try:
                return await self.scanner.scan_url(url, priority=True)
            except Exception as e:
                return {"error": str(e)}

        if name == "broadcast_message":
            if not self.bot:
                return {"error": "bot not available"}
            msg = args.get("message", "")
            if not msg:
                return {"error": "message required"}
            try:
                users = await self.db.fetch("SELECT user_id FROM users")
                sent = 0
                for u in users:
                    try:
                        await self.bot.send_message(u["user_id"], msg)
                        sent += 1
                    except Exception:
                        continue
                return {"status": "ok", "sent": sent, "total": len(users)}
            except Exception as e:
                return {"error": str(e)}

        if name == "get_user_info":
            uid = args.get("user_id", 0)
            if not uid:
                return {"error": "user_id required"}
            user = await self.db.fetchrow("SELECT * FROM users WHERE user_id = ?", (uid,))
            if not user:
                return {"error": "user not found"}
            return dict(user)

        if name == "ban_user":
            uid = args.get("user_id", 0)
            reason = args.get("reason", "MCP action")
            await self.db.execute("INSERT OR REPLACE INTO banned_users (user_id, reason, banned_at) VALUES (?, ?, ?)",
                                  (uid, reason, datetime.utcnow().isoformat()))
            return {"status": "banned", "user_id": uid}

        if name == "unban_user":
            uid = args.get("user_id", 0)
            await self.db.execute("DELETE FROM banned_users WHERE user_id = ?", (uid,))
            return {"status": "unbanned", "user_id": uid}

        if name == "add_vip":
            uid = args.get("user_id", 0)
            duration = args.get("duration", "week")
            from vip_system import VipSystem
            vip = VipSystem(self.db)
            result = await vip.grant_vip(uid, duration)
            return result if result else {"error": "failed to grant VIP"}

        if name == "get_recent_scans":
            limit = min(args.get("limit", 10), 100)
            results = await self.db.fetch(
                "SELECT * FROM scan_history ORDER BY scanned_at DESC LIMIT ?", (limit,)
            )
            return {"results": [dict(r) for r in results]} if results else {"results": []}

        if name == "get_blacklist":
            rows = await self.db.fetch("SELECT * FROM blacklist ORDER BY added_at DESC")
            return {"blacklist": [dict(r) for r in rows]} if rows else {"blacklist": []}

        if name == "restart_bot":
            asyncio.get_event_loop().stop()
            return {"status": "restarting"}

        return {"error": f"unknown tool: {name}"}
