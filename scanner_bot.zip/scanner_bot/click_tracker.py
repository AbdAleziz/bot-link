import asyncio
import logging
import random
from datetime import datetime, timedelta
from urllib.parse import urlparse

from config import Config
from database import Database

logger = logging.getLogger("click_tracker")


class ClickTracker:
    def __init__(self, db: Database):
        self.db = db

    def _generate_short_code(self) -> str:
        alphabet = Config.SHORT_URL_ALPHABET
        length = Config.SHORT_URL_LENGTH
        return "".join(random.choice(alphabet) for _ in range(length))

    async def create_short_url(self, original_url: str, created_by: int = None,
                               expires_in_days: int = 0) -> dict:
        parsed = urlparse(original_url)
        if not parsed.scheme:
            original_url = "https://" + original_url

        short_code = self._generate_short_code()

        exists = await self.db.fetchval(
            "SELECT id FROM short_links WHERE short_code = ?", (short_code,)
        )
        while exists:
            short_code = self._generate_short_code()
            exists = await self.db.fetchval(
                "SELECT id FROM short_links WHERE short_code = ?", (short_code,)
            )

        expires_at = None
        if expires_in_days > 0:
            expires_at = (datetime.utcnow() + timedelta(days=expires_in_days)).isoformat()

        await self.db.execute(
            "INSERT INTO short_links (short_code, original_url, created_by, expires_at, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (short_code, original_url, created_by, expires_at, datetime.utcnow().isoformat())
        )

        short_url = f"{Config.WEB_URL}/r/{short_code}"
        logger.info(f"Created short URL: {short_url} -> {original_url}")
        return {"short_code": short_code, "short_url": short_url, "original_url": original_url}

    async def resolve_short_url(self, short_code: str) -> str | None:
        link = await self.db.fetchrow(
            "SELECT original_url, expires_at FROM short_links WHERE short_code = ?",
            (short_code,)
        )
        if not link:
            return None

        if link["expires_at"]:
            try:
                expires = datetime.fromisoformat(link["expires_at"])
                if expires < datetime.utcnow():
                    return None
            except ValueError:
                pass

        return link["original_url"]

    async def record_click(self, short_code: str, ip: str = None,
                           user_agent: str = None, referer: str = None) -> bool:
        link = await self.db.fetchrow(
            "SELECT id FROM short_links WHERE short_code = ?", (short_code,)
        )
        if not link:
            return False

        await self.db.execute(
            "INSERT INTO click_logs (link_id, ip, user_agent, referer, clicked_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (link["id"], ip, user_agent, referer, datetime.utcnow().isoformat())
        )
        return True

    async def get_click_stats(self, short_code: str) -> dict | None:
        link = await self.db.fetchrow(
            "SELECT * FROM short_links WHERE short_code = ?", (short_code,)
        )
        if not link:
            return None

        total_clicks = await self.db.fetchval(
            "SELECT COUNT(*) FROM click_logs WHERE link_id = ?", (link["id"],)
        ) or 0

        unique_ips = await self.db.fetchval(
            "SELECT COUNT(DISTINCT ip) FROM click_logs WHERE link_id = ? AND ip IS NOT NULL",
            (link["id"],)
        ) or 0

        recent = await self.db.fetch(
            "SELECT * FROM click_logs WHERE link_id = ? ORDER BY clicked_at DESC LIMIT 20",
            (link["id"],)
        )

        return {
            "short_code": short_code,
            "original_url": link["original_url"],
            "created_at": link["created_at"],
            "total_clicks": total_clicks,
            "unique_ips": unique_ips,
            "recent_clicks": [dict(r) for r in recent] if recent else [],
        }

    async def get_all_links(self, limit: int = 50) -> list[dict]:
        rows = await self.db.fetch(
            "SELECT sl.*, (SELECT COUNT(*) FROM click_logs WHERE link_id = sl.id) as clicks "
            "FROM short_links sl ORDER BY sl.created_at DESC LIMIT ?",
            (limit,)
        )
        return [dict(r) for r in rows] if rows else []

    async def cleanup_expired(self):
        await self.db.execute(
            "DELETE FROM short_links WHERE expires_at IS NOT NULL AND expires_at < ?",
            (datetime.utcnow().isoformat(),)
        )
        logger.info("Cleaned up expired short links")
