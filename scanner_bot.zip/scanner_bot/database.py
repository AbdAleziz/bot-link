import asyncio
import json
import logging
import sqlite3
import time
from datetime import datetime
from pathlib import Path

from config import Config

logger = logging.getLogger("database")


class CacheLayer:
    """In-memory cache with optional Redis backend for scan results and frequent queries."""

    def __init__(self):
        self._memory = {}
        self._ttl = {}
        self._redis = None
        self._redis_available = False

    async def init(self):
        if Config.REDIS_URL:
            try:
                import redis.asyncio as aioredis
                self._redis = aioredis.from_url(Config.REDIS_URL, decode_responses=True)
                await self._redis.ping()
                self._redis_available = True
                logger.info("Redis cache connected")
            except Exception as e:
                logger.warning(f"Redis unavailable, using memory cache: {e}")

    async def get(self, key: str) -> str | None:
        if self._redis_available:
            try:
                return await self._redis.get(key)
            except Exception:
                pass
        val = self._memory.get(key)
        if val and key in self._ttl:
            if time.time() > self._ttl[key]:
                self._memory.pop(key, None)
                self._ttl.pop(key, None)
                return None
        return val

    async def set(self, key: str, value: str, ttl: int = Config.CACHE_TTL):
        if self._redis_available:
            try:
                await self._redis.setex(key, ttl, value)
                return
            except Exception:
                pass
        self._memory[key] = value
        self._ttl[key] = time.time() + ttl

    async def delete(self, key: str):
        if self._redis_available:
            try:
                await self._redis.delete(key)
                return
            except Exception:
                pass
        self._memory.pop(key, None)
        self._ttl.pop(key, None)

    async def close(self):
        if self._redis_available and self._redis:
            await self._redis.close()


class Database:
    def __init__(self):
        self._pool = None
        self._sqlite_conn = None
        self._lock = asyncio.Lock()
        self.cache = CacheLayer()
        self._postgres = Config.USE_POSTGRES and bool(Config.DATABASE_URL and "postgres" in Config.DATABASE_URL)

    async def init(self):
        await self.cache.init()
        if self._postgres:
            await self._init_postgres()
        else:
            await self._init_sqlite()
        await self._run_migrations()

    async def _init_sqlite(self):
        db_path = Config.DATABASE_URL.replace("sqlite+aiosqlite:///", "")
        if not db_path:
            db_path = "bot.db"
        db_path = Path(db_path)
        db_path.parent.mkdir(parents=True, exist_ok=True)

        self._conn = sqlite3.connect(str(db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.execute("PRAGMA synchronous=1")
        self._conn.execute("PRAGMA cache_size=-8000")
        self._conn.execute("PRAGMA foreign_keys=ON")

        self._sqlite_pool = asyncio.Queue()
        for _ in range(Config.DB_POOL_SIZE):
            self._sqlite_pool.put_nowait(None)

        logger.info(f"SQLite database initialized: {db_path}")

    async def _init_postgres(self):
        try:
            import asyncpg
            self._pool = await asyncpg.create_pool(
                Config.DATABASE_URL,
                min_size=2,
                max_size=Config.DB_POOL_SIZE
            )
            logger.info("PostgreSQL database initialized")
        except Exception as e:
            logger.error(f"PostgreSQL init failed, falling back to SQLite: {e}")
            self._postgres = False
            await self._init_sqlite()

    async def _run_migrations(self):
        await self.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                is_banned INTEGER DEFAULT 0,
                joined_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS banned_users (
                user_id INTEGER PRIMARY KEY,
                reason TEXT,
                banned_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS vip_users (
                user_id INTEGER PRIMARY KEY,
                expires_at TEXT,
                plan TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS scan_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT,
                domain TEXT,
                user_id INTEGER,
                is_threat INTEGER DEFAULT 0,
                threat_type TEXT,
                trust_score REAL,
                vt_positives INTEGER,
                scanner_result TEXT,
                scanned_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS blacklist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern TEXT UNIQUE,
                reason TEXT,
                added_by INTEGER,
                added_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS whitelist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern TEXT UNIQUE,
                added_by INTEGER,
                added_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS domain_watch (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                domain TEXT UNIQUE,
                user_id INTEGER,
                added_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS support_tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                message TEXT,
                reply TEXT,
                status TEXT DEFAULT 'open',
                created_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS pending_payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                plan TEXT,
                amount INTEGER,
                currency TEXT,
                invoice_id TEXT,
                status TEXT DEFAULT 'pending',
                created_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS short_links (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                short_code TEXT UNIQUE,
                original_url TEXT,
                created_by INTEGER,
                expires_at TEXT,
                created_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS click_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                link_id INTEGER,
                ip TEXT,
                user_agent TEXT,
                referer TEXT,
                clicked_at TEXT,
                FOREIGN KEY (link_id) REFERENCES short_links(id)
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS import_export_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action TEXT,
                user_id INTEGER,
                filename TEXT,
                record_count INTEGER,
                created_at TEXT
            )
        """)
        await self.execute("""
            CREATE TABLE IF NOT EXISTS api_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT UNIQUE,
                user_id INTEGER,
                permissions TEXT DEFAULT 'read',
                is_active INTEGER DEFAULT 1,
                created_at TEXT
            )
        """)

        # Indexes
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_scan_history_scanned_at ON scan_history(scanned_at)")
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_scan_history_url ON scan_history(url)")
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_short_links_code ON short_links(short_code)")
        await self.execute(
            "CREATE INDEX IF NOT EXISTS idx_click_logs_link ON click_logs(link_id)")

        logger.info("Database migrations complete")

    async def execute(self, query: str, *args, **kwargs):
        if self._postgres and self._pool:
            async with self._pool.acquire() as conn:
                return await conn.execute(query, *args)
        else:
            loop = asyncio.get_event_loop()
            cur = await loop.run_in_executor(None, self._conn.execute, query, args)
            self._conn.commit()
            return cur

    async def fetchval(self, query: str, *args):
        if self._postgres and self._pool:
            async with self._pool.acquire() as conn:
                return await conn.fetchval(query, *args)
        else:
            loop = asyncio.get_event_loop()
            cur = await loop.run_in_executor(None, self._conn.execute, query, args)
            row = cur.fetchone()
            return row[0] if row else None

    async def fetchrow(self, query: str, *args):
        if self._postgres and self._pool:
            async with self._pool.acquire() as conn:
                row = await conn.fetchrow(query, *args)
                return dict(row) if row else None
        else:
            loop = asyncio.get_event_loop()
            cur = await loop.run_in_executor(None, self._conn.execute, query, args)
            row = cur.fetchone()
            return dict(row) if row else None

    async def fetch(self, query: str, *args):
        if self._postgres and self._pool:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(query, *args)
                return [dict(r) for r in rows]
        else:
            loop = asyncio.get_event_loop()
            cur = await loop.run_in_executor(None, self._conn.execute, query, args)
            rows = cur.fetchall()
            return [dict(r) for r in rows]

    async def export_to_json(self, tables: list[str] = None) -> str:
        if tables is None:
            tables = ["users", "vip_users", "blacklist", "whitelist", "banned_users", "config"]
        data = {}
        for table in tables:
            try:
                rows = await self.fetch(f"SELECT * FROM {table}")
                data[table] = rows
            except Exception:
                data[table] = []
        return json.dumps(data, ensure_ascii=False, indent=2)

    async def import_from_json(self, json_str: str, user_id: int = None) -> dict:
        result = {"imported": 0, "errors": 0, "tables": {}}
        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            return {"error": "Invalid JSON"}

        for table, rows in data.items():
            if not rows:
                continue
            count = 0
            for row in rows:
                try:
                    columns = ", ".join(row.keys())
                    placeholders = ", ".join(["?"] * len(row))
                    await self.execute(
                        f"INSERT OR REPLACE INTO {table} ({columns}) VALUES ({placeholders})",
                        *row.values()
                    )
                    count += 1
                except Exception:
                    result["errors"] += 1
            result["tables"][table] = count
            result["imported"] += count

        if user_id:
            await self.execute(
                "INSERT INTO import_export_log (action, user_id, record_count, created_at) VALUES (?, ?, ?, ?)",
                ("import", user_id, result["imported"], datetime.utcnow().isoformat())
            )

        return result

    async def close(self):
        await self.cache.close()
        if self._postgres and self._pool:
            await self._pool.close()
        elif hasattr(self, '_conn'):
            self._conn.close()
        logger.info("Database closed")
