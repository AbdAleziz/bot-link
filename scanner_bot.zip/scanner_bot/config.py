import os


class Config:
    # Bot
    BOT_TOKEN = os.getenv("BOT_TOKEN", "")
    API_ID = int(os.getenv("API_ID", "0"))
    API_HASH = os.getenv("API_HASH", "")
    SUDO_USERS = [int(x) for x in os.getenv("SUDO_USERS", "").split(",") if x]

    # Database
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///bot.db")
    REDIS_URL = os.getenv("REDIS_URL", "")  # Optional: redis://localhost:6379/0
    USE_POSTGRES = os.getenv("USE_POSTGRES", "false").lower() == "true"
    DB_POOL_SIZE = int(os.getenv("DB_POOL_SIZE", "10"))

    # Scanner
    VIRUSTOTAL_API_KEY = os.getenv("VIRUSTOTAL_API_KEY", "")
    URLSCAN_API_KEY = os.getenv("URLSCAN_API_KEY", "")
    SCAN_TIMEOUT = int(os.getenv("SCAN_TIMEOUT", "30"))
    MAX_REDIRECTS = int(os.getenv("MAX_REDIRECTS", "10"))

    # VIP
    STAR_PRICE_WEEK = int(os.getenv("STAR_PRICE_WEEK", "100"))
    STAR_PRICE_MONTH = int(os.getenv("STAR_PRICE_MONTH", "300"))
    STAR_PRICE_LIFETIME = int(os.getenv("STAR_PRICE_LIFETIME", "1000"))
    CURRENCY = os.getenv("CURRENCY", "XTR")
    VIP_SCAN_LIMIT = int(os.getenv("VIP_SCAN_LIMIT", "200"))

    # Flood / Captcha
    MAX_MESSAGES = int(os.getenv("MAX_MESSAGES", "5"))
    TIME_WINDOW = int(os.getenv("TIME_WINDOW", "3"))
    BAN_DURATION = int(os.getenv("BAN_DURATION", "300"))
    QUARANTINE_CHANNEL = int(os.getenv("QUARANTINE_CHANNEL", "0"))
    MIN_ACCOUNT_AGE = int(os.getenv("MIN_ACCOUNT_AGE", "259200"))

    # Web Dashboard
    WEB_HOST = os.getenv("WEB_HOST", "0.0.0.0")
    WEB_PORT = int(os.getenv("WEB_PORT", "8080"))
    WEB_URL = os.getenv("WEB_URL", "http://localhost:8080")
    WEB_SECRET = os.getenv("WEB_SECRET", "changeme")
    ENABLE_DASHBOARD = os.getenv("ENABLE_DASHBOARD", "true").lower() == "true"
    DASHBOARD_USER = os.getenv("DASHBOARD_USER", "admin")
    DASHBOARD_PASS = os.getenv("DASHBOARD_PASS", "admin123")

    # Webhook
    WEBHOOK_MODE = os.getenv("WEBHOOK_MODE", "false").lower() == "true"
    WEBHOOK_URL = os.getenv("WEBHOOK_URL", "")
    WEBHOOK_PATH = os.getenv("WEBHOOK_PATH", "/webhook")
    WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "")

    # Click Tracker
    SHORT_URL_LENGTH = int(os.getenv("SHORT_URL_LENGTH", "6"))
    SHORT_URL_ALPHABET = os.getenv("SHORT_URL_ALPHABET",
                                   "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")

    # MCP Server
    ENABLE_MCP = os.getenv("ENABLE_MCP", "false").lower() == "true"
    MCP_PORT = int(os.getenv("MCP_PORT", "9090"))

    # Threat Intel API
    ENABLE_THREAT_API = os.getenv("ENABLE_THREAT_API", "true").lower() == "true"
    THREAT_API_KEY = os.getenv("THREAT_API_KEY", "")  # External API key for threat intel

    # Cache
    CACHE_TTL = int(os.getenv("CACHE_TTL", "300"))  # seconds
    SCAN_CACHE_TTL = int(os.getenv("SCAN_CACHE_TTL", "3600"))

    # Batch Upload
    MAX_BATCH_SIZE = int(os.getenv("MAX_BATCH_SIZE", "100"))
    ALLOWED_EXTENSIONS = {"txt", "csv"}

    # Health
    HEALTH_CHECK_INTERVAL = int(os.getenv("HEALTH_CHECK_INTERVAL", "30"))  # seconds

    # Logging
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE = os.getenv("LOG_FILE", "bot.log")
