#!/usr/bin/env bash
# One-shot installer for ghost-bot fixes package.
# - Backs up the 4 original files into .backups/
# - Copies the 4 fixed files over the originals
# - Syntax-checks every file (restores from backup if any fails)
# - Restarts the bot and watches the log for the 6 known errors
set -e

RED='\033[0;31m'; GRN='\033[0;32m'; YEL='\033[1;33m'; CYN='\033[0;36m'; RST='\033[0m'
info() { echo -e "${CYN}[*]${RST} $*"; }
ok()   { echo -e "${GRN}[✓]${RST} $*"; }
warn() { echo -e "${YEL}[!]${RST} $*"; }
fail() { echo -e "${RED}[✗]${RST} $*"; }

# ---- locate project root ---------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR=""
for cand in "$SCRIPT_DIR/.." "$SCRIPT_DIR"; do
  cand_real="$(cd "$cand" 2>/dev/null && pwd || true)"
  if [ -n "$cand_real" ] && [ -f "$cand_real/main.py" ]; then
    PROJECT_DIR="$cand_real"; break
  fi
done
if [ -z "$PROJECT_DIR" ]; then
  for cand in "$HOME/ghost/deploy-package" "$HOME/deploy-package" "/root/ghost/deploy-package"; do
    if [ -f "$cand/main.py" ]; then PROJECT_DIR="$cand"; break; fi
  done
fi
if [ -z "$PROJECT_DIR" ] || [ ! -f "$PROJECT_DIR/main.py" ]; then
  fail "Can't find deploy-package (looked for main.py)."
  fail "Run this script from inside the project dir, or set PROJECT_DIR=/path"
  exit 1
fi
info "Project: $PROJECT_DIR"
info "Source : $SCRIPT_DIR"

# ---- backup ----------------------------------------------------------------
TS=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="$PROJECT_DIR/.backups"
mkdir -p "$BACKUP_DIR"

FILES=(
  "main.py:main.py"
  "database.py:database.py"
  "services/payment_flow.py:services/payment_flow.py"
  "support/handlers.py:support/handlers.py"
)

info "Backing up originals → $BACKUP_DIR/"
for pair in "${FILES[@]}"; do
  src_rel="${pair%%:*}"; dst_rel="${pair##*:}"
  src="$SCRIPT_DIR/$src_rel"; dst="$PROJECT_DIR/$dst_rel"
  [ ! -f "$src" ] && { fail "Missing source file in zip: $src"; exit 1; }
  if [ -f "$dst" ]; then
    cp "$dst" "$BACKUP_DIR/$(basename "$dst_rel").$TS.bak"
    ok "Backed up: $dst_rel"
  else
    warn "Destination missing (will create): $dst_rel"
    mkdir -p "$(dirname "$dst")"
  fi
done

# ---- copy fixed files ------------------------------------------------------
info "Copying fixed files..."
for pair in "${FILES[@]}"; do
  src_rel="${pair%%:*}"; dst_rel="${pair##*:}"
  src="$SCRIPT_DIR/$src_rel"; dst="$PROJECT_DIR/$dst_rel"
  cp "$src" "$dst"
  ok "Wrote: $dst_rel"
done

# ---- syntax check ----------------------------------------------------------
info "Syntax-checking all 4 files..."
all_ok=true
for pair in "${FILES[@]}"; do
  dst_rel="${pair##*:}"; dst="$PROJECT_DIR/$dst_rel"
  if python3 -c "import ast; ast.parse(open('$dst').read())" 2>/dev/null; then
    ok "syntax OK: $dst_rel"
  else
    fail "syntax ERROR: $dst_rel"
    all_ok=false
  fi
done
if [ "$all_ok" = "false" ]; then
  fail "Syntax errors found. Restoring from backup..."
  for pair in "${FILES[@]}"; do
    dst_rel="${pair##*:}"; dst="$PROJECT_DIR/$dst_rel"
    bak="$BACKUP_DIR/$(basename "$dst_rel").$TS.bak"
    [ -f "$bak" ] && cp "$bak" "$dst" && ok "Restored: $dst_rel"
  done
  exit 1
fi

# ---- venv + restart --------------------------------------------------------
if [ -f "$PROJECT_DIR/venv/bin/activate" ]; then
  # shellcheck disable=SC1091
  source "$PROJECT_DIR/venv/bin/activate"
  ok "venv activated"
fi

info "Stopping any running bot..."
( cd "$PROJECT_DIR" && pkill -f "python.*main\.py" 2>/dev/null ) && ok "Killed previous" || ok "No previous"
sleep 1

mkdir -p "$PROJECT_DIR/logs"
LOG_FILE="$PROJECT_DIR/logs/bot.log"
TS_LOG=$(date +%Y%m%d_%H%M%S)
HIST_LOG="$PROJECT_DIR/logs/bot.$TS_LOG.log"
[ -f "$LOG_FILE" ] && cp "$LOG_FILE" "$HIST_LOG"
: > "$LOG_FILE"

info "Starting bot..."
( cd "$PROJECT_DIR" && nohup python3 main.py >> "$LOG_FILE" 2>&1 & )
sleep 2
ok "Bot started"

info "Watching log for 12s..."
echo "----------------------------------------------------------------"
( cd "$PROJECT_DIR" && timeout 12 tail -n 60 -f "$LOG_FILE" ) &
TAIL_PID=$!
sleep 12
kill $TAIL_PID 2>/dev/null || true
echo "----------------------------------------------------------------"

echo
if pgrep -f "python.*main\.py" > /dev/null 2>&1; then
  ok "Bot is RUNNING"
else
  fail "Bot exited. Last 40 lines:"
  echo
  tail -n 40 "$LOG_FILE"
  exit 1
fi

# ---- post-check: detect the 6 errors we fixed -----------------------------
ERRORS=()
grep -qE "NameError: name 'filters' is not defined" "$LOG_FILE" && ERRORS+=("filters import (payment_flow.py)")
grep -qE "NameError: name 'idle' is not defined"    "$LOG_FILE" && ERRORS+=("idle import (main.py)")
grep -qE "bad operand type for unary ~"              "$LOG_FILE" && ERRORS+=("filters.command (handlers.py)")
grep -qE "Incorrect number of bindings supplied"     "$LOG_FILE" && ERRORS+=("db args (database.py)")
grep -qE "Error binding parameter 0 - probably"      "$LOG_FILE" && ERRORS+=("db binding type (database.py)")
grep -qE "coroutine 'register_(pricing_admin|audit_log|batch_scanner|trial_guard|support_handlers)' was never awaited" "$LOG_FILE" && ERRORS+=("missing await (main.py)")

if [ ${#ERRORS[@]} -gt 0 ]; then
  fail "Some errors still present:"
  printf '  - %s\n' "${ERRORS[@]}"
  exit 1
fi

if grep -q "Bot is ready" "$LOG_FILE"; then
  ok "✅ 'Bot is ready!' — looks healthy!"
fi

OTHER=$(grep -E "ERROR|WARNING" "$LOG_FILE" | grep -vE "Support auto-close disabled|Memory watchdog" | head -10 || true)
if [ -n "$OTHER" ]; then
  echo
  warn "Other log lines worth a glance:"
  echo "$OTHER"
fi

echo
ok "All 6 fixes applied and verified."
echo
echo "  Quick commands:"
echo "      tail -f $PROJECT_DIR/$LOG_FILE"
echo "      pgrep -f 'python.*main.py'"
echo "      pkill -f 'python.*main.py'   # stop"
echo
