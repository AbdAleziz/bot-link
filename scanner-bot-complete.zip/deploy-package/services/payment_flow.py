# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

"""Iraqi manual payment flow — Fawateer, Zain Cash, FIB, QiCard, Mastercard/Visa."""
import asyncio
import logging
import os
import secrets
from datetime import datetime, timedelta

from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from config import Config
from config.payment_config import (
    PAYMENT_CONTACTS,
    PAYMENT_ACCOUNT_HOLDER,
    PRICING,
    PRICING_DISPLAY,
    REQUEST_EXPIRY_HOURS,
    ENABLE_STARS_PAYMENT,
)
from database import Database
from vip_system import VipSystem

logger = logging.getLogger("payment_flow")


def generate_reference_code() -> str:
    return f"LK-{secrets.token_hex(3).upper()}"


def build_duration_keyboard():
    buttons = []
    for plan_id, info in PRICING_DISPLAY.items():
        buttons.append([
            InlineKeyboardButton(
                f"{info['label']} — {info['price']:,} د.ع",
                callback_data=f"pdur_{plan_id}"
            )
        ])
    buttons.append([InlineKeyboardButton("🔙 رجوع", callback_data="nav_home")])
    return InlineKeyboardMarkup(buttons)


def build_method_keyboard(plan: str):
    buttons = [
        [InlineKeyboardButton("💳 Mastercard/Visa — تحويل بنكي", callback_data=f"pmethod_{plan}_mastercard")],
        [InlineKeyboardButton("📱 Zain Cash", callback_data=f"pmethod_{plan}_zain_cash")],
        [InlineKeyboardButton("🏦 FIB", callback_data=f"pmethod_{plan}_fib")],
        [InlineKeyboardButton("💳 QiCard", callback_data=f"pmethod_{plan}_qicard")],
        [InlineKeyboardButton("🔙 رجوع", callback_data="nav_vip")],
    ]
    return InlineKeyboardMarkup(buttons)


def build_confirm_keyboard(ref_code: str):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ حوّلت المبلغ", callback_data=f"pconf_{ref_code}")],
        [InlineKeyboardButton("❌ إلغاء", callback_data=f"pcancel_{ref_code}")],
    ])


def build_admin_action_keyboard(ref_code: str):
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ تأكيد التحويل", callback_data=f"pverify_{ref_code}"),
            InlineKeyboardButton("❌ رفض", callback_data=f"preject_{ref_code}"),
        ],
        [InlineKeyboardButton("💬 مراسلة المستخدم", callback_data=f"pmsg_{ref_code}")],
    ])


def build_instructions_message(method_code: str, method_name: str, amount: int, ref_code: str, account_holder: str) -> str:
    contact = PAYMENT_CONTACTS.get(method_code, "")
    lines = [
        "╔══════════════════════════════════════════╗",
        f"║ {method_name} — تفعيل VIP",
        "║",
        f"║ 💰 المبلغ: {amount:,} د.ع",
        "║",
    ]
    if contact:
        lines.append("║ 📞 حوّل المبلغ إلى الرقم:")
        lines.append(f"║     {contact}")
    if account_holder:
        lines.append(f"║     (حساب: {account_holder})")
    lines.extend([
        "║",
        f"║ 🔖 كود مرجعي خاص بطلبك:",
        f"║     {ref_code}",
        "║",
        f"║ ⚠️ مهم جداً: اكتب الكود {ref_code}",
        "║    بخانة \"ملاحظة التحويل\" بتطبيق بنكك",
        "║",
        "╚══════════════════════════════════════════╝",
    ])
    return "\n".join(lines)


def build_message_user_keyboard(ref_code: str):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 رجوع", callback_data=f"pback_{ref_code}")],
    ])


class PaymentFlow:
    def __init__(self, db: Database, vip_system: VipSystem):
        self.db = db
        self.vip = vip_system
        self._pending_messages = {}

    async def notify_admins(self, client: Client, text: str, reply_markup=None):
        for admin_id in Config.SUDO_USERS:
            try:
                await client.send_message(admin_id, text, reply_markup=reply_markup)
            except Exception as e:
                logger.error(f"Failed to notify admin {admin_id}: {e}")

    async def cmd_vip_start(self, client: Client, message: Message):
        user_id = message.from_user.id
        banned = await self.db.fetchrow("SELECT * FROM banned_users WHERE user_id = ?", (user_id,))
        if banned:
            await message.reply("🚫 أنت محظور من استخدام البوت.")
            return
        vip = await self.db.fetchrow(
            "SELECT expires_at FROM vip_users WHERE user_id = ? AND expires_at > datetime('now')",
            (user_id,)
        )
        if vip:
            await message.reply(
                f"⭐ <b>أنت مشترك VIP بالفعل!</b>\n"
                f"━━━━━━━━━━━━━━\n"
                f"✅ اشتراكك نشط حتى {vip['expires_at'][:10]}\n"
                f"استخدم /vip لعرض التفاصيل"
            )
            return
        await message.reply(
            "⭐ <b>ترقية الحساب إلى VIP</b>\n"
            "━━━━━━━━━━━━━━\n"
            "اختر مدة الاشتراك المناسبة لك:",
            reply_markup=build_duration_keyboard()
        )

    async def cb_payment_duration(self, client: Client, cb: CallbackQuery):
        plan = cb.data.replace("pdur_", "")
        info = PRICING_DISPLAY.get(plan)
        if not info:
            await cb.answer("❌ خيار غير صالح")
            return
        text = (
            f"⭐ <b>اشتراك {info['label']}</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"💰 المبلغ: {info['price']:,} د.ع\n\n"
            f"اختر وسيلة الدفع:"
        )
        await cb.message.edit(text, reply_markup=build_method_keyboard(plan))
        await cb.answer()

    async def cb_payment_method(self, client: Client, cb: CallbackQuery):
        parts = cb.data.split("_", 2)
        if len(parts) < 3:
            await cb.answer("❌ خطأ في البيانات")
            return
        _, plan, method_code = parts
        user_id = cb.from_user.id

        pricing_info = PRICING.get(plan)
        if not pricing_info:
            await cb.answer("❌ خطة غير صالحة")
            return

        method_row = await self.db.fetchrow(
            "SELECT name, icon, contact_info, account_holder FROM payment_methods WHERE code = ? AND active = 1",
            (method_code,)
        )
        method_name = method_row["name"] if method_row else method_code
        account_holder = (method_row.get("account_holder") or PAYMENT_ACCOUNT_HOLDER) if method_row else PAYMENT_ACCOUNT_HOLDER

        amount = pricing_info["iqd"]
        duration_days = pricing_info["days"]

        for _ in range(5):
            ref_code = generate_reference_code()
            existing = await self.db.fetchrow(
                "SELECT id FROM payment_requests WHERE reference_code = ?", (ref_code,)
            )
            if not existing:
                break
        else:
            await cb.answer("❌ حدث خطأ، حاول مرة أخرى")
            return

        now = datetime.utcnow()
        expires_at = now + timedelta(hours=REQUEST_EXPIRY_HOURS)

        await self.db.execute(
            "INSERT INTO payment_requests (user_id, reference_code, amount, currency, method_id, plan, duration_days, status, created_at, expires_at) "
            "VALUES (?, ?, ?, ?, (SELECT id FROM payment_methods WHERE code = ?), ?, ?, 'pending', ?, ?)",
            (user_id, ref_code, amount, "IQD", method_code, plan, duration_days, now.isoformat(), expires_at.isoformat())
        )

        msg = build_instructions_message(method_code, method_name, amount, ref_code, account_holder)
        await cb.message.edit(msg, reply_markup=build_confirm_keyboard(ref_code))
        await cb.answer()

    async def cb_payment_confirmed(self, client: Client, cb: CallbackQuery):
        ref_code = cb.data.replace("pconf_", "")
        user_id = cb.from_user.id

        request = await self.db.fetchrow(
            "SELECT pr.*, pm.name as method_name, pm.code as method_code FROM payment_requests pr "
            "LEFT JOIN payment_methods pm ON pr.method_id = pm.id "
            "WHERE pr.reference_code = ? AND pr.user_id = ? AND pr.status = 'pending'",
            (ref_code, user_id)
        )
        if not request:
            await cb.answer("❌ لم يتم العثور على الطلب أو تمت معالجته مسبقاً")
            return

        now = datetime.utcnow()
        expires = datetime.fromisoformat(request["expires_at"])
        if now > expires:
            await self.db.execute(
                "UPDATE payment_requests SET status = 'expired' WHERE reference_code = ?",
                (ref_code,)
            )
            await cb.answer("❌ انتهت صلاحية الطلب، استخدم /vip لإنشاء طلب جديد")
            return

        user = cb.from_user
        admin_text = (
            f"🔔 <b>طلب تفعيل VIP جديد</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"👤 {user.mention} — ID: <code>{user_id}</code>\n"
            f"💰 {request['amount']:,} د.ع\n"
            f"💳 {request.get('method_name', '')}\n"
            f"🔖 {ref_code}\n"
            f"📋 الخطة: {request['plan']}\n"
            f"⏰ منذ: 2 دقيقة\n"
            f"━━━━━━━━━━━━━━"
        )
        await self.notify_admins(client, admin_text, reply_markup=build_admin_action_keyboard(ref_code))

        await cb.message.edit(
            "✅ <b>شكراً!</b> أرسلنا إشعار للإدارة.\n"
            "سيتم تفعيل VIP خلال دقائق بعد التأكيد.\n\n"
            "📞 <a href=\"tg://user?id=7849476337\">تواصل مع الدعم</a>"
        )
        await cb.answer()

    async def cb_payment_cancel(self, client: Client, cb: CallbackQuery):
        ref_code = cb.data.replace("pcancel_", "")
        user_id = cb.from_user.id

        await self.db.execute(
            "UPDATE payment_requests SET status = 'rejected' WHERE reference_code = ? AND user_id = ?",
            (ref_code, user_id)
        )
        await cb.message.edit("❌ تم إلغاء الطلب.\nاستخدم /vip لإنشاء طلب جديد.")
        await cb.answer()

    async def cb_admin_verify(self, client: Client, cb: CallbackQuery):
        admin_id = cb.from_user.id
        if admin_id not in Config.SUDO_USERS:
            await cb.answer("❌ غير مصرح")
            return

        ref_code = cb.data.replace("pverify_", "")
        request = await self.db.fetchrow(
            "SELECT * FROM payment_requests WHERE reference_code = ? AND status = 'pending'",
            (ref_code,)
        )
        if not request:
            await cb.answer("❌ الطلب غير موجود أو تمت معالجته مسبقاً")
            return

        user_id = request["user_id"]
        plan = request["plan"]

        result = await self.vip.grant_vip(user_id, plan)
        if "error" in result:
            await cb.answer(f"❌ فشل التفعيل: {result['error']}")
            return

        now = datetime.utcnow()
        await self.db.execute(
            "UPDATE payment_requests SET status = 'verified', verified_at = ?, verified_by = ? WHERE reference_code = ?",
            (now.isoformat(), admin_id, ref_code)
        )

        pdf_path = None
        try:
            pdf_path = await self.generate_receipt_pdf(user_id, request, result)
        except Exception as e:
            logger.error(f"PDF generation error: {e}")

        try:
            await client.send_message(
                user_id,
                f"🎉 <b>تم تفعيل VIP بنجاح!</b>\n"
                f"━━━━━━━━━━━━━━\n"
                f"📆 المدة: {request['duration_days']} يوم\n"
                f"🔚 ينتهي: {result['expires_at'][:10]}\n"
                f"━━━━━━━━━━━━━━"
            )
        except Exception as e:
            logger.error(f"Failed to notify user {user_id}: {e}")

        if pdf_path and os.path.exists(pdf_path):
            for target_id in [user_id, *Config.SUDO_USERS]:
                try:
                    await client.send_document(
                        target_id, pdf_path,
                        caption=f"🧾 إيصال دفع VIP | كود: {ref_code}"
                    )
                except Exception as e:
                    logger.error(f"Failed to send PDF to {target_id}: {e}")
            try:
                os.remove(pdf_path)
                logger.info(f"Deleted receipt PDF: {pdf_path}")
            except Exception as e:
                logger.error(f"Delete PDF failed: {e}")

        admin_notify = (
            f"✅ <b>تم تأكيد الدفع وتفعيل VIP</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"👤 المستخدم: <code>{user_id}</code>\n"
            f"💳 الوسيلة: {request.get('plan', '')}\n"
            f"💰 المبلغ: {request['amount']:,} د.ع\n"
            f"🔖 الكود: {ref_code}\n"
            f"🔚 VIP ينتهي: {result['expires_at'][:10]}\n"
            f"━━━━━━━━━━━━━━"
        )
        await self.notify_admins(client, admin_notify)

        await cb.message.edit(
            f"{admin_notify}\n\n✅ تمت المعالجة بواسطة: {cb.from_user.mention}"
        )
        await cb.answer("✅ تم تفعيل VIP بنجاح")

    async def cb_admin_reject(self, client: Client, cb: CallbackQuery):
        admin_id = cb.from_user.id
        if admin_id not in Config.SUDO_USERS:
            await cb.answer("❌ غير مصرح")
            return

        ref_code = cb.data.replace("preject_", "")
        request = await self.db.fetchrow(
            "SELECT * FROM payment_requests WHERE reference_code = ? AND status = 'pending'",
            (ref_code,)
        )
        if not request:
            await cb.answer("❌ الطلب غير موجود أو تمت معالجته مسبقاً")
            return

        await self.db.execute(
            "UPDATE payment_requests SET status = 'rejected', verified_at = ?, verified_by = ? WHERE reference_code = ?",
            (datetime.utcnow().isoformat(), admin_id, ref_code)
        )

        user_id = request["user_id"]
        try:
            await client.send_message(
                user_id,
                "❌ <b>عذراً، لم يتم تأكيد الدفع.</b>\n"
                "يرجى التواصل مع الدعم للمساعدة.\n"
                "يمكنك استخدام /vip لإنشاء طلب جديد."
            )
        except Exception as e:
            logger.error(f"Failed to notify user {user_id}: {e}")

        await cb.message.edit(
            f"❌ <b>تم رفض الطلب</b>\n"
            f"🔖 {ref_code}\n"
            f"تم الإلغاء بواسطة: {cb.from_user.mention}"
        )
        await cb.answer("❌ تم رفض الطلب")

    async def cb_admin_message_user(self, client: Client, cb: CallbackQuery):
        admin_id = cb.from_user.id
        if admin_id not in Config.SUDO_USERS:
            await cb.answer("❌ غير مصرح")
            return

        ref_code = cb.data.replace("pmsg_", "")
        request = await self.db.fetchrow(
            "SELECT * FROM payment_requests WHERE reference_code = ?", (ref_code,)
        )
        if not request:
            await cb.answer("❌ الطلب غير موجود")
            return

        user_id = request["user_id"]
        self._pending_messages[admin_id] = user_id

        await cb.message.reply(
            f"📝 أرسل الرسالة التي تريد إرسالها للمستخدم <code>{user_id}</code>:\n"
            f"(اكتب /cancel للإلغاء)"
        )
        await cb.answer()

    async def handle_admin_message(self, client: Client, message: Message):
        admin_id = message.from_user.id
        if admin_id not in Config.SUDO_USERS:
            return

        target_id = self._pending_messages.pop(admin_id, None)
        if not target_id:
            return

        text = message.text.strip()
        if text == "/cancel":
            await message.reply("✅ تم إلغاء الإرسال.")
            return

        try:
            await client.send_message(target_id, f"📩 رسالة من الإدارة:\n\n{text}")
            await message.reply(f"✅ تم إرسال الرسالة إلى <code>{target_id}</code>")
        except Exception as e:
            await message.reply(f"❌ فشل الإرسال: {e}")

    async def cleanup_expired_requests(self):
        try:
            await self.db.execute(
                "UPDATE payment_requests SET status = 'expired' "
                "WHERE status = 'pending' AND expires_at < datetime('now')"
            )
        except Exception as e:
            logger.error(f"Cleanup expired requests error: {e}")

    async def generate_receipt_pdf(self, user_id: int, request: dict, grant_result: dict) -> str:
        pid = f"PAY-{request['reference_code']}"
        filename = f"/tmp/{pid}.pdf"

        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.lib import colors
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
            from reportlab.lib.units import mm
            import arabic_reshaper
            from bidi.algorithm import get_display

            def reshape_text(text: str) -> str:
                reshaped = arabic_reshaper.reshape(text)
                return get_display(reshaped)

            doc = SimpleDocTemplate(
                filename, pagesize=A4,
                rightMargin=20*mm, leftMargin=20*mm,
                topMargin=20*mm, bottomMargin=20*mm,
            )

            styles = getSampleStyleSheet()
            title_style = ParagraphStyle(
                'ArabicTitle', parent=styles['Title'],
                fontSize=20, alignment=1, spaceAfter=10
            )
            normal_style = ParagraphStyle(
                'ArabicNormal', parent=styles['Normal'],
                fontSize=11, spaceAfter=4, leading=14
            )

            elements = []
            elements.append(Paragraph(reshape_text("إيصال دفع — scanner_bot"), title_style))
            elements.append(Spacer(1, 6*mm))

            data = [
                [reshape_text("رقم الإيصال"), pid],
                [reshape_text("معرف المستخدم"), str(user_id)],
                [reshape_text("المبلغ"), f"{request['amount']:,} د.ع"],
                [reshape_text("وسيلة الدفع"), reshape_text(str(request.get('method_name', request.get('plan', ''))))],
                [reshape_text("الكود المرجعي"), request['reference_code']],
                [reshape_text("تاريخ العملية"), datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')],
                [reshape_text("مدة الاشتراك"), f"{request['duration_days']} يوم"],
                [reshape_text("ينتهي VIP"), grant_result.get('expires_at', '')[:10]],
                [reshape_text("الحالة"), reshape_text("مدفوع ✅")],
            ]

            table = Table(data, colWidths=[100*mm, 80*mm])
            table.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (-1, -1)),  # Use default Helvetica for ASCII, Arabic needs separate font
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
                ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ]))
            elements.append(table)
            elements.append(Spacer(1, 10*mm))
            elements.append(Paragraph(reshape_text("شكراً لاشتراكك! — scanner_bot"), normal_style))

            doc.build(elements)
            logger.info(f"PDF receipt generated: {filename}")
        except ImportError:
            logger.warning("reportlab/arabic_reshaper not installed, using fpdf2")
            try:
                from fpdf import FPDF
                pdf = FPDF()
                pdf.add_page()
                pdf.add_font('DejaVu', '', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', uni=True)
                pdf.set_font('DejaVu', '', 16)
                title = "إيصال دفع - scanner_bot"
                pdf.cell(0, 10, title, ln=True, align='C')
                pdf.line(10, 20, 200, 20)
                pdf.ln(10)
                pdf.set_font('DejaVu', '', 10)
                lines = [
                    f"رقم الإيصال: {pid}",
                    f"معرف المستخدم: {user_id}",
                    f"المبلغ: {request['amount']:,} IQD",
                    f"وسيلة الدفع: {request.get('method_name', request.get('plan', ''))}",
                    f"الكود المرجعي: {request['reference_code']}",
                    f"التاريخ: {datetime.utcnow().strftime('%Y-%m-%d %H:%M')} UTC",
                    f"المدة: {request['duration_days']} يوم",
                    f"ينتهي VIP: {grant_result.get('expires_at', '')[:10]}",
                    "الحالة: مدفوع ✅",
                ]
                for line in lines:
                    pdf.cell(0, 8, line, ln=True)
                pdf.output(filename)
                logger.info(f"PDF (fpdf2) generated: {filename}")
            except Exception as e:
                logger.error(f"PDF fallback failed: {e}")
                return None
        except Exception as e:
            logger.error(f"PDF generation failed: {e}")
            return None

        return filename

    def register(self, app: Client):
        """Register payment flow handlers if Stars payment is disabled."""
        if ENABLE_STARS_PAYMENT:
            logger.info("Stars payment enabled, skipping Iraqi manual payment flow")
            return

        self.app = app
        app.db = self.db

        @app.on_message(filters.command("vip") & filters.private)
        async def _vip_cmd(client: Client, message: Message):
            await self.cmd_vip_start(client, message)

        @app.on_callback_query(filters.regex(r"^pdur_"))
        async def _pdur_cb(client: Client, cb: CallbackQuery):
            await self.cb_payment_duration(client, cb)

        @app.on_callback_query(filters.regex(r"^pmethod_"))
        async def _pmethod_cb(client: Client, cb: CallbackQuery):
            await self.cb_payment_method(client, cb)

        @app.on_callback_query(filters.regex(r"^pconf_"))
        async def _pconf_cb(client: Client, cb: CallbackQuery):
            await self.cb_payment_confirmed(client, cb)

        @app.on_callback_query(filters.regex(r"^pcancel_"))
        async def _pcancel_cb(client: Client, cb: CallbackQuery):
            await self.cb_payment_cancel(client, cb)

        @app.on_callback_query(filters.regex(r"^pverify_"))
        async def _pverify_cb(client: Client, cb: CallbackQuery):
            await self.cb_admin_verify(client, cb)

        @app.on_callback_query(filters.regex(r"^preject_"))
        async def _preject_cb(client: Client, cb: CallbackQuery):
            await self.cb_admin_reject(client, cb)

        @app.on_callback_query(filters.regex(r"^pmsg_"))
        async def _pmsg_cb(client: Client, cb: CallbackQuery):
            await self.cb_admin_message_user(client, cb)

        @app.on_message(filters.text & filters.private & filters.user(Config.SUDO_USERS))
        async def _admin_msg_handler(client: Client, message: Message):
            await self.handle_admin_message(client, message)

        logger.info("Iraqi manual payment flow registered")
