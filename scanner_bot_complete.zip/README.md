# scanner_bot — Telegram link scanner

A Telegram bot that scans URLs for threats (VirusTotal, urlscan, WHOIS, SSL,
local blacklist/whitelist), ships with a web dashboard for admins, and
supports VIP subscriptions.

## Local development

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env and replace the placeholders with your real values
python fix.py              # creates data/ + uploads/, sanity-checks env
python main.py
```

The bot starts in **polling** mode by default. The web dashboard is
exposed on `http://localhost:8080/` (Basic auth: whatever you put in
`DASHBOARD_USER` / `DASHBOARD_PASS`).

## Security warning

> ⚠️ **The `.env` file in this repository originally contained real secrets (BOT_TOKEN, API_ID, API_HASH, etc.).**
> If you forked or downloaded this repo before the fix, you MUST rotate ALL secrets immediately:
> 1. Go to @BotFather and send `/revoke` to get a new BOT_TOKEN.
> 2. Go to my.telegram.org → Apps → delete the old app and create a new one.
> 3. Regenerate your VirusTotal and urlscan.io API keys.
> 4. Change your Telegram password and enable 2FA.

## Project layout

```
scanner_bot/
├── main.py              # entrypoint: wires everything together
├── config.py            # all env-var driven settings
├── config/
│   ├── __init__.py
│   └── payment_config.py  # Iraqi manual payment pricing + contacts
├── database.py          # SQLite (default) + optional Turso/libSQL / Postgres
├── scanner.py           # URL scanner (VT, urlscan, WHOIS, SSL, redirects)
├── admin.py             # /ban, /broadcast, /stats, /export, ...
├── vip_handlers.py      # /vip, /bulkscan, /domainwatch, /whitelist (Stars)
├── vip_system.py        # VIP grants via Telegram Stars
├── services/
│   ├── __init__.py
│   └── payment_flow.py  # Iraqi manual payment flow (Fawateer, Zain Cash, FIB, QiCard, Mastercard)
├── flood_captcha.py     # group anti-flood + captcha
├── click_tracker.py     # short-link tracking
├── web_dashboard.py     # aiohttp web UI + REST API
├── mcp_server.py        # JSON-RPC MCP server (off by default)
├── fix.py               # startup sanity checks
├── scripts/
│   ├── migrate_to_turso.py  # SQLite → Turso/libSQL migration
│   └── load_secrets.sh      # SOPS/age encrypted secrets loader
├── templates/
│   └── dashboard.html   # admin web UI
├── static/              # static assets (empty, ready for use)
├── uploads/             # runtime: bulk-scan files
├── data/                # runtime: bot.db, bot.session, bot.log
├── requirements.txt
├── justrunmy.yml        # deployment manifest (reference only)
├── Dockerfile           # alternative: Docker Image deploy
├── .env.example         # placeholders — copy to .env for local dev
└── .env                 # real secrets — NEVER commit this (in .gitignore)
```

## VIP payment — two modes

### 1. Iraqi manual payment (default, `ENABLE_STARS_PAYMENT=false`)

For Iraqi users who cannot use Stripe/PayPal. Supports:

| Method | Description |
|---|---|
| 💳 Mastercard/Visa | Bank transfer to admin's phone number |
| 📱 Zain Cash | e-wallet transfer |
| 🏦 FIB | FIB app transfer |
| 💳 QiCard | QiCard transfer |

**Flow:** `/vip` → choose duration → choose method → see admin's phone number with reference code → admin confirms → VIP activated + PDF receipt sent.

Set your receiving numbers in `.env`:
```
RECEIVE_MASTERCARD=0770XXXXXXX
RECEIVE_ZAIN_CASH=0770XXXXXXX
RECEIVE_FIB=0770XXXXXXX
RECEIVE_QICARD=0770XXXXXXX
PRICE_MONTH_IQD=5000
PRICE_QUARTER_IQD=12000
PRICE_YEAR_IQD=40000
PRICE_LIFETIME_IQD=150000
```

### 2. Telegram Stars (opt-in, `ENABLE_STARS_PAYMENT=true`)

Uses Telegram's native Stars payment system. Enable by setting:
```
ENABLE_STARS_PAYMENT=true
```
The existing `/vip` handler from `vip_handlers.py` will be used.

## Turso/libSQL (persistent cloud database)

By default the bot uses a local SQLite file. For platforms with ephemeral
filesystem (like justrunmy.app), you can use Turso — a hosted SQLite.

1. Sign up at https://turso.tech
2. Install CLI: `brew install tursodatabase/tap/turso`
3. Create a database:
   ```bash
   turso db create scanner-bot-prod
   turso db tokens create scanner-bot-prod
   ```
4. Set in `.env`:
   ```
   DATABASE_URL=libsql://scanner-bot-prod.turso.io
   TURSO_AUTH_TOKEN=...
   ```
5. Run the migration script to copy existing data:
   ```bash
   pip install libsql-experimental
   python scripts/migrate_to_turso.py
   ```
6. Start the bot — it auto-detects `libsql://` URLs and uses Turso.
   Falls back to SQLite if Turso is unavailable.

## SOPS/age encryption (VPS phase)

For production VPS, encrypt secrets with Mozilla SOPS + age:

```bash
# Install tools
sudo apt install age
# Download sops from https://github.com/getsops/sops/releases

# Generate keypair
sudo mkdir -p /etc/scanner_bot
age-keygen -o /etc/scanner_bot/keys.age

# Create and encrypt secrets
sops --encrypt --age "$(cat /etc/scanner_bot/keys.age.pub)" secrets.yaml

# Start the bot
chmod +x scripts/load_secrets.sh
./scripts/load_secrets.sh
```

## Deploying to justrunmy.app

### Build the zip (without secrets)

```bash
zip -r bot.zip . -x '.env' 'data/*' '__pycache__/*' '*.pyc' '.venv/*'
```

### Upload & configure

In the justrunmy.app dashboard:

- **Run Command**: `python main.py`
- **Port**: `8080`  (the web dashboard + health check)
- **OS**: Linux
- **Environment variables**: at minimum, set
  - `BOT_TOKEN`
  - `API_ID`
  - `API_HASH`
  - `SUDO_USERS` (comma-separated Telegram user ids)
  - `DASHBOARD_PASS` (change the default!)
- **Persistent volume**: mount `/app/data` (≥ 256 MB) so the SQLite
  database and `bot.session` survive restarts.

### Verify

- The platform polls `GET /health` every 30s. Expect:
  `{"status":"healthy","database":"connected",...}`
- Open `https://<your-app>.justrunmy.app/` — browser prompts for Basic auth.

## Phase 2 (planned)

- Screenshot preview (Playwright/Chromium or external API)
- Advanced MFA for admin commands
