#!/usr/bin/env bash
# =============================================================================
# Load encrypted secrets from secrets.yaml using Mozilla SOPS + age
# and start the bot.
#
# Prerequisites (VPS only):
#   sudo apt install age
#   Install sops binary from https://github.com/getsops/sops/releases
#
# Setup:
#   age-keygen -o /etc/scanner_bot/keys.age
#   export SOPS_AGE_KEY_FILE=/etc/scanner_bot/keys.age
#   sops --encrypt --age "$(cat /etc/scanner_bot/keys.age.pub)" secrets.yaml
#
# Usage:
#   chmod +x scripts/load_secrets.sh
#   ./scripts/load_secrets.sh
# =============================================================================

set -e

# Path to the age private key (keep this safe!)
SOPS_AGE_KEY_FILE="${SOPS_AGE_KEY_FILE:-/etc/scanner_bot/keys.age}"

if [ ! -f "$SOPS_AGE_KEY_FILE" ]; then
    echo "❌ Age key not found at $SOPS_AGE_KEY_FILE"
    echo "   Generate one: age-keygen -o $SOPS_AGE_KEY_FILE"
    exit 1
fi

export SOPS_AGE_KEY_FILE

SECRETS_FILE="${SECRETS_FILE:-secrets.yaml}"

if [ ! -f "$SECRETS_FILE" ]; then
    echo "⚠️  Encrypted secrets file not found at $SECRETS_FILE"
    echo "   Falling back to .env file"
    if [ -f ".env" ]; then
        set -a
        source .env
        set +a
    fi
    exec python main.py
fi

echo "🔐 Decrypting $SECRETS_FILE..."
set -a
eval "$(sops --decrypt "$SECRETS_FILE" | sed 's/: /=/g' | sed 's/^/export /')"
set +a

echo "🚀 Starting scanner_bot..."
exec python main.py
