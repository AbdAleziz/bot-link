#!/usr/bin/env python3
"""
Migration script: local SQLite → Turso (libSQL).

Usage:
    pip install libsql-experimental
    python scripts/migrate_to_turso.py

Environment variables:
    SOURCE_DB        — path to local SQLite file (default: data/bot.db)
    DATABASE_URL     — Turso database URL (e.g. libsql://scanner-bot-prod.turso.io)
    TURSO_AUTH_TOKEN — Turso auth token

The script reads schema + data from local SQLite and recreates everything
in Turso. Existing tables in Turso are dropped first.
"""

import asyncio
import logging
import os
import sqlite3
import sys

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("migrate_to_turso")


async def get_sqlite_tables(conn: sqlite3.Connection) -> list[dict]:
    cur = conn.execute("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
    return [{"name": row[0], "sql": row[1]} for row in cur.fetchall()]


async def get_sqlite_indexes(conn: sqlite3.Connection) -> list[dict]:
    cur = conn.execute("SELECT name, sql FROM sqlite_master WHERE type='index' AND sql IS NOT NULL")
    return [{"name": row[0], "sql": row[1]} for row in cur.fetchall()]


async def get_table_data(conn: sqlite3.Connection, table: str) -> tuple[list[str], list[tuple]]:
    cur = conn.execute(f"SELECT * FROM \"{table}\"")
    columns = [desc[0] for desc in cur.description]
    rows = cur.fetchall()
    return columns, rows


async def main():
    source_db = os.getenv("SOURCE_DB", "data/bot.db")
    turso_url = os.getenv("DATABASE_URL", "")
    turso_token = os.getenv("TURSO_AUTH_TOKEN", "")

    if not turso_url or "libsql" not in turso_url:
        logger.error("DATABASE_URL must be a libsql:// URL. Set it in your .env")
        sys.exit(1)

    if not turso_token:
        logger.error("TURSO_AUTH_TOKEN is required")
        sys.exit(1)

    if not os.path.exists(source_db):
        logger.error(f"Source database not found: {source_db}")
        sys.exit(1)

    # Connect to local SQLite
    logger.info(f"Connecting to local SQLite: {source_db}")
    sqlite_conn = sqlite3.connect(source_db)
    sqlite_conn.row_factory = sqlite3.Row

    # Connect to Turso
    try:
        import libsql_experimental as libsql
        turso_conn = libsql.connect(database=turso_url, auth_token=turso_token)
        logger.info(f"Connected to Turso: {turso_url}")
    except ImportError:
        logger.error("libsql_experimental not installed. Run: pip install libsql-experimental")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Failed to connect to Turso: {e}")
        sys.exit(1)

    # Get schema from local SQLite
    tables = await get_sqlite_tables(sqlite_conn)
    indexes = await get_sqlite_indexes(sqlite_conn)

    logger.info(f"Found {len(tables)} tables and {len(indexes)} indexes in local DB")

    # Drop existing tables in Turso and recreate
    for table in tables:
        logger.info(f"Recreating table: {table['name']}")
        turso_conn.execute(f"DROP TABLE IF EXISTS \"{table['name']}\"")
        turso_conn.execute(table["sql"])

    # Recreate indexes
    for idx in indexes:
        logger.info(f"Creating index: {idx['name']}")
        try:
            turso_conn.execute(idx["sql"])
        except Exception as e:
            logger.warning(f"Could not create index {idx['name']}: {e}")

    # Migrate data
    total_rows = 0
    for table in tables:
        name = table["name"]
        columns, rows = await get_table_data(sqlite_conn, name)
        if not rows:
            logger.info(f"Table {name}: 0 rows (empty)")
            continue

        placeholders = ", ".join(["?"] * len(columns))
        col_names = ", ".join(f'"{c}"' for c in columns)
        insert_sql = f'INSERT INTO "{name}" ({col_names}) VALUES ({placeholders})'

        batch_size = 100
        for i in range(0, len(rows), batch_size):
            batch = rows[i:i + batch_size]
            turso_conn.executemany(insert_sql, batch)

        total_rows += len(rows)
        logger.info(f"Table {name}: {len(rows)} rows migrated")

    logger.info(f"Migration complete! {total_rows} total rows migrated.")
    sqlite_conn.close()
    logger.info("Don't forget to update your .env with the Turso DATABASE_URL and TURSO_AUTH_TOKEN")


if __name__ == "__main__":
    asyncio.run(main())
