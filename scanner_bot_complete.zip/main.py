import asyncio
import logging
import os
import sys
from datetime import datetime

_PORT = os.getenv("PORT")
if _PORT:
    os.environ["WEB_PORT"] = _PORT
    os.environ["MCP_PORT"] = str(int(_PORT) + 1)

from pyrogram import Client, filters, idle
from pyrogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, LabeledPrice

from config import Config
from database import Database
from scanner import Scanner
from admin import AdminHandler
from vip_system import VipSystem
from flood_captcha import FloodCaptcha
from web_dashboard import WebDashboard
from click_tracker import ClickTracker
from mcp_server import MCPServer
from config.payment_config import ENABLE_STARS_PAYMENT
from services.payment_flow import PaymentFlow, build_duration_keyboard

_log_handlers = [logging.StreamHandler()]
if Config.LOG_FILE:
    _log_handlers.append(logging.FileHandler(Config.LOG_FILE, encoding="utf-8"))

logging.basicConfig(
    level=getattr(logging, Config.LOG_LEVEL),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=_log_handlers,
)
logger = logging.getLogger("main")

app = Client(
    "scanner_bot",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN,
    workers=16,
)

db = Database()
scanner = Scanner(db)
admin_handler = AdminHandler(db)
vip_system = VipSystem(db)
click_tracker = ClickTracker(db)
dashboard = None
mcp = None

# ─── Keyboard Builders ─────────────────────────────────────────────────────────

def main_menu_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔗 اضغط لفحص رابط", callback_data="nav_scan")],
        [InlineKeyboardButton("👤 حسابي ومعلومات الاشتراك", callback_data="nav_account")],
        [InlineKeyboardButton("⭐ ترقية الحساب إلى VIP", callback_data="nav_vip")],
        [InlineKeyboardButton("🛠️ الدعم الفني والمساعدة", callback_data="nav_support")],
    ])

def back_home_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 رجوع", callback_data="nav_home"),
         InlineKeyboardButton("🏠 الرئيسية", callback_data="nav_home")],
    ])

def scan_again_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔍 فحص رابط آخر", callback_data="nav_scan"),
         InlineKeyboardButton("🏠 الرئيسية", callback_data="nav_home")],
    ])

def vip_pay_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💳 اضغط للدفع الآمن عبر Google Pay", callback_data="vip_pay")],
        [InlineKeyboardButton("🔙 رجوع", callback_data="nav_home")],
    ])

def upgrade_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⭐ ترقية الحساب إلى VIP", callback_data="nav_vip")],
        [InlineKeyboardButton("🏠 الرئيسية", callback_data="nav_home")],
    ])

# ─── Helpers ───────────────────────────────────────────────────────────────────

async def is_admin(uid: int) -> bool:
    return uid in Config.SUDO_USERS

async def daily_scan_count(uid: int) -> int:
    today = datetime.utcnow().date().isoformat()
    row = await db.fetchval(
        "SELECT COUNT(*) FROM scan_history WHERE user_id = ? AND date(scanned_at) = ?",
        (uid, today))
    return row or 0

async def is_vip(uid: int) -> bool:
    row = await db.fetchrow(
        "SELECT expires_at FROM vip_users WHERE user_id = ? AND expires_at > datetime('now')",
        (uid,))
    return row is not None

def format_scan_result(result: dict) -> str:
    emoji = "✅" if not result.get("is_threat") else "🚫"
    status_text = "آمن ✅" if not result.get("is_threat") else f"تهديد 🚫 ({result.get('threat_type', 'غير معروف')})"
    text = (
        f"{emoji} <b>نتيجة الفحص</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"🔗 الرابط: <code>{result.get('url', '')[:100]}</code>\n"
        f"🌐 النطاق: {result.get('domain', '')}\n"
        f"📊 الحالة: {status_text}\n"
        f"⭐ ثقة: {result.get('trust_score', 0):.1f}%\n"
    )
    checks = result.get("checks", {})
    vt = checks.get("virustotal", {})
    if isinstance(vt, dict) and vt.get("positives") is not None:
        text += f"🦠 VirusTotal: {vt.get('positives', 0)} إيجابي\n"
    ssl_check = checks.get("ssl", {})
    if isinstance(ssl_check, dict):
        ssl_status = "✅ صالح" if ssl_check.get("valid") else "❌ غير صالح"
        text += f"🔐 SSL: {ssl_status}\n"
    whois = checks.get("whois", {})
    if isinstance(whois, dict) and whois.get("registrar"):
        text += f"📅 WHOIS: {whois.get('registrar', '')[:50]}\n"
        if whois.get("age_days"):
            text += f"📆 عمر النطاق: {whois['age_days']} يوم\n"
    text += f"\n🕐 {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC"
    return text

# ─── /start ────────────────────────────────────────────────────────────────────

@app.on_message(filters.command("start"))
async def start_cmd(client: Client, message: Message):
    user = message.from_user
    await db.execute(
        "INSERT OR IGNORE INTO users (user_id, username, first_name, last_name, joined_at) VALUES (?, ?, ?, ?, ?)",
        (user.id, user.username or "", user.first_name or "", user.last_name or "",
         datetime.utcnow().isoformat()))
    banned = await db.fetchrow("SELECT * FROM banned_users WHERE user_id = ?", (user.id,))
    if banned:
        await message.reply("🚫 أنت محظور من استخدام البوت.")
        return
    await message.reply(
        "🤖 <b>مرحباً بك في بوت فحص الروابط</b>\n\n"
        "اختر من القائمة أدناه ما يناسبك:",
        reply_markup=main_menu_kb())

# ─── Navigation Callbacks ──────────────────────────────────────────────────────

@app.on_callback_query(filters.regex(r"^nav_"))
async def nav_callback(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    action = cb.data[4:]

    if action in ("home", "back_main"):
        await cb.message.edit(
            "🤖 <b>مرحباً بك في بوت فحص الروابط</b>\n\n"
            "اختر من القائمة أدناه ما يناسبك:",
            reply_markup=main_menu_kb())

    elif action == "scan":
        await cb.message.edit(
            "🔗 <b>فحص رابط</b>\n\n"
            "أرسل الرابط الذي تريد فحصه الآن:",
            reply_markup=back_home_kb())

    elif action == "account":
        daily = await daily_scan_count(uid)
        vip = await is_vip(uid)
        if vip:
            row = await db.fetchrow("SELECT expires_at, plan FROM vip_users WHERE user_id = ?", (uid,))
            expires = row["expires_at"][:10] if row else "—"
            plan = row["plan"] if row else "—"
            atype = "⭐ VIP"
            limit_txt = "غير محدود"
        else:
            atype = "👤 مجاني"
            limit_txt = f"{daily}/{Config.FREE_DAILY_LIMIT}"
            expires = "—"
            plan = "—"
        await cb.message.edit(
            f"👤 <b>معلومات حسابك</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"🆔 المعرف: <code>{uid}</code>\n"
            f"📋 النوع: {atype}\n"
            f"🔍 فحوصات اليوم: {limit_txt}\n"
            f"📅 انتهاء VIP: {expires}\n"
            f"📋 الخطة: {plan}\n"
            f"━━━━━━━━━━━━━━",
            reply_markup=back_home_kb())

    elif action == "vip":
        if ENABLE_STARS_PAYMENT:
            if await is_vip(uid):
                row = await db.fetchrow("SELECT expires_at FROM vip_users WHERE user_id = ?", (uid,))
                await cb.message.edit(
                    f"⭐ <b>أنت مشترك VIP بالفعل!</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"✅ اشتراكك نشط حتى {row['expires_at'][:10]}\n"
                    f"استمر في استخدام المميزات الحصرية",
                    reply_markup=back_home_kb())
            else:
                price_display = Config.VIP_PRICE_CENTS / 100
                await cb.message.edit(
                    f"⭐ <b>ترقية الحساب إلى VIP</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"📌 اشتراك شهري: {Config.VIP_DURATION_DAYS} يوماً\n"
                    f"💵 السعر: {price_display:.2f} {Config.VIP_CURRENCY}\n\n"
                    f"✨ <b>المميزات:</b>\n"
                    f"• 🔍 فحص غير محدود للروابط\n"
                    f"• 🤖 فحص متقدم بالذكاء الاصطناعي\n"
                    f"• 📸 فحص الصور والفيديو\n"
                    f"• 📋 فحص جماعي للروابط\n"
                    f"• 🔐 مراقبة النطاقات\n"
                    f"• 🔑 API شخصي\n"
                    f"• ⭐ أولوية في الفحص\n\n"
                    f"اضغط على الزر أدناه للدفع الآمن عبر Google Pay:",
                    reply_markup=vip_pay_kb())
        else:
            # Iraqi manual payment flow
            if await is_vip(uid):
                row = await db.fetchrow("SELECT expires_at FROM vip_users WHERE user_id = ?", (uid,))
                await cb.message.edit(
                    f"⭐ <b>أنت مشترك VIP بالفعل!</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"✅ اشتراكك نشط حتى {row['expires_at'][:10]}\n"
                    f"استمر في استخدام المميزات الحصرية",
                    reply_markup=back_home_kb())
            else:
                await cb.message.edit(
                    "⭐ <b>ترقية الحساب إلى VIP</b>\n"
                    "━━━━━━━━━━━━━━\n"
                    "اختر مدة الاشتراك المناسبة لك:",
                    reply_markup=build_duration_keyboard())

    elif action == "support":
        await cb.message.edit(
            "🛠️ <b>الدعم الفني والمساعدة</b>\n"
            f"━━━━━━━━━━━━━━\n"
            "للاستفسارات والدعم الفني، يرجى التواصل مع المطور:\n\n"
            f"👤 المطور الأساسي: <a href=\"tg://user?id={Config.PRIMARY_ADMIN_ID}\">اضغط هنا</a>\n"
            f"👤 المطور المساعد: <a href=\"tg://user?id={Config.SECONDARY_ADMIN_ID}\">اضغط هنا</a>\n\n"
            "📧 أو أرسل رسالتك وسيتم الرد عليك في أقرب وقت.",
            reply_markup=back_home_kb())

    await cb.answer()

# ─── Incoming Text (URL Scan) ──────────────────────────────────────────────────

@app.on_message(filters.text & filters.private & ~filters.command(["start", "help", "r", "myapi", "grantvip", "admin", "stats", "ban", "unban", "broadcast", "export", "import", "logs", "restart", "clearcache", "addadmin", "deladmin", "vip", "bulkscan", "domainwatch", "whitelist"]))
async def handle_text(client: Client, message: Message):
    uid = message.from_user.id
    banned = await db.fetchrow("SELECT * FROM banned_users WHERE user_id = ?", (uid,))
    if banned:
        await message.reply("🚫 أنت محظور من استخدام البوت.")
        return

    text = message.text.strip()
    if not (text.startswith("http://") or text.startswith("https://") or "." in text):
        await message.reply(
            "❌ يبدو أن هذا ليس رابطاً صحيحاً.\n"
            "الرجاء إرسال رابط صحيح أو استخدم القائمة أدناه:",
            reply_markup=main_menu_kb())
        return

    if not await is_vip(uid):
        daily = await daily_scan_count(uid)
        if daily >= Config.FREE_DAILY_LIMIT:
            await message.reply(
                f"❌ <b>لقد تجاوزت الحد اليومي المجاني</b>\n\n"
                f"📊 عدد فحوصات اليوم: {daily}/{Config.FREE_DAILY_LIMIT}\n\n"
                f"⭐ قم بترقية حسابك إلى VIP لتحصل على فحص غير محدود:",
                reply_markup=upgrade_kb())
            return

    sent = await message.reply("🔍 جاري فحص الرابط...")
    try:
        result = await asyncio.wait_for(
            scanner.scan_url(text, uid, priority=await is_vip(uid)),
            timeout=7)
        await sent.edit(format_scan_result(result), reply_markup=scan_again_kb())
    except asyncio.TimeoutError:
        await sent.edit("⏰ انتهت مهلة الفحص (أكثر من 7 ثوانٍ). الرابط بطيء جداً.", reply_markup=scan_again_kb())
    except Exception as e:
        logger.error(f"Scan error for {text}: {e}")
        await sent.edit(f"❌ حدث خطأ أثناء الفحص: {str(e)[:200]}", reply_markup=scan_again_kb())

# ─── VIP Payment ──────────────────────────────────────────────────────────────

@app.on_callback_query(filters.regex("^vip_pay$"))
async def vip_pay_cb(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    if await is_vip(uid):
        await cb.answer("أنت مشترك VIP بالفعل!", show_alert=True)
        return
    if not Config.PROVIDER_TOKEN:
        await cb.answer("الدفع غير متاح حالياً. تواصل مع المطور.", show_alert=True)
        return
    prices = [LabeledPrice(label="اشتراك VIP لمدة شهر", amount=Config.VIP_PRICE_CENTS)]
    try:
        await client.send_invoice(
            chat_id=uid,
            title="اشتراك VIP - بوت فحص الروابط",
            description=f"اشتراك لمدة {Config.VIP_DURATION_DAYS} يوماً مع مميزات غير محدودة",
            payload=f"vip_{uid}_{int(datetime.utcnow().timestamp())}",
            provider_token=Config.PROVIDER_TOKEN,
            currency=Config.VIP_CURRENCY,
            prices=prices,
            start_parameter="vip_subscription")
    except Exception as e:
        logger.error(f"sendInvoice error: {e}")
        await cb.answer(f"خطأ: {str(e)[:50]}", show_alert=True)
    await cb.answer()

@app.on_pre_checkout_query()
async def pre_checkout_handler(client: Client, query):
    await query.answer(ok=True)

@app.on_message(filters.successful_payment)
async def payment_success(client: Client, message: Message):
    uid = message.from_user.id
    pay = message.successful_payment
    total = pay.total_amount / 100
    currency = pay.currency
    pid = f"INV-{uid}-{int(datetime.utcnow().timestamp())}"

    await vip_system.grant_vip(uid, "month")

    filename = None
    try:
        from fpdf import FPDF
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 20)
        pdf.cell(0, 15, "INVOICE / \u0641\u0627\u062a\u0648\u0631\u0629", ln=True, align="C")
        pdf.line(10, 25, 200, 25)
        pdf.ln(10)
        pdf.set_font("Helvetica", "", 11)
        for line in [
            f"Payment ID / \u0631\u0642\u0645 \u0627\u0644\u0641\u0627\u062a\u0648\u0631\u0629: {pid}",
            f"User ID / \u0631\u0642\u0645 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645: {uid}",
            f"Plan / \u0627\u0644\u062e\u0637\u0629: VIP Monthly Subscription",
            f"Duration / \u0627\u0644\u0645\u062f\u0629: {Config.VIP_DURATION_DAYS} days",
            f"Amount / \u0627\u0644\u0645\u0628\u0644\u063a: {total:.2f} {currency}",
            f"Date / \u0627\u0644\u062a\u0627\u0631\u064a\u062e: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC",
            f"Status / \u0627\u0644\u062d\u0627\u0644\u0629: PAID / \u062f\u0641\u0639",
        ]:
            pdf.cell(0, 8, line, ln=True)
        pdf.ln(10)
        pdf.set_font("Helvetica", "I", 10)
        pdf.cell(0, 8, "Thank you for your purchase! / \u0634\u0643\u0631\u0627\u064b \u0644\u0637\u0644\u0628\u0643", ln=True, align="C")
        filename = f"/tmp/{pid}.pdf"
        pdf.output(filename)
    except Exception as e:
        logger.error(f"PDF error: {e}")

    await message.reply(
        "✅ <b>تم الدفع بنجاح!</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"⭐ تم تفعيل VIP لمدة {Config.VIP_DURATION_DAYS} يوماً\n"
        f"💰 {total:.2f} {currency}\n"
        f"🆔 {pid}\n"
        f"━━━━━━━━━━━━━━\n"
        f"استمتع بالمميزات الحصرية!")

    if filename and os.path.exists(filename):
        for target, label in [(uid, "المستخدم"), (Config.PRIMARY_ADMIN_ID, "المطور الأساسي"), (Config.SECONDARY_ADMIN_ID, "المطور المساعد")]:
            try:
                await client.send_document(
                    target, filename,
                    caption=f"🧾 فاتورة دفع | {label}\n👤 {uid}\n💰 {total:.2f} {currency}\n🆔 {pid}")
            except Exception as e:
                logger.error(f"Failed to send PDF to {label} ({target}): {e}")
        try:
            os.remove(filename)
            logger.info(f"Deleted invoice PDF: {filename}")
        except Exception as e:
            logger.error(f"Delete PDF failed: {e}")

# ─── /grantvip (Admin Only) ──────────────────────────────────────────────────

# Store pending grant confirmations
_pending_grants = {}

@app.on_message(filters.command("grantvip") & filters.private)
async def grantvip_cmd(client: Client, message: Message):
    uid = message.from_user.id
    if uid not in Config.SUDO_USERS:
        await message.reply("❌ هذا الأمر خاص بالمطورين فقط.")
        return
    args = message.text.split()
    if len(args) < 3:
        await message.reply("❌ استخدم: /grantvip <معرف_المستخدم> <عدد_الأشهر>\nمثال: /grantvip 123456789 3")
        return
    try:
        target = int(args[1])
        months = int(args[2])
    except ValueError:
        await message.reply("❌ المعرف وعدد الأشهر يجب أن يكونا أرقاماً.")
        return
    if months < 1 or months > 120:
        await message.reply("❌ عدد الأشهر يجب أن يكون بين 1 و 120.")
        return

    confirm_key = f"grant_{uid}_{target}_{months}"
    _pending_grants[confirm_key] = {"target": target, "months": months, "admin": uid}

    # Calculate expected amount
    price_per_month = int(os.getenv("PRICE_MONTH_IQD", "5000"))
    expected_amount = price_per_month * months

    await message.reply(
        f"⚠️ <b>أنت على وشك تفعيل VIP</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"👤 المستخدم: <code>{target}</code>\n"
        f"📆 المدة: {months} شهر/أشهر\n"
        f"💰 المبلغ المتوقع: {expected_amount:,} د.ع\n"
        f"━━━━━━━━━━━━━━\n\n"
        f"هل تأكدت من استلام المبلغ؟",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ نعم، فعّل", callback_data=f"gogrant_{confirm_key}")],
            [InlineKeyboardButton("❌ إلغاء", callback_data=f"nogrant_{confirm_key}")],
        ])
    )

@app.on_callback_query(filters.regex(r"^gogrant_"))
async def confirm_grant_cb(client: Client, cb: CallbackQuery):
    key = cb.data.replace("gogrant_", "")
    info = _pending_grants.pop(key, None)
    if not info:
        await cb.answer("❌ انتهت صلاحية الطلب، استخدم /grantvip مرة أخرى")
        return

    admin_id = info["admin"]
    if cb.from_user.id != admin_id:
        await cb.answer("❌ غير مصرح")
        return

    target = info["target"]
    months = info["months"]

    result = await vip_system.grant_vip(target, "month", months)
    if "error" in result:
        await cb.message.edit(f"❌ فشل التفعيل: {result['error']}")
    else:
        await cb.message.edit(
            f"✅ <b>تم تفعيل VIP يدوياً</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"👤 المستخدم: <code>{target}</code>\n"
            f"📆 المدة: {months} شهر/أشهر\n"
            f"🔚 ينتهي: {result['expires_at'][:10]}\n"
            f"━━━━━━━━━━━━━━\n"
            f"✅ تم التأكيد بواسطة: {cb.from_user.mention}")
        try:
            await client.send_message(
                target,
                f"⭐ <b>تم تفعيل اشتراك VIP الخاص بك!</b>\n"
                f"━━━━━━━━━━━━━━\n"
                f"📆 المدة: {months} شهر/أشهر\n"
                f"🔚 ينتهي: {result['expires_at'][:10]}\n"
                f"━━━━━━━━━━━━━━\n"
                f"استخدم /start للاطلاع على القائمة.")
        except Exception:
            pass
        # Notify admins
        notify_text = (
            f"✅ <b>تم تفعيل VIP يدوياً</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"👤 المستخدم: <code>{target}</code>\n"
            f"📆 المدة: {months} شهر/أشهر\n"
            f"🔚 ينتهي: {result['expires_at'][:10]}\n"
            f"━━━━━━━━━━━━━━"
        )
        await notify_admins(client, notify_text)
    await cb.answer()

@app.on_callback_query(filters.regex(r"^nogrant_"))
async def cancel_grant_cb(client: Client, cb: CallbackQuery):
    key = cb.data.replace("nogrant_", "")
    _pending_grants.pop(key, None)
    await cb.message.edit("❌ تم إلغاء التفعيل.")
    await cb.answer()

# ─── /help ────────────────────────────────────────────────────────────────────

@app.on_message(filters.command("help"))
async def help_cmd(client: Client, message: Message):
    await message.reply(
        "📚 <b>مساعدة البوت</b>\n\n"
        "هذا البوت يعمل بشكل كامل عبر الأزرار.\n"
        "اضغط /start لفتح القائمة الرئيسية.\n\n"
        "يمكنك إرسال رابط مباشرة للفحص في أي وقت.",
        reply_markup=back_home_kb())

# ─── Short URL Resolver ───────────────────────────────────────────────────────

@app.on_message(filters.command("r"))
async def resolve_short(client: Client, message: Message):
    text = message.text.split(maxsplit=1)
    if len(text) < 2:
        await message.reply("❌ استخدم: /r كود_الرابط")
        return
    code = text[1].strip()
    original = await click_tracker.resolve_short_url(code)
    if original:
        await message.reply(f"🔗 الرابط الأصلي: {original}")
    else:
        await message.reply("❌ الرابط غير موجود أو منتهي الصلاحية")

# ─── /myapi (VIP only) ────────────────────────────────────────────────────────

@app.on_message(filters.command("myapi") & filters.private)
async def myapi_cmd(client: Client, message: Message):
    uid = message.from_user.id
    if not await is_vip(uid):
        await message.reply("❌ هذه الميزة للمستخدمين VIP فقط\nاستخدم /vip للاشتراك")
        return
    key = await db.fetchrow("SELECT * FROM api_keys WHERE user_id = ?", (uid,))
    if not key:
        import secrets
        new_key = f"sb_{secrets.token_hex(16)}"
        await db.execute(
            "INSERT INTO api_keys (key, user_id, permissions, created_at) VALUES (?, ?, ?, ?)",
            (new_key, uid, "read", datetime.utcnow().isoformat()))
        key = {"key": new_key}
    endpoint = f"{Config.WEB_URL}/api/scan"
    await message.reply(
        f"🔑 <b>مفتاح API الخاص بك</b>\n\n"
        f"المفتاح: <code>{key['key']}</code>\n"
        f"الرابط: {endpoint}\n\n"
        f"<b>طريقة الاستخدام:</b>\n"
        f"<pre>curl -X POST {endpoint} \\\n"
        f"  -H \"Authorization: Bearer {key['key']}\" \\\n"
        f"  -H \"Content-Type: application/json\" \\\n"
        f"  -d '{{\"url\":\"https://example.com\"}}'</pre>")

# ─── Webhook ──────────────────────────────────────────────────────────────────

async def webhook_handler(request):
    from aiohttp import web
    try:
        data = await request.json()
        secret = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
        if Config.WEBHOOK_SECRET and secret != Config.WEBHOOK_SECRET:
            return web.Response(status=403)
        await app.process_update(data)
        return web.Response(status=200)
    except Exception as e:
        logger.error(f"Webhook handler error: {e}")
        return web.Response(status=500)

# ─── Infrastructure ───────────────────────────────────────────────────────────

async def start_webhook():
    try:
        webhook_url = Config.WEBHOOK_URL
        if not webhook_url:
            public_url = os.getenv("PUBLIC_URL", "").rstrip("/")
            if public_url:
                webhook_url = public_url + Config.WEBHOOK_PATH
            else:
                logger.warning("No WEBHOOK_URL or PUBLIC_URL set, webhook mode disabled")
                return
        await app.set_webhook(
            url=webhook_url,
            secret_token=Config.WEBHOOK_SECRET or None,
            max_connections=40)
        logger.info(f"Webhook set to {webhook_url}")
    except Exception as e:
        logger.error(f"Webhook setup failed: {e}")

async def start_dashboard():
    global dashboard
    try:
        dashboard = WebDashboard(db, bot=app)
        await dashboard.start()
        logger.info("Web dashboard started")
    except Exception as e:
        logger.error(f"Dashboard start failed: {e}")

async def start_mcp():
    global mcp
    try:
        mcp = MCPServer(bot=app, db=db, dashboard=dashboard, scanner=scanner)
        from aiohttp import web
        mcp_app = web.Application()
        async def mcp_handler(request):
            data = await request.json()
            result = await mcp.handle_request(data)
            return web.json_response(result)
        mcp_app.router.add_post("/mcp", mcp_handler)
        runner = web.AppRunner(mcp_app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", Config.MCP_PORT)
        await site.start()
        logger.info(f"MCP server running on port {Config.MCP_PORT}")
    except Exception as e:
        logger.error(f"MCP server start failed: {e}")

async def notify_admins(client: Client, text: str, reply_markup=None):
    """Notify both primary and secondary admins."""
    for admin_id in Config.SUDO_USERS:
        try:
            await client.send_message(admin_id, text, reply_markup=reply_markup)
        except Exception as e:
            logger.error(f"Failed to notify admin {admin_id}: {e}")

async def cleanup_expired_links():
    while True:
        try:
            await click_tracker.cleanup_expired()
        except Exception as e:
            logger.error(f"Cleanup error: {e}")
        await asyncio.sleep(3600)

async def main():
    logger.info("Starting bot...")
    await db.init()
    await app.start()

    admin_handler.register(app)
    flood = FloodCaptcha(db)
    flood.register(app)

    if ENABLE_STARS_PAYMENT:
        from vip_handlers import VipHandler
        VipHandler(db).register(app)
        logger.info("VIP: Telegram Stars payment mode")
    else:
        payment_flow = PaymentFlow(db, vip_system)
        payment_flow.register(app)
        logger.info("VIP: Iraqi manual payment mode")

    bot_info = await app.get_me()
    logger.info(f"Bot started: @{bot_info.username}")

    if Config.ENABLE_DASHBOARD:
        asyncio.create_task(start_dashboard())
        await asyncio.sleep(1)

    from aiohttp import web

    if Config.WEBHOOK_MODE:
        webhook_app = web.Application()
        webhook_app.router.add_post(Config.WEBHOOK_PATH, webhook_handler)
        webhook_app.router.add_get("/health", lambda r: web.json_response({
            "status": "healthy", "mode": "webhook",
            "timestamp": datetime.utcnow().isoformat()}))
        if dashboard:
            webhook_app.router.add_routes(dashboard.app.router.routes())
        runner = web.AppRunner(webhook_app)
        await runner.setup()
        site = web.TCPSite(runner, Config.WEB_HOST, Config.WEB_PORT)
        await site.start()
        logger.info(f"Webhook+dashboard server on {Config.WEB_HOST}:{Config.WEB_PORT}")
        if Config.WEBHOOK_URL:
            await start_webhook()
        if dashboard and hasattr(dashboard, 'runner') and dashboard.runner:
            await dashboard.runner.cleanup()
            dashboard.runner = None
    else:
        logger.info("Running in polling mode")

    if Config.ENABLE_MCP:
        asyncio.create_task(start_mcp())

    asyncio.create_task(cleanup_expired_links())

    if not ENABLE_STARS_PAYMENT:
        async def payment_cleanup_loop():
            while True:
                await payment_flow.cleanup_expired_requests()
                await asyncio.sleep(300)  # every 5 minutes
        asyncio.create_task(payment_cleanup_loop())

    logger.info("Bot is ready!")
    await idle()

    logger.info("Shutting down...")
    if dashboard:
        await dashboard.stop()
    await scanner.close()
    await db.close()
    await app.stop()

if __name__ == "__main__":
    try:
        os.makedirs("data", exist_ok=True)
        os.makedirs("uploads", exist_ok=True)
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except ImportError as e:
        logger.error(f"Missing module: {e}")
        logger.error(f"Run: pip install -r requirements.txt")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)
