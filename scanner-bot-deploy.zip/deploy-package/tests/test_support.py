"""Tests for support system: agents parser, ticket store, RBAC integration."""

import os
import re
import sys
import pytest
from unittest.mock import AsyncMock, patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("LOCAL_ONLY_MODE", "true")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///data/test_bot.db")

# Set support env vars for tests
os.environ["SUPPORT_USERS"] = "1001,1002"
os.environ["SUPPORT_NAMES"] = "Tester One,Tester Two"
os.environ["SUPPORT_ROLES"] = "tech,sales"
os.environ["SUPPORT_HOURS"] = "09:00-18:00,"
os.environ["SUPPORT_TICKETS_ENABLED"] = "true"
os.environ["SUPPORT_MAX_OPEN_TICKETS"] = "3"
os.environ["SUPPORT_AUTO_CLOSE_HOURS"] = "1"
os.environ["SUPPORT_CONTACT_METHOD"] = "both"

from config import Config
from support.agents import SupportAgent, parse_support_users
from support.tickets import TicketStore, _ticket_id

TICKET_ID_RE = re.compile(r"^T-\d{8}-[A-Z0-9]{4}$")


class TestSupportAgent:
    def test_dataclass(self):
        a = SupportAgent(user_id=101, name="Alice", role="tech", hours="09:00-18:00")
        assert a.user_id == 101
        assert a.name == "Alice"
        assert a.role == "tech"
        assert a.hours == "09:00-18:00"

    def test_dataclass_no_hours(self):
        a = SupportAgent(user_id=102, name="Bob", role="", hours=None)
        assert a.hours is None

    def test_ticket_id_format(self):
        tid = _ticket_id()
        assert TICKET_ID_RE.match(tid), f"Invalid ticket ID format: {tid}"

    def test_ticket_id_unique(self):
        ids = {_ticket_id() for _ in range(100)}
        assert len(ids) == 100, "Ticket IDs collided"

    @patch.dict(os.environ, {
        "SUPPORT_USERS": "1001,1002",
        "SUPPORT_NAMES": "Tester One,Tester Two",
        "SUPPORT_ROLES": "tech,sales",
        "SUPPORT_HOURS": "09:00-18:00,",
    }, clear=False)
    def test_parse_format_a(self):
        agents = parse_support_users()
        ids = {a.user_id for a in agents}
        assert 1001 in ids
        assert 1002 in ids
        for a in agents:
            if a.user_id == 1001:
                assert a.name == "Tester One"
                assert a.role == "tech"
                assert a.hours == "09:00-18:00"

    @patch.object(Config, "SUPPORT_USER_1_ID", 2001, create=True)
    @patch.object(Config, "SUPPORT_USER_1_NAME", "Verbose One", create=True)
    @patch.object(Config, "SUPPORT_USER_1_ROLE", "admin", create=True)
    @patch.object(Config, "SUPPORT_USER_1_HOURS", "10:00-17:00", create=True)
    @patch.object(Config, "SUPPORT_USER_2_ID", 2002, create=True)
    @patch.object(Config, "SUPPORT_USER_2_NAME", "Verbose Two", create=True)
    @patch.object(Config, "SUPPORT_USER_2_ROLE", "mod", create=True)
    @patch.object(Config, "SUPPORT_USER_2_HOURS", "", create=True)
    def test_parse_format_b(self):
        agents = parse_support_users()
        ids = {a.user_id for a in agents}
        assert 2001 in ids
        assert 2002 in ids
        for a in agents:
            if a.user_id == 2001:
                assert a.name == "Verbose One"
                assert a.role == "admin"
                assert a.hours == "10:00-17:00"
            if a.user_id == 2002:
                assert a.hours is None

    @patch.dict(os.environ, {
        "SUPPORT_USERS": "3001,3002",
        "SUPPORT_NAMES": "Compact A,Compact B",
        "SUPPORT_ROLES": "role_a,role_b",
        "SUPPORT_HOURS": ",",
    }, clear=False)
    @patch.object(Config, "SUPPORT_USER_1_ID", 3001, create=True)
    @patch.object(Config, "SUPPORT_USER_1_NAME", "Verbose Override", create=True)
    @patch.object(Config, "SUPPORT_USER_1_ROLE", "boss", create=True)
    @patch.object(Config, "SUPPORT_USER_1_HOURS", "08:00-16:00", create=True)
    def test_verbose_wins_on_duplicate(self):
        agents = parse_support_users()
        a = next((x for x in agents if x.user_id == 3001), None)
        assert a is not None
        assert a.name == "Verbose Override"
        assert a.role == "boss"
        assert a.hours == "08:00-16:00"
        b = next((x for x in agents if x.user_id == 3002), None)
        assert b is not None
        assert b.name == "Compact B"


@pytest.mark.asyncio
class TestTicketStore:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.db = AsyncMock()
        self.db.execute = AsyncMock()
        self.db.fetchrow = AsyncMock()
        self.db.fetchval = AsyncMock(return_value=0)
        self.db.fetch = AsyncMock(return_value=[])
        self.ts = TicketStore(self.db)

    async def test_create_ticket(self):
        self.db.fetchval.return_value = 0
        tid = await self.ts.create_ticket(101, "Test subject", "Test body")
        assert TICKET_ID_RE.match(tid)
        assert self.db.execute.await_count == 2

    async def test_get_ticket_found(self):
        fake = {"id": "T-20260101-ABCD", "user_id": 101, "status": "open"}
        self.db.fetchrow.return_value = fake
        tkt = await self.ts.get_ticket("T-20260101-ABCD")
        assert tkt is not None
        assert tkt["id"] == "T-20260101-ABCD"

    async def test_get_ticket_not_found(self):
        self.db.fetchrow.return_value = None
        tkt = await self.ts.get_ticket("T-20260101-NONE")
        assert tkt is None

    async def test_list_user_tickets(self):
        fake = [{"id": "T1", "user_id": 101, "status": "open"}]
        self.db.fetch.return_value = fake
        lst = await self.ts.list_user_tickets(101)
        assert len(lst) == 1
        assert lst[0]["id"] == "T1"

    async def test_list_open_tickets(self):
        fake = [{"id": "T2", "status": "open"}]
        self.db.fetch.return_value = fake
        lst = await self.ts.list_open_tickets()
        assert len(lst) == 1

    async def test_list_assigned_tickets(self):
        fake = [{"id": "T3", "assigned_to": 201, "status": "assigned"}]
        self.db.fetch.return_value = fake
        lst = await self.ts.list_assigned_tickets(201)
        assert len(lst) == 1

    async def test_open_ticket_count(self):
        self.db.fetchval.return_value = 2
        cnt = await self.ts.open_ticket_count(101)
        assert cnt == 2

    async def test_open_ticket_count_zero(self):
        self.db.fetchval.return_value = 0
        cnt = await self.ts.open_ticket_count(101)
        assert cnt == 0

    async def test_assign_ticket(self):
        await self.ts.assign_ticket("T-20260101-ABCD", 201)
        self.db.execute.assert_awaited_once()

    async def test_reply_to_ticket_agent(self):
        await self.ts.reply_to_ticket("T-1", 201, True, "Agent reply")
        assert self.db.execute.await_count == 2

    async def test_reply_to_ticket_user(self):
        await self.ts.reply_to_ticket("T-1", 101, False, "User reply")
        assert self.db.execute.await_count == 2

    async def test_close_ticket(self):
        await self.ts.close_ticket("T-1", 101)
        self.db.execute.assert_awaited_once()

    async def test_get_messages(self):
        fake = [{"id": 1, "ticket_id": "T-1", "body": "hi"}]
        self.db.fetch.return_value = fake
        msgs = await self.ts.get_messages("T-1")
        assert len(msgs) == 1
        assert msgs[0]["body"] == "hi"

    async def test_auto_close_stale_zero_hours(self):
        with patch("support.tickets.Config.SUPPORT_AUTO_CLOSE_HOURS", 0):
            result = await self.ts.auto_close_stale()
            assert result is None

    async def test_auto_close_stale_closes(self):
        fake_rows = [
            {"id": "T-STALE-1", "status": "open", "updated_at": "2020-01-01T00:00:00"},
        ]
        self.db.fetch.return_value = fake_rows
        stale = await self.ts.auto_close_stale()
        assert stale is not None

    async def test_limit_exceeded(self):
        self.db.fetchval.return_value = 3
        cnt = await self.ts.open_ticket_count(101)
        assert cnt >= 3


@pytest.mark.asyncio
class TestSupportRBAC:
    async def test_is_support(self):
        from rbac import RBAC
        with patch.dict(os.environ, {"SUPPORT_USERS": "9999", "SUPPORT_NAMES": "", "SUPPORT_ROLES": "", "SUPPORT_HOURS": ""}, clear=False):
            assert RBAC.is_support(9999) is True
            assert RBAC.is_support(0) is False
