# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import hashlib
import json
import logging
import os
import shutil
import time
from datetime import datetime, timedelta
from pathlib import Path

import aiohttp.web as web
import aiohttp_jinja2
import humanize
import jinja2

from config import Config
from database import Database

logger = logging.getLogger("web_dashboard")


class WebDashboard:
    def __init__(self, db: Database, bot=None, backup_manager=None):
        self.db = db
        self.bot = bot
        self.backup_manager = backup_manager
        self.app = web.Application()
        self.runner = None
        self._ws_clients = set()
        self._start_time = datetime.utcnow()
        self._db_query_count = 0
        self._setup_routes()

    def _setup_routes(self):
        self.app.router.add_get("/", self._handle_index)
        self.app.router.add_get("/health", self._handle_health)
        self.app.router.add_get("/api/stats", self._handle_api_stats)
        self.app.router.add_get("/api/threats", self._handle_api_threats)
        self.app.router.add_post("/api/scan", self._handle_api_scan)
        self.app.router.add_post("/api/upload", self._handle_api_upload)
        self.app.router.add_get("/api/activity", self._handle_api_activity)
        self.app.router.add_get("/api/analytics", self._handle_api_analytics)
        self.app.router.add_get("/analytics", self._handle_analytics_page)
        self.app.router.add_get("/api/performance", self._handle_api_performance)
        self.app.router.add_get("/api/files", self._handle_api_files_list)
        self.app.router.add_delete("/api/files/{filename}", self._handle_api_files_delete)
        self.app.router.add_post("/api/files/upload", self._handle_api_files_upload)
        self.app.router.add_get("/api/backups", self._handle_api_backups_list)
        self.app.router.add_post("/api/backups/create", self._handle_api_backups_create)
        self.app.router.add_get("/api/backups/{filename}/verify", self._handle_api_backups_verify)
        self.app.router.add_get("/api/docs", self._handle_api_docs)
        self.app.router.add_get("/api/openapi.json", self._handle_openapi_json)
        self.app.router.add_get("/ws", self._handle_websocket)
        self.app.router.add_static("/static", Path(__file__).parent / "static")
        aiohttp_jinja2.setup(
            self.app,
            loader=jinja2.FileSystemLoader(Path(__file__).parent / "templates"),
            autoescape=True,
        )

        self.app.on_shutdown.append(self._on_shutdown)

    async def _auth_check(self, request: web.Request) -> bool:
        auth = request.headers.get("Authorization", "")
        import base64
        if auth.startswith("Basic "):
            try:
                decoded = base64.b64decode(auth[7:]).decode()
                user, _, passwd = decoded.partition(":")
                return user == Config.DASHBOARD_USER and passwd == Config.DASHBOARD_PASS
            except Exception:
                return False
        return False

    async def _require_auth(self, request: web.Request):
        if not await self._auth_check(request):
            raise web.HTTPUnauthorized(headers={"WWW-Authenticate": 'Basic realm="Dashboard"'})

    async def _handle_index(self, request: web.Request):
        if not await self._auth_check(request):
            resp = web.Response(status=401, text="Unauthorized")
            resp.headers["WWW-Authenticate"] = 'Basic realm="Dashboard"'
            return resp

        stats = await self._get_stats()
        stats["dashboard_user"] = Config.DASHBOARD_USER
        try:
            return aiohttp_jinja2.render_template(
                "dashboard.html", request,
                {"stats": stats, "now": datetime.now().isoformat()}
            )
        except Exception:
            return web.json_response({"status": "ok", "stats": stats})

    async def _handle_health(self, request: web.Request):
        status = "healthy"
        db_ok = False
        db_size_mb = 0.0
        try:
            await self.db.fetchval("SELECT 1")
            db_ok = True
            size_row = await self.db.fetchval(
                "SELECT page_count * page_size FROM pragma_page_count, pragma_page_size"
            )
            if size_row:
                db_size_mb = round(size_row / (1024 * 1024), 2)
        except Exception:
            status = "degraded"

        disk = shutil.disk_usage("/")
        disk_usage = round(disk.used / disk.total * 100, 1)

        mem = self._get_memory_mb()
        cpu = self._get_cpu_percent()

        backup_count = 0
        last_backup = None
        if self.backup_manager:
            backups = self.backup_manager.list_backups()
            backup_count = len(backups)
            if backups:
                last_backup = backups[0].get("mtime_iso")

        uptime_secs = (datetime.utcnow() - self._start_time).total_seconds()
        uptime_hours = round(uptime_secs / 3600, 1)

        return web.json_response({
            "status": status,
            "timestamp": datetime.utcnow().isoformat(),
            "database": "connected" if db_ok else "disconnected",
            "database_size_mb": db_size_mb,
            "disk_usage_percent": disk_usage,
            "memory_usage_mb": mem,
            "cpu_percent": cpu,
            "uptime_hours": uptime_hours,
            "backup_count": backup_count,
            "last_backup": last_backup,
            "telegram_bot": "connected" if self.bot is not None else "disconnected",
            "version": Config.BOT_VERSION,
            "owner": Config.BOT_OWNER,
        })

    async def _handle_api_stats(self, request: web.Request):
        if not await self._auth_check(request):
            return web.json_response({"error": "unauthorized"}, status=401)
        stats = await self._get_stats()
        return web.json_response(stats)

    async def _handle_api_threats(self, request: web.Request):
        key = request.query.get("key", "")
        if Config.THREAT_API_KEY and key != Config.THREAT_API_KEY:
            return web.json_response({"error": "invalid key"}, status=403)

        url = request.query.get("url", "")
        domain = request.query.get("domain", "")

        if url:
            result = await self.db.fetchrow(
                "SELECT * FROM scan_history WHERE url = ? ORDER BY scanned_at DESC LIMIT 1",
                (url,)
            )
        elif domain:
            result = await self.db.fetchrow(
                "SELECT * FROM scan_history WHERE domain = ? ORDER BY scanned_at DESC LIMIT 1",
                (domain,)
            )
        else:
            results = await self.db.fetch(
                "SELECT * FROM scan_history ORDER BY scanned_at DESC LIMIT 50"
            )
            return web.json_response({"results": [dict(r) for r in results]})

        if result:
            return web.json_response(dict(result))
        return web.json_response({"error": "not found"}, status=404)

    async def _handle_api_scan(self, request: web.Request):
        if not await self._auth_check(request):
            return web.json_response({"error": "unauthorized"}, status=401)

        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "invalid json"}, status=400)

        url = data.get("url", "")
        if not url:
            return web.json_response({"error": "url required"}, status=400)

        if self.bot:
            try:
                from scanner import Scanner
                scanner = Scanner(self.db)
                result = await scanner.scan_url(url, priority=True)
                return web.json_response({"result": result})
            except Exception as e:
                logger.error(f"Scan error: {e}")
                return web.json_response({"error": str(e)}, status=500)

        return web.json_response({"error": "scanner not available"}, status=503)

    async def _handle_api_upload(self, request: web.Request):
        if not await self._auth_check(request):
            return web.json_response({"error": "unauthorized"}, status=401)

        reader = await request.multipart()
        field = await reader.next()

        if not field or field.name != "file":
            return web.json_response({"error": "file field required"}, status=400)

        filename = field.filename
        if not filename:
            return web.json_response({"error": "no filename"}, status=400)

        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if ext not in Config.ALLOWED_EXTENSIONS:
            return web.json_response({"error": f"invalid extension {ext}, allowed: {Config.ALLOWED_EXTENSIONS}"},
                                     status=400)

        content = await field.read()
        urls = content.decode().strip().splitlines()
        urls = [u.strip() for u in urls if u.strip()]

        if len(urls) > Config.MAX_BATCH_SIZE:
            urls = urls[:Config.MAX_BATCH_SIZE]

        results = []
        if self.bot:
            from scanner import Scanner
            scanner = Scanner(self.db)
            for u in urls:
                try:
                    r = await scanner.scan_url(u, priority=False)
                    results.append({"url": u, "status": "scanned", "result": r})
                except Exception as e:
                    results.append({"url": u, "status": "error", "error": str(e)})
        else:
            results = [{"url": u, "status": "queued"} for u in urls]

        return web.json_response({
            "total": len(urls),
            "results": results,
            "scanned": len(results),
        })

    async def _handle_api_activity(self, request: web.Request):
        if not await self._auth_check(request):
            return web.json_response({"error": "unauthorized"}, status=401)

        hours = int(request.query.get("hours", "24"))
        since = datetime.utcnow() - timedelta(hours=hours)

        try:
            scans = await self.db.fetch(
                "SELECT COUNT(*) as count, strftime('%Y-%m-%d %H:00', scanned_at) as hour "
                "FROM scan_history WHERE scanned_at >= ? GROUP BY hour ORDER BY hour",
                (since.isoformat(),)
            )
            total_scans = sum(r["count"] for r in scans) if scans else 0

            threat_types = await self.db.fetch(
                "SELECT threat_type, COUNT(*) as count FROM scan_history "
                "WHERE scanned_at >= ? AND threat_type IS NOT NULL GROUP BY threat_type",
                (since.isoformat(),)
            )
        except Exception:
            scans = []
            total_scans = 0
            threat_types = []

        return web.json_response({
            "period_hours": hours,
            "total_scans": total_scans,
            "scans_per_hour": [dict(r) for r in scans] if scans else [],
            "threat_types": [dict(r) for r in threat_types] if threat_types else [],
        })

    # ---------------------------------------------------------------------------
    # Analytics Dashboard
    # ---------------------------------------------------------------------------

    async def _handle_api_analytics(self, request: web.Request):
        await self._require_auth(request)

        today = datetime.utcnow().date().isoformat()
        week_ago = (datetime.utcnow() - timedelta(days=7)).isoformat()
        month_ago = (datetime.utcnow() - timedelta(days=30)).isoformat()

        scans_today = 0
        scans_week = []
        scans_month = 0
        try:
            row = await self.db.fetchrow(
                "SELECT COUNT(*) as c FROM scan_history WHERE date(scanned_at) = ?", (today,)
            )
            scans_today = row["c"] if row else 0

            rows = await self.db.fetch(
                "SELECT date(scanned_at) as d, COUNT(*) as c FROM scan_history "
                "WHERE scanned_at >= ? GROUP BY d ORDER BY d", (week_ago,)
            )
            scans_week = [dict(r) for r in rows] if rows else []

            row2 = await self.db.fetchrow(
                "SELECT COUNT(*) as c FROM scan_history WHERE scanned_at >= ?", (month_ago,)
            )
            scans_month = row2["c"] if row2 else 0
        except Exception as e:
            logger.error(f"Analytics scans error: {e}")

        top_users = []
        try:
            rows = await self.db.fetch(
                "SELECT user_id, COUNT(*) as count FROM scan_history "
                "GROUP BY user_id ORDER BY count DESC LIMIT 10"
            )
            top_users = [dict(r) for r in rows] if rows else []
        except Exception as e:
            logger.error(f"Analytics top_users error: {e}")

        threat_breakdown = []
        try:
            rows = await self.db.fetch(
                "SELECT threat_type, COUNT(*) as count FROM scan_history "
                "WHERE threat_type IS NOT NULL GROUP BY threat_type ORDER BY count DESC"
            )
            threat_breakdown = [dict(r) for r in rows] if rows else []
        except Exception as e:
            logger.error(f"Analytics threats error: {e}")

        revenue_stats = {}
        try:
            row = await self.db.fetchrow(
                "SELECT COUNT(*) as count, COALESCE(SUM(amount), 0) as total FROM payment_requests WHERE status = 'verified'"
            )
            revenue_stats = dict(row) if row else {"count": 0, "total": 0}
        except Exception:
            revenue_stats = {"count": 0, "total": 0}

        backup_stats = {"count": 0, "sizes": [], "last_backup": None}
        if self.backup_manager:
            backups = self.backup_manager.list_backups()
            backup_stats["count"] = len(backups)
            backup_stats["sizes"] = [b.get("size_bytes", 0) for b in backups]
            backup_stats["last_backup"] = backups[0].get("mtime_iso") if backups else None

        return web.json_response({
            "scans_today": scans_today,
            "scans_week": scans_week,
            "scans_month": scans_month,
            "top_users": top_users,
            "threat_breakdown": threat_breakdown,
            "revenue_stats": revenue_stats,
            "backup_stats": backup_stats,
        })

    async def _handle_analytics_page(self, request: web.Request):
        await self._require_auth(request)

        html = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - scanner_bot</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: system-ui, -apple-system, sans-serif;
            background: #0f172a; color: #e2e8f0; padding: 2rem;
        }
        h1 { color: #f1f5f9; margin-bottom: 1.5rem; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 1.5rem; }
        .card {
            background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 1.25rem;
        }
        .card h2 { color: #94a3b8; font-size: 0.9rem; margin-bottom: 1rem; }
        canvas { max-height: 300px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 0.5rem; text-align: right; border-bottom: 1px solid #334155; }
        th { color: #94a3b8; font-weight: 600; }
        .stat-row { display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #1e293b; }
        .label { color: #94a3b8; }
        .value { color: #f1f5f9; font-weight: 700; }
        a { color: #3b82f6; text-decoration: none; margin-bottom: 1rem; display: inline-block; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <a href="/">&larr; Dashboard</a>
    <h1>Analytics Dashboard</h1>
    <div class="grid">
        <div class="card"><h2>Scans per Day (Week)</h2><canvas id="chartWeek"></canvas></div>
        <div class="card"><h2>Threat Breakdown</h2><canvas id="chartThreats"></canvas></div>
        <div class="card"><h2>Top Users</h2><table><thead><tr><th>User ID</th><th>Scans</th></tr></thead><tbody id="topUsers"></tbody></table></div>
        <div class="card">
            <h2>Revenue</h2>
            <div class="stat-row"><span class="label">Total Payments</span><span class="value" id="revCount">0</span></div>
            <div class="stat-row"><span class="label">Total Amount</span><span class="value" id="revTotal">0</span></div>
            <h2 style="margin-top:1rem;">Backups</h2>
            <div class="stat-row"><span class="label">Count</span><span class="value" id="bakCount">0</span></div>
            <div class="stat-row"><span class="label">Last Backup</span><span class="value" id="bakLast">-</span></div>
        </div>
    </div>
    <script>
        fetch('/api/analytics', { credentials: 'include' })
            .then(r => r.json())
            .then(d => {
                const labels = d.scans_week.map(s => s.d);
                const values = d.scans_week.map(s => s.c);
                new Chart(document.getElementById('chartWeek'), {
                    type: 'bar',
                    data: { labels, datasets: [{ label: 'Scans', data: values, backgroundColor: '#3b82f6' }] },
                    options: { responsive: true, plugins: { legend: { display: false } } }
                });

                const tLabels = d.threat_breakdown.map(t => t.threat_type || 'unknown');
                const tValues = d.threat_breakdown.map(t => t.count);
                new Chart(document.getElementById('chartThreats'), {
                    type: 'pie',
                    data: { labels: tLabels, datasets: [{ data: tValues, backgroundColor: ['#ef4444','#f97316','#eab308','#22c55e','#3b82f6'] }] }
                });

                const tbody = document.getElementById('topUsers');
                d.top_users.forEach(u => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `<td>${u.user_id}</td><td>${u.count}</td>`;
                    tbody.appendChild(tr);
                });

                document.getElementById('revCount').textContent = d.revenue_stats.count;
                document.getElementById('revTotal').textContent = d.revenue_stats.total;
                document.getElementById('bakCount').textContent = d.backup_stats.count;
                document.getElementById('bakLast').textContent = d.backup_stats.last_backup || '-';
            });
    </script>
</body>
</html>"""
        return web.Response(text=html, content_type="text/html")

    # ---------------------------------------------------------------------------
    # Web File Manager
    # ---------------------------------------------------------------------------

    async def _handle_api_files_list(self, request: web.Request):
        await self._require_auth(request)
        backup_dir = Path(Config.BACKUP_DIR)
        files = []
        if backup_dir.exists():
            for f in sorted(backup_dir.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
                if f.is_file():
                    files.append({
                        "name": f.name,
                        "size_bytes": f.stat().st_size,
                        "modified": datetime.utcfromtimestamp(f.stat().st_mtime).isoformat(),
                    })
        return web.json_response({"files": files})

    async def _handle_api_files_delete(self, request: web.Request):
        await self._require_auth(request)
        filename = request.match_info.get("filename", "")
        if not filename:
            return web.json_response({"error": "filename required"}, status=400)

        backup_dir = Path(Config.BACKUP_DIR)
        filepath = (backup_dir / filename).resolve()
        if not str(filepath).startswith(str(backup_dir.resolve())):
            return web.json_response({"error": "invalid path"}, status=400)
        if not filepath.exists() or not filepath.is_file():
            return web.json_response({"error": "not found"}, status=404)

        filepath.unlink()
        logger.info(f"File deleted via web: {filepath}")
        return web.json_response({"status": "deleted", "filename": filename})

    async def _handle_api_files_upload(self, request: web.Request):
        await self._require_auth(request)
        reader = await request.multipart()
        field = await reader.next()
        if not field or field.name != "file":
            return web.json_response({"error": "file field required"}, status=400)

        filename = field.filename
        if not filename:
            return web.json_response({"error": "no filename"}, status=400)

        backup_dir = Path(Config.BACKUP_DIR)
        backup_dir.mkdir(parents=True, exist_ok=True)
        dest = backup_dir / filename

        content = await field.read()
        dest.write_bytes(content)
        logger.info(f"File uploaded via web: {dest} ({len(content)} bytes)")

        return web.json_response({
            "status": "uploaded",
            "filename": filename,
            "size_bytes": len(content),
        })

    # ---------------------------------------------------------------------------
    # Performance Monitor
    # ---------------------------------------------------------------------------

    def _get_memory_mb(self) -> float:
        try:
            import psutil
            proc = psutil.Process(os.getpid())
            return round(proc.memory_info().rss / (1024 * 1024), 1)
        except ImportError:
            pass
        try:
            with open("/proc/self/status") as f:
                for line in f:
                    if line.startswith("VmRSS:"):
                        kb = int(line.split()[1])
                        return round(kb / 1024, 1)
        except Exception:
            pass
        return 0.0

    def _get_cpu_percent(self) -> float:
        try:
            import psutil
            proc = psutil.Process(os.getpid())
            return round(proc.cpu_percent(interval=0.1), 1)
        except ImportError:
            pass
        try:
            with open("/proc/self/stat") as f:
                parts = f.read().split()
                if len(parts) > 13:
                    utime = int(parts[13])
                    stime = int(parts[14])
                    cutime = int(parts[15])
                    cstime = int(parts[16])
                    total = utime + stime + cutime + cstime
                    try:
                        with open("/proc/uptime") as uf:
                            uptime = float(uf.read().split()[0])
                            return round(total / uptime * 100, 1)
                    except Exception:
                        pass
        except Exception:
            pass
        return 0.0

    async def _handle_api_performance(self, request: web.Request):
        await self._require_auth(request)

        cpu = self._get_cpu_percent()
        mem = self._get_memory_mb()

        disk = shutil.disk_usage("/")
        disk_usage = round(disk.used / disk.total * 100, 1)

        uptime_secs = round((datetime.utcnow() - self._start_time).total_seconds())

        active_connections = len(self._ws_clients)

        return web.json_response({
            "process_cpu_percent": cpu,
            "memory_usage_mb": mem,
            "disk_usage_percent": disk_usage,
            "uptime_seconds": uptime_secs,
            "db_query_count": self._db_query_count,
            "active_connections": active_connections,
            "ws_clients": active_connections,
        })

    # ---------------------------------------------------------------------------
    # Backups API
    # ---------------------------------------------------------------------------

    async def _handle_api_backups_list(self, request: web.Request):
        await self._require_auth(request)
        if not self.backup_manager:
            return web.json_response({"error": "backup manager not available"}, status=503)
        backups = self.backup_manager.list_backups()
        return web.json_response({"backups": backups})

    async def _handle_api_backups_create(self, request: web.Request):
        await self._require_auth(request)
        if not self.backup_manager:
            return web.json_response({"error": "backup manager not available"}, status=503)
        try:
            path = await self.backup_manager.create_backup(label="web_manual")
            return web.json_response({
                "status": "created",
                "filename": path.name,
                "size_bytes": path.stat().st_size,
            })
        except Exception as e:
            logger.error(f"Backup create error: {e}")
            return web.json_response({"error": str(e)}, status=500)

    async def _handle_api_backups_verify(self, request: web.Request):
        await self._require_auth(request)
        if not self.backup_manager:
            return web.json_response({"error": "backup manager not available"}, status=503)
        filename = request.match_info.get("filename", "")
        if not filename:
            return web.json_response({"error": "filename required"}, status=400)

        backup_dir = Path(Config.BACKUP_DIR)
        filepath = (backup_dir / filename).resolve()
        if not str(filepath).startswith(str(backup_dir.resolve())):
            return web.json_response({"error": "invalid path"}, status=400)
        if not filepath.exists():
            return web.json_response({"error": "not found"}, status=404)

        import tarfile
        valid = False
        file_count = 0
        try:
            with tarfile.open(str(filepath), "r:gz") as tar:
                members = tar.getmembers()
                file_count = len(members)
                valid = True
        except Exception:
            valid = False

        return web.json_response({
            "filename": filename,
            "valid": valid,
            "file_count": file_count,
            "size_bytes": filepath.stat().st_size,
        })

    # ---------------------------------------------------------------------------
    # API Documentation (Swagger)
    # ---------------------------------------------------------------------------

    OPENAPI_SPEC = {
        "openapi": "3.0.3",
        "info": {
            "title": "scanner_bot API",
            "version": Config.BOT_VERSION,
            "description": "Telegram URL Scanner & QR Generator API",
            "contact": {"name": "AbdAleziz", "url": "https://t.me/AbdAleziz_1"},
        },
        "servers": [{"url": Config.WEB_URL, "description": "Production server"}],
        "paths": {
            "/health": {
                "get": {
                    "summary": "Health Check",
                    "responses": {
                        "200": {
                            "description": "Detailed health status",
                            "content": {"application/json": {"schema": {"$ref": "#/components/schemas/HealthResponse"}}},
                        }
                    },
                }
            },
            "/api/stats": {
                "get": {
                    "summary": "Dashboard Stats",
                    "security": [{"basicAuth": []}],
                    "responses": {
                        "200": {"description": "Dashboard statistics"},
                        "401": {"description": "Unauthorized"},
                    },
                }
            },
            "/api/analytics": {
                "get": {
                    "summary": "Analytics Data",
                    "security": [{"basicAuth": []}],
                    "responses": {
                        "200": {"description": "Analytics data including scans, users, threats"},
                        "401": {"description": "Unauthorized"},
                    },
                }
            },
            "/api/performance": {
                "get": {
                    "summary": "Performance Metrics",
                    "security": [{"basicAuth": []}],
                    "responses": {
                        "200": {"description": "CPU, memory, disk, uptime metrics"},
                        "401": {"description": "Unauthorized"},
                    },
                }
            },
            "/api/files": {
                "get": {
                    "summary": "List Files",
                    "security": [{"basicAuth": []}],
                    "responses": {
                        "200": {"description": "List of files in backup directory"},
                        "401": {"description": "Unauthorized"},
                    },
                }
            },
            "/api/files/{filename}": {
                "delete": {
                    "summary": "Delete File",
                    "security": [{"basicAuth": []}],
                    "parameters": [{"name": "filename", "in": "path", "required": True, "schema": {"type": "string"}}],
                    "responses": {
                        "200": {"description": "File deleted"},
                        "401": {"description": "Unauthorized"},
                        "404": {"description": "Not found"},
                    },
                }
            },
            "/api/scan": {
                "post": {
                    "summary": "Scan a URL",
                    "security": [{"basicAuth": []}],
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {"url": {"type": "string"}},
                                    "required": ["url"],
                                }
                            }
                        }
                    },
                    "responses": {
                        "200": {"description": "Scan result"},
                        "401": {"description": "Unauthorized"},
                    },
                }
            },
            "/api/upload": {
                "post": {
                    "summary": "Upload File for Batch Scan",
                    "security": [{"basicAuth": []}],
                    "requestBody": {
                        "content": {
                            "multipart/form-data": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "file": {"type": "string", "format": "binary"}
                                    },
                                }
                            }
                        }
                    },
                    "responses": {
                        "200": {"description": "Batch scan results"},
                        "401": {"description": "Unauthorized"},
                    },
                }
            },
            "/api/activity": {
                "get": {
                    "summary": "Activity Log",
                    "security": [{"basicAuth": []}],
                    "parameters": [
                        {"name": "hours", "in": "query", "schema": {"type": "integer", "default": 24}}
                    ],
                    "responses": {
                        "200": {"description": "Activity data"},
                        "401": {"description": "Unauthorized"},
                    },
                }
            },
            "/api/threats": {
                "get": {
                    "summary": "Query Threats",
                    "parameters": [
                        {"name": "key", "in": "query", "schema": {"type": "string"}},
                        {"name": "url", "in": "query", "schema": {"type": "string"}},
                        {"name": "domain", "in": "query", "schema": {"type": "string"}},
                    ],
                    "responses": {
                        "200": {"description": "Threat data"},
                        "403": {"description": "Invalid API key"},
                    },
                }
            },
        },
        "components": {
            "securitySchemes": {
                "basicAuth": {"type": "http", "scheme": "basic"}
            },
            "schemas": {
                "HealthResponse": {
                    "type": "object",
                    "properties": {
                        "status": {"type": "string"},
                        "timestamp": {"type": "string"},
                        "database": {"type": "string"},
                        "database_size_mb": {"type": "number"},
                        "disk_usage_percent": {"type": "number"},
                        "memory_usage_mb": {"type": "number"},
                        "cpu_percent": {"type": "number"},
                        "uptime_hours": {"type": "number"},
                        "backup_count": {"type": "integer"},
                        "last_backup": {"type": "string"},
                        "telegram_bot": {"type": "string"},
                        "version": {"type": "string"},
                        "owner": {"type": "string"},
                    },
                }
            },
        },
    }

    async def _handle_openapi_json(self, request: web.Request):
        return web.json_response(self.OPENAPI_SPEC)

    async def _handle_api_docs(self, request: web.Request):
        swagger_html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Docs - scanner_bot</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css">
</head>
<body>
    <div id="swagger-ui"></div>
    <script src="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
    <script>
        SwaggerUIBundle({
            url: '/api/openapi.json',
            dom_id: '#swagger-ui',
        });
    </script>
</body>
</html>"""
        return web.Response(text=swagger_html, content_type="text/html")

    # ---------------------------------------------------------------------------
    # WebSocket
    # ---------------------------------------------------------------------------

    async def _handle_websocket(self, request: web.Request):
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        self._ws_clients.add(ws)
        logger.info("WebSocket client connected")

        try:
            async for msg in ws:
                if msg.type == aiohttp.WSMsgType.ERROR:
                    logger.error(f"WebSocket error: {ws.exception()}")
        except asyncio.CancelledError:
            pass
        finally:
            self._ws_clients.discard(ws)
            logger.info("WebSocket client disconnected")

        return ws

    async def broadcast(self, event: str, data: dict):
        msg = json.dumps({"event": event, "data": data})
        dead = set()
        for ws in self._ws_clients:
            try:
                await ws.send_str(msg)
            except Exception:
                dead.add(ws)
        self._ws_clients -= dead

    # ---------------------------------------------------------------------------
    # Stats / Uptime helpers
    # ---------------------------------------------------------------------------

    async def _get_stats(self) -> dict:
        stats = {"users": 0, "vips": 0, "scans_today": 0, "threats_blocked": 0, "total_scans": 0}
        try:
            today = datetime.utcnow().date().isoformat()

            row = await self.db.fetchrow("SELECT COUNT(*) as c FROM users")
            if row:
                stats["users"] = row["c"]

            row = await self.db.fetchrow("SELECT COUNT(*) as c FROM vip_users WHERE expires_at > datetime('now')")
            if row:
                stats["vips"] = row["c"]

            row = await self.db.fetchrow(
                "SELECT COUNT(*) as c FROM scan_history WHERE date(scanned_at) = ?", (today,)
            )
            if row:
                stats["scans_today"] = row["c"]

            row = await self.db.fetchrow("SELECT COUNT(*) as c FROM scan_history WHERE is_threat = 1")
            if row:
                stats["threats_blocked"] = row["c"]

            row = await self.db.fetchrow("SELECT COUNT(*) as c FROM scan_history")
            if row:
                stats["total_scans"] = row["c"]
        except Exception as e:
            logger.error(f"Stats error: {e}")

        stats["uptime"] = humanize.naturaldelta(self._uptime())
        return stats

    def _uptime(self):
        return datetime.utcnow() - self._start_time if hasattr(self, '_start_time') else timedelta(0)

    async def _on_shutdown(self, app):
        for ws in self._ws_clients:
            await ws.close()

    async def start(self):
        self._start_time = datetime.utcnow()
        self.runner = web.AppRunner(self.app)
        await self.runner.setup()
        site = web.TCPSite(self.runner, Config.WEB_HOST, Config.WEB_PORT)
        await site.start()
        logger.info(f"Web dashboard running on http://{Config.WEB_HOST}:{Config.WEB_PORT}")

    async def stop(self):
        if self.runner:
            await self.runner.cleanup()
            logger.info("Web dashboard stopped")
