import logging
from datetime import datetime

from pyrogram import Client, filters
from pyrogram.types import Message

from config import Config
from database import Database
from rbac import RBAC

logger = logging.getLogger(__name__)


async def register_whoami(app: Client, db: Database):
    @app.on_message(filters.command("whoami") & filters.private)
    async def whoami_cmd(client: Client, message: Message):
        uid = message.from_user.id
        user = message.from_user

        role = RBAC.get_role(uid)
        role_names = {-1: "🚫 محظور", 0: "👤 مستخدم", 10: "🛠️ مطور مساعد", 100: "👑 مالك"}
        role_name = role_names.get(role.value, f"غير معروف ({role.value})")

        perms = _get_permissions_text(uid)

        vip_status = "❌ غير مشترك"
        vip_expiry = "—"
        vip_plan = "—"
        vip_row = await db.fetchrow(
            "SELECT expires_at, plan FROM vip_users WHERE user_id = ?", (uid,)
        )
        if vip_row:
            try:
                expires = datetime.fromisoformat(vip_row["expires_at"])
                if expires > datetime.utcnow():
                    vip_status = "✅ مشترك"
                    vip_expiry = vip_row["expires_at"][:19]
                    vip_plan = vip_row.get("plan", "—")
                else:
                    vip_status = "❌ منتهي"
                    vip_expiry = vip_row["expires_at"][:19]
            except Exception:
                pass

        trial_used = await db.fetchval(
            "SELECT COUNT(*) FROM trial_attempts WHERE user_id = ?", (uid,)
        ) or 0
        trial_text = "✅ نعم" if trial_used > 0 else "❌ لا"

        lang_code = await db.fetchval(
            "SELECT lang FROM user_language WHERE user_id = ?", (uid,)
        ) or "ar"
        lang_names = {"ar": "🇸🇦 العربية", "en": "🇬🇧 English", "ku": "🇹🇯 كوردی"}
        lang_display = lang_names.get(lang_code, lang_code)

        user_row = await db.fetchrow(
            "SELECT joined_at FROM users WHERE user_id = ?", (uid,)
        )
        joined_at = user_row["joined_at"][:19] if user_row and user_row.get("joined_at") else "—"

        total_scans = await db.fetchval(
            "SELECT COUNT(*) FROM scan_history WHERE user_id = ?", (uid,)
        ) or 0

        last_scan_row = await db.fetchrow(
            "SELECT scanned_at FROM scan_history WHERE user_id = ? ORDER BY id DESC LIMIT 1",
            (uid,),
        )
        last_scan = last_scan_row["scanned_at"][:19] if last_scan_row else "—"

        text = (
            f"👤 <b>معلوماتي</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"🆔 المعرف: <code>{uid}</code>\n"
            f"👤 الاسم: {user.first_name or ''} {user.last_name or ''}\n"
            f"🔰 الدور: {role_name}\n"
            f"🔑 الصلاحيات: {perms}\n"
            f"⭐ VIP: {vip_status}\n"
            f"📅 ينتهي VIP: {vip_expiry}\n"
            f"📋 الخطة: {vip_plan}\n"
            f"🎁 تجربة مجانية: {trial_text}\n"
            f"🌐 اللغة: {lang_display}\n"
            f"📅 تاريخ الانضمام: {joined_at}\n"
            f"🔍 إجمالي الفحوصات: {total_scans}\n"
            f"🕐 آخر فحص: {last_scan}\n"
            f"━━━━━━━━━━━━━━"
        )
        await message.reply(text)


def _get_permissions_text(user_id: int) -> str:
    role = RBAC.get_role(user_id)
    if role.value >= 100:
        return "👑 جميع الصلاحيات"
    elif role.value >= 10:
        return "📢 إرسال | 🚫 حظر | ✅ فك حظر | 📊 إحصائيات | 🗑️ مسح ذاكرة | 📋 سجلات"
    else:
        return "🔒 لا توجد صلاحيات إدارية"
