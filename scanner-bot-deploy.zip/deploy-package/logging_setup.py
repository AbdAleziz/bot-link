# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import json
import logging
import logging.handlers
import os
import sys
import traceback
from datetime import datetime
from typing import Optional

from config import Config


class JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info and record.exc_info[0]:
            log_entry["exception"] = {
                "type": record.exc_info[0].__name__,
                "message": str(record.exc_info[1]),
                "traceback": "".join(
                    traceback.format_exception(*record.exc_info)
                ),
            }
        if hasattr(record, "user_id"):
            log_entry["user_id"] = record.user_id
        return json.dumps(log_entry, ensure_ascii=False)


class AlertHandler(logging.Handler):
    def __init__(self, bot=None, chat_id: int = 0):
        super().__init__(level=logging.ERROR)
        self.bot = bot
        self.chat_id = chat_id

    async def emit_async(self, record: logging.LogRecord):
        if not self.bot or not self.chat_id:
            return
        try:
            msg = (
                f"🚨 <b>Error Alert</b>\n"
                f"<b>Level:</b> {record.levelname}\n"
                f"<b>Logger:</b> {record.name}\n"
                f"<b>Message:</b> <code>{(record.getMessage()[:500])}</code>"
            )
            await self.bot.send_message(self.chat_id, msg)
        except Exception:
            pass

    def emit(self, record: logging.LogRecord):
        pass


class LoggerSetup:
    _alert_handler: Optional[AlertHandler] = None
    _is_initialized = False

    @classmethod
    def setup(cls, json_format: bool = False):
        if cls._is_initialized:
            return
        cls._is_initialized = True

        log_level = getattr(logging, Config.LOG_LEVEL.upper(), logging.INFO)

        root_logger = logging.getLogger()
        root_logger.setLevel(log_level)

        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)

        formatter = JSONFormatter() if json_format else logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        )

        stream_handler = logging.StreamHandler(sys.stdout)
        stream_handler.setFormatter(formatter)
        root_logger.addHandler(stream_handler)

        if Config.LOG_FILE:
            try:
                os.makedirs(os.path.dirname(Config.LOG_FILE) or ".", exist_ok=True)
                file_handler = logging.handlers.RotatingFileHandler(
                    Config.LOG_FILE,
                    maxBytes=10 * 1024 * 1024,
                    backupCount=5,
                    encoding="utf-8",
                )
                file_handler.setFormatter(formatter)
                root_logger.addHandler(file_handler)
            except Exception as e:
                root_logger.error(f"Failed to setup file logging: {e}")

    @classmethod
    def set_alert_bot(cls, bot, chat_id: int = None):
        target = chat_id or Config.ALERT_LOG_CHANNEL
        if target and bot:
            cls._alert_handler = AlertHandler(bot=bot, chat_id=target)
            logging.getLogger().addHandler(cls._alert_handler)

    @classmethod
    def get_logger(cls, name: str) -> logging.Logger:
        return logging.getLogger(name)


async def log_audit(db, user_id: int, action: str, target_type: str = None, target_id: str = None, details: str = None, ip: str = None):
    if not Config.AUDIT_LOG_ENABLED:
        return
    try:
        await db.execute(
            "INSERT INTO audit_log (user_id, action, target_type, target_id, details, ip, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            user_id, action, target_type, target_id, details, ip, datetime.utcnow().isoformat()
        )
    except Exception as e:
        logging.getLogger(__name__).error(f"Audit log error: {e}")
