"""Background auto-close job for stale tickets."""

import asyncio
import logging

from config import Config
from .tickets import TicketStore

logger = logging.getLogger(__name__)


async def run_auto_close_loop(app, db):
    if Config.SUPPORT_AUTO_CLOSE_HOURS <= 0:
        logger.info("Support auto-close disabled (SUPPORT_AUTO_CLOSE_HOURS=0)")
        return

    ts = TicketStore(db)
    logger.info("Support auto-close job started (every 30m, idle >%dh)", Config.SUPPORT_AUTO_CLOSE_HOURS)
    while True:
        try:
            stale = await ts.auto_close_stale()
            if stale:
                for tkt in stale:
                    # Notify both sides
                    try:
                        await app.send_message(
                            tkt["user_id"],
                            f"ℹ️ " + (f"تم إغلاق التذكرة {tkt['id']} تلقائياً لانتهاء المهلة" if getattr(Config, 'LOCAL_ONLY_MODE', False) else f"Ticket {tkt['id']} auto-closed due to inactivity"),
                        )
                    except Exception:
                        pass
                    if tkt.get("assigned_to"):
                        try:
                            await app.send_message(
                                tkt["assigned_to"],
                                f"ℹ️ " + (f"تم إغلاق التذكرة {tkt['id']} تلقائياً" if getattr(Config, 'LOCAL_ONLY_MODE', False) else f"Ticket {tkt['id']} auto-closed"),
                            )
                        except Exception:
                            pass
        except Exception as e:
            logger.error("Auto-close error: %s", e)
        await asyncio.sleep(1800)  # 30 minutes
