"""Support handlers: /support, /ticket, /reply, /close, /my_tickets, /tickets, /support_admin."""

import logging
import re
from datetime import datetime, timezone

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from config import Config
from logging_setup import log_audit
from rbac import RBAC
from i18n.translator import t, get_user_lang

from .agents import parse_support_users, SupportAgent
from .tickets import TicketStore

logger = logging.getLogger(__name__)

TICKET_ID_RE = re.compile(r"^(T-\d{8}-[A-Z0-9]{4})$", re.IGNORECASE)

_ticket_wizard: dict[int, dict] = {}


def _lang(msg: Message) -> str:
    return get_user_lang(msg.from_user.id)


def _agent_kb(ticket_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📥 استلام", callback_data=f"support_pick_{ticket_id}"),
            InlineKeyboardButton("💬 رد", callback_data=f"support_reply_{ticket_id}"),
            InlineKeyboardButton("✅ إغلاق", callback_data=f"support_close_{ticket_id}"),
        ],
    ])


def _user_ticket_kb(ticket_id: str, is_closed: bool = False) -> InlineKeyboardMarkup:
    if is_closed:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("🏠 القائمة الرئيسية", callback_data="nav_home")],
        ])
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("💬 إضافة رسالة", callback_data=f"support_addmsg_{ticket_id}"),
            InlineKeyboardButton("✅ إغلاق التذكرة", callback_data=f"support_close_{ticket_id}"),
        ],
    ])


async def register_support_handlers(app: Client, db):
    ts = TicketStore(db)
    support_agents = parse_support_users()
    agent_ids = {a.user_id for a in support_agents}

    def is_support_or_higher(uid: int) -> bool:
        return uid in agent_ids or RBAC.is_admin(uid)

    # ── /support ──────────────────────────────────────────────────────────
    @app.on_message(filters.command("support") & filters.private)
    async def support_cmd(client: Client, message: Message):
        uid = message.from_user.id
        lang = _lang(message)
        agents = parse_support_users()

        if not agents:
            await message.reply(
                "🛟 " + t("support.empty", lang=lang),
            )
            return

        lines = [f"🛟  {t('support.title', lang=lang)}", "─" * 29]
        for idx, a in enumerate(agents, 1):
            name_display = a.name if a.name else str(a.user_id)
            role_display = f" — {a.role}" if a.role else ""
            hours_display = a.hours if a.hours else "متاح دائماً" if lang == "ar" else "Always available"
            lines.append(f"{idx}) 👤 {name_display}{role_display}")
            lines.append(f"   ⏰ {hours_display}")
            lines.append(f"   [💬 {t('support.button.contact', lang=lang)}] [👤 {t('support.button.profile', lang=lang)}]")
            lines.append("")

        kb = []
        for a in agents:
            row = []
            contact_method = Config.SUPPORT_CONTACT_METHOD
            if contact_method in ("open_chat", "both"):
                row.append(InlineKeyboardButton(
                    f"💬 {t('support.button.contact', lang=lang)}",
                    url=f"tg://resolve?user_id={a.user_id}",
                ))
            if contact_method in ("username", "both"):
                row.append(InlineKeyboardButton(
                    f"👤 {t('support.button.profile', lang=lang)}",
                    url=f"tg://user?id={a.user_id}",
                ))
            kb.append(row)

        if Config.SUPPORT_TICKETS_ENABLED:
            kb.append([InlineKeyboardButton(
                f"🎫 {t('support.button.new_ticket', lang=lang)}",
                callback_data="support_new_ticket",
            )])

        kb.append([InlineKeyboardButton("🏠 " + t("main.menu.home", lang=lang), callback_data="nav_home")])

        footer = t("support.footer", lang=lang) if hasattr(t, "footer") else ""
        text = "\n".join(lines)
        if footer:
            text += f"\n─" * 29 + f"\n{footer}"

        await message.reply(text, reply_markup=InlineKeyboardMarkup(kb))

    # ── /ticket wizard ────────────────────────────────────────────────────
    if Config.SUPPORT_TICKETS_ENABLED:

        @app.on_message(filters.command("ticket") & filters.private)
        async def ticket_cmd(client: Client, message: Message):
            uid = message.from_user.id
            lang = _lang(message)

            open_count = await ts.open_ticket_count(uid)
            if open_count >= Config.SUPPORT_MAX_OPEN_TICKETS:
                await message.reply(
                    "❌ " + t("support.tickets.limit_exceeded", lang=lang, limit=Config.SUPPORT_MAX_OPEN_TICKETS),
                )
                await log_audit(db, uid, "support.ticket.limit_exceeded", details=f"open_tickets={open_count}")
                return

            _ticket_wizard[uid] = {"step": "awaiting_subject"}
            await message.reply(
                t("support.tickets.new_intro", lang=lang),
            )

        @app.on_callback_query(filters.regex(r"^support_new_ticket$"))
        async def support_new_ticket_cb(client: Client, cb: CallbackQuery):
            uid = cb.from_user.id
            lang = _lang(cb.message)

            open_count = await ts.open_ticket_count(uid)
            if open_count >= Config.SUPPORT_MAX_OPEN_TICKETS:
                await cb.message.edit(
                    "❌ " + t("support.tickets.limit_exceeded", lang=lang, limit=Config.SUPPORT_MAX_OPEN_TICKETS),
                )
                await log_audit(db, uid, "support.ticket.limit_exceeded", details=f"open_tickets={open_count}")
                return

            _ticket_wizard[uid] = {"step": "awaiting_subject"}
            await cb.message.edit(t("support.tickets.new_intro", lang=lang))
            await cb.answer()

    # ── /my_tickets ────────────────────────────────────────────────────────
    @app.on_message(filters.command("my_tickets") & filters.private)
    async def my_tickets_cmd(client: Client, message: Message):
        uid = message.from_user.id
        lang = _lang(message)
        tickets = await ts.list_user_tickets(uid)
        if not tickets:
            await message.reply("📭 " + ( "لا توجد تذاكر" if lang == "ar" else "No tickets" ))
            return

        lines = ["📋 " + ( "تذاكري" if lang == "ar" else "My Tickets" )]
        for tkt in tickets[:10]:
            lines.append(f"🎫 {tkt['id']} — {tkt['status']} ({tkt.get('updated_at','')[:10]})")
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🏠 " + t("main.menu.home", lang=lang), callback_data="nav_home")],
        ])
        await message.reply("\n".join(lines), reply_markup=kb)

    # ── /tickets (agent view) ──────────────────────────────────────────────
    @app.on_message(filters.command("tickets") & filters.private)
    async def tickets_cmd(client: Client, message: Message):
        uid = message.from_user.id
        lang = _lang(message)
        if not is_support_or_higher(uid):
            await message.reply("❌ " + t("errors.no_permission", lang=lang))
            return

        open_tickets = await ts.list_open_tickets()
        assigned = await ts.list_assigned_tickets(uid)

        if not open_tickets and not assigned:
            await message.reply("📭 " + ( "لا توجد تذاكر مفتوحة" if lang == "ar" else "No open tickets" ))
            return

        lines = [f"🎫 " + ( "التذاكر المفتوحة" if lang == "ar" else "Open Tickets" )]
        for tkt in open_tickets[:20]:
            assign = f" → {tkt.get('assigned_to','')}" if tkt.get('assigned_to') else " (غير مسندة)"
            lines.append(f"{tkt['id']} — {tkt['status']}{assign} — {tkt.get('subject','')[:40]}")
        await message.reply("\n".join(lines))

    # ── /support_admin ──────────────────────────────────────────────────────
    @app.on_message(filters.command("support_admin") & filters.private)
    async def support_admin_cmd(client: Client, message: Message):
        uid = message.from_user.id
        lang = _lang(message)
        if not is_support_or_higher(uid):
            await message.reply("❌ " + t("errors.no_permission", lang=lang))
            return

        open_tickets = await ts.list_open_tickets()
        unassigned = [t for t in open_tickets if not t.get("assigned_to")]

        text = (
            f"🛟 {t('support.admin.title', lang=lang)}\n"
            f"─" * 29 + "\n"
            f"📊 " + ( "مفتوحة" if lang == "ar" else "Open" ) + f": {len(open_tickets)}  |  "
            + ( "غير مسندة" if lang == "ar" else "Unassigned" ) + f": {len(unassigned)}\n"
        )
        kb = []
        for tkt in unassigned[:10]:
            kb.append([InlineKeyboardButton(
                f"📥 {t('support.admin.picked', lang=lang)} — {tkt['id']} ({tkt.get('subject','')[:30]})",
                callback_data=f"support_pick_{tkt['id']}",
            )])
        kb.append([InlineKeyboardButton("🏠 " + t("main.menu.home", lang=lang), callback_data="nav_home")])
        await message.reply(text, reply_markup=InlineKeyboardMarkup(kb))

    # ── /reply ──────────────────────────────────────────────────────────────
    @app.on_message(filters.command("reply") & filters.private)
    async def reply_cmd(client: Client, message: Message):
        uid = message.from_user.id
        lang = _lang(message)
        if not is_support_or_higher(uid):
            await message.reply("❌ " + t("errors.no_permission", lang=lang))
            return

        parts = message.text.split(maxsplit=2)
        if len(parts) < 3:
            await message.reply(
                "💡 " + ( "استعمال: /reply <رقم_التذكرة> <الرسالة>" if lang == "ar" else "Usage: /reply <ticket_id> <message>" )
            )
            return

        _, ticket_id, reply_body = parts
        if not TICKET_ID_RE.match(ticket_id):
            await message.reply("❌ " + ( "رقم تذكرة غير صالح" if lang == "ar" else "Invalid ticket ID" ))
            return

        tkt = await ts.get_ticket(ticket_id.upper())
        if not tkt:
            await message.reply("❌ " + t("support.error.ticket_not_found", lang=lang))
            return
        if tkt["status"] == "closed":
            await message.reply("❌ " + t("support.error.ticket_already_closed", lang=lang))
            return

        await ts.reply_to_ticket(ticket_id.upper(), uid, True, reply_body)

        # Notify the user
        try:
            kb = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("💬 " + t("support.button.reply_more", lang=lang), callback_data=f"support_addmsg_{ticket_id.upper()}"),
                    InlineKeyboardButton("✅ " + t("support.button.close_ticket", lang=lang), callback_data=f"support_close_{ticket_id.upper()}"),
                ],
            ])
            await client.send_message(
                tkt["user_id"],
                f"💬 {t('support.message_to_user', lang=get_user_lang(tkt['user_id']), ticket_id=ticket_id.upper())}\n─" * 29 + f"\n{reply_body}\n" + "─" * 29,
                reply_markup=kb,
            )
        except Exception as e:
            logger.warning("Could not notify user %d about reply: %s", tkt["user_id"], e)

        await message.reply("✅ " + ( "تم إرسال الرد" if lang == "ar" else "Reply sent" ))
        await log_audit(db, uid, "support.ticket.reply", target_id=ticket_id.upper(), details=f"user_id={tkt['user_id']} len={len(reply_body)}")

    # ── /close ──────────────────────────────────────────────────────────────
    @app.on_message(filters.command("close") & filters.private)
    async def close_cmd(client: Client, message: Message):
        uid = message.from_user.id
        lang = _lang(message)
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            await message.reply(
                "💡 " + ( "استعمال: /close <رقم_التذكرة>" if lang == "ar" else "Usage: /close <ticket_id>" )
            )
            return

        ticket_id = parts[1].strip().upper()
        if not TICKET_ID_RE.match(ticket_id):
            await message.reply("❌ " + ( "رقم تذكرة غير صالح" if lang == "ar" else "Invalid ticket ID" ))
            return

        tkt = await ts.get_ticket(ticket_id)
        if not tkt:
            await message.reply("❌ " + t("support.error.ticket_not_found", lang=lang))
            return
        if tkt["status"] == "closed":
            await message.reply("❌ " + t("support.error.ticket_already_closed", lang=lang))
            return

        is_owner = tkt["user_id"] == uid or is_support_or_higher(uid)
        if not is_owner:
            await message.reply("❌ " + t("errors.no_permission", lang=lang))
            return

        await ts.close_ticket(ticket_id, uid)
        await log_audit(db, uid, "support.ticket.close", target_id=ticket_id, details=f"ticket_user_id={tkt['user_id']}")

        # Notify the agent if assigned
        if tkt.get("assigned_to") and tkt["assigned_to"] != uid:
            try:
                await client.send_message(
                    tkt["assigned_to"],
                    f"✅ " + ( f"تم إغلاق التذكرة {ticket_id} بواسطة المستخدم" if lang == "ar" else f"Ticket {ticket_id} closed by user" ),
                )
            except Exception:
                pass

        await message.reply("✅ " + ( "تم إغلاق التذكرة" if lang == "ar" else "Ticket closed" ))

    # ── Callback: support_pick_ ──────────────────────────────────────────────
    @app.on_callback_query(filters.regex(r"^support_pick_(T-\d{8}-[A-Z0-9]{4})$"))
    async def support_pick_cb(client: Client, cb: CallbackQuery):
        uid = cb.from_user.id
        lang = _lang(cb.message)
        if not is_support_or_higher(uid):
            await cb.answer("❌ " + t("errors.no_permission", lang=lang), show_alert=True)
            return

        ticket_id = cb.matches[0].group(1)
        tkt = await ts.get_ticket(ticket_id)
        if not tkt:
            await cb.answer("❌ " + t("support.error.ticket_not_found", lang=lang), show_alert=True)
            return

        await ts.assign_ticket(ticket_id, uid)
        await log_audit(db, uid, "support.ticket.assign", target_id=ticket_id, details=f"assigned_to={uid}")

        await cb.message.edit(
            f"✅ {t('support.admin.picked', lang=lang)} {ticket_id}",
        )
        await cb.answer("✅ " + ( "تم استلام التذكرة" if lang == "ar" else "Ticket picked" ))

        # Notify the user
        try:
            await client.send_message(
                tkt["user_id"],
                f"📥 " + (f"تم استلام تذكرتك {ticket_id} من فريق الدعم" if lang == "ar" else f"Your ticket {ticket_id} has been picked by support"),
            )
        except Exception:
            pass

    # ── Callback: support_close_ ──────────────────────────────────────────────
    @app.on_callback_query(filters.regex(r"^support_close_(T-\d{8}-[A-Z0-9]{4})$"))
    async def support_close_cb(client: Client, cb: CallbackQuery):
        uid = cb.from_user.id
        lang = _lang(cb.message)
        ticket_id = cb.matches[0].group(1)
        tkt = await ts.get_ticket(ticket_id)
        if not tkt:
            await cb.answer("❌ " + t("support.error.ticket_not_found", lang=lang), show_alert=True)
            return
        if tkt["status"] == "closed":
            await cb.answer("❌ " + t("support.error.ticket_already_closed", lang=lang), show_alert=True)
            return

        is_owner = tkt["user_id"] == uid or is_support_or_higher(uid)
        if not is_owner:
            await cb.answer("❌ " + t("errors.no_permission", lang=lang), show_alert=True)
            return

        await ts.close_ticket(ticket_id, uid)
        await log_audit(db, uid, "support.ticket.close", target_id=ticket_id, details=f"ticket_user_id={tkt['user_id']}")

        await cb.message.edit(
            f"✅ " + (f"تم إغلاق التذكرة {ticket_id}" if lang == "ar" else f"Ticket {ticket_id} closed"),
        )
        await cb.answer("✅ " + ( "تم الإغلاق" if lang == "ar" else "Closed" ))

    # ── Callback: support_reply_ (triggers inline reply prompt) ────────────
    @app.on_callback_query(filters.regex(r"^support_reply_(T-\d{8}-[A-Z0-9]{4})$"))
    async def support_reply_cb(client: Client, cb: CallbackQuery):
        uid = cb.from_user.id
        lang = _lang(cb.message)
        if not is_support_or_higher(uid):
            await cb.answer("❌ " + t("errors.no_permission", lang=lang), show_alert=True)
            return
        ticket_id = cb.matches[0].group(1)
        _ticket_wizard[uid] = {"step": "reply", "ticket_id": ticket_id}
        await cb.message.reply(
            "💬 " + (f"اكتب ردك للتذكرة {ticket_id}:" if lang == "ar" else f"Type your reply for ticket {ticket_id}:"),
        )
        await cb.answer()

    # ── Callback: support_addmsg_ (user adds message) ────────────────────
    @app.on_callback_query(filters.regex(r"^support_addmsg_(T-\d{8}-[A-Z0-9]{4})$"))
    async def support_addmsg_cb(client: Client, cb: CallbackQuery):
        uid = cb.from_user.id
        lang = _lang(cb.message)
        ticket_id = cb.matches[0].group(1)
        _ticket_wizard[uid] = {"step": "addmsg", "ticket_id": ticket_id}
        await cb.message.reply(
            "💬 " + (f"اكتب رسالتك الإضافية للتذكرة {ticket_id}:" if lang == "ar" else f"Type your additional message for ticket {ticket_id}:"),
        )
        await cb.answer()

    # ── Text handler: support ticket wizard steps ────────────────────────
    original_handle = None

    # We wrap the existing handle_text to add wizard support.
    # Instead of a separate handler, we inject into the existing text handler.
    # Since we can't modify handle_text in main.py without touching it,
    # we add a new handler with high priority via group=1.
    @app.on_message(filters.text & filters.private & ~filters.command([]), group=1)
    async def support_wizard_handler(client: Client, message: Message):
        uid = message.from_user.id
        if uid not in _ticket_wizard:
            return  # let other handlers process

        wizard = _ticket_wizard[uid]
        step = wizard.get("step")
        lang = get_user_lang(uid)

        if step == "awaiting_subject":
            subject = message.text.strip()[:200]
            wizard["subject"] = subject
            wizard["step"] = "awaiting_body"
            await message.reply(
                "📝 " + ( "الآن اكتب رسالتك بالتفصيل:" if lang == "ar" else "Now write your message in detail:" ),
            )
            return

        if step == "awaiting_body":
            subject = wizard.get("subject", "No subject")
            body = message.text.strip()
            ticket_id = await ts.create_ticket(uid, subject, body)
            _ticket_wizard.pop(uid, None)

            await log_audit(db, uid, "support.ticket.open", target_id=ticket_id, details=f"subject='{subject}'")

            await message.reply(
                f"✅ " + t("support.tickets.created", lang=lang, ticket_id=ticket_id),
                reply_markup=_user_ticket_kb(ticket_id),
            )

            # Notify all agents
            agents = parse_support_users()
            for agent in agents:
                try:
                    kb = _agent_kb(ticket_id)
                    await client.send_message(
                        agent.user_id,
                        f"🎫 " + ( "تذكرة جديدة" if lang == "ar" else "New ticket" ) + f"  {ticket_id}\n"
                        f"👤 من: @{message.from_user.username or '—'} ({uid})\n"
                        f"🕐 {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')}\n"
                        f"─" * 29 + f"\n{subject}\n\n{body[:400]}\n" + "─" * 29,
                        reply_markup=kb,
                    )
                except Exception as e:
                    logger.warning("Could not notify agent %d: %s", agent.user_id, e)

            # Forward to inbox channel if configured
            if Config.SUPPORT_INBOX_CHANNEL:
                try:
                    await client.send_message(
                        Config.SUPPORT_INBOX_CHANNEL,
                        f"🎫 {ticket_id}\n👤 {uid}\n📝 {subject}\n\n{body[:500]}",
                    )
                except Exception as e:
                    logger.warning("Could not forward to inbox channel: %s", e)
            return

        if step in ("reply", "addmsg"):
            ticket_id = wizard["ticket_id"]
            is_agent = step == "reply"
            body = message.text.strip()

            if is_agent:
                tkt = await ts.get_ticket(ticket_id)
                if not tkt:
                    await message.reply("❌ " + ( "تذكرة غير موجودة" if lang == "ar" else "Ticket not found" ))
                    _ticket_wizard.pop(uid, None)
                    return

                await ts.reply_to_ticket(ticket_id, uid, True, body)
                await log_audit(db, uid, "support.ticket.reply", target_id=ticket_id, details=f"user_id={tkt['user_id']} len={len(body)}")

                # Notify the user
                try:
                    user_kb = InlineKeyboardMarkup([
                        [
                            InlineKeyboardButton("💬 " + t("support.button.reply_more", lang=lang), callback_data=f"support_addmsg_{ticket_id}"),
                            InlineKeyboardButton("✅ " + t("support.button.close_ticket", lang=lang), callback_data=f"support_close_{ticket_id}"),
                        ],
                    ])
                    await client.send_message(
                        tkt["user_id"],
                        f"💬 {t('support.message_to_user', lang=get_user_lang(tkt['user_id']), ticket_id=ticket_id)}\n" + "─" * 29 + f"\n{body}\n" + "─" * 29,
                        reply_markup=user_kb,
                    )
                except Exception as e:
                    logger.warning("Could not notify user: %s", e)

                await message.reply("✅ " + ( "تم إرسال الرد" if lang == "ar" else "Reply sent" ))
            else:
                await ts.reply_to_ticket(ticket_id, uid, False, body)
                await log_audit(db, uid, "support.ticket.reply", target_id=ticket_id, details=f"user_message len={len(body)}")

                # Notify assigned agent
                tkt = await ts.get_ticket(ticket_id)
                if tkt and tkt.get("assigned_to"):
                    try:
                        kb = _agent_kb(ticket_id)
                        await client.send_message(
                            tkt["assigned_to"],
                            f"💬 {t('support.received_from_user', lang=get_user_lang(tkt['assigned_to']), ticket_id=ticket_id)}\n" + "─" * 29 + f"\n{body}\n" + "─" * 29,
                            reply_markup=kb,
                        )
                    except Exception:
                        pass

                await message.reply("✅ " + ( "تم إرسال رسالتك" if lang == "ar" else "Your message has been sent" ))

            _ticket_wizard.pop(uid, None)
            return
