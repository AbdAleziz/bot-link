"""TicketStore: create / list / reply / close / auto-close."""

import asyncio
import logging
import random
import string
from datetime import datetime, timedelta, timezone

from config import Config

logger = logging.getLogger(__name__)


def _ticket_id() -> str:
    date_part = datetime.now(timezone.utc).strftime("%Y%m%d")
    rand = "".join(random.choices(string.ascii_uppercase + string.digits, k=4))
    return f"T-{date_part}-{rand}"


class TicketStore:
    def __init__(self, db):
        self._db = db

    async def create_ticket(self, user_id: int, subject: str, body: str) -> str:
        tid = _ticket_id()
        now = datetime.now(timezone.utc).isoformat()
        await self._db.execute(
            """INSERT INTO support_tickets (id, user_id, status, subject, created_at, updated_at)
               VALUES (?, ?, 'open', ?, ?, ?)""",
            tid, user_id, subject[:200], now, now,
        )
        await self._db.execute(
            """INSERT INTO support_messages (ticket_id, sender_id, is_agent, body, sent_at)
               VALUES (?, ?, 0, ?, ?)""",
            tid, user_id, body, now,
        )
        logger.info("Ticket %s created by user %d", tid, user_id)
        return tid

    async def get_ticket(self, ticket_id: str) -> dict | None:
        row = await self._db.fetchrow(
            "SELECT * FROM support_tickets WHERE id = ?", (ticket_id,)
        )
        return dict(row) if row else None

    async def list_user_tickets(self, user_id: int) -> list[dict]:
        rows = await self._db.fetch(
            "SELECT * FROM support_tickets WHERE user_id = ? ORDER BY updated_at DESC",
            (user_id,),
        )
        return [dict(r) for r in rows] if rows else []

    async def list_open_tickets(self) -> list[dict]:
        rows = await self._db.fetch(
            "SELECT * FROM support_tickets WHERE status != 'closed' ORDER BY created_at ASC",
        )
        return [dict(r) for r in rows] if rows else []

    async def list_assigned_tickets(self, agent_id: int) -> list[dict]:
        rows = await self._db.fetch(
            "SELECT * FROM support_tickets WHERE assigned_to = ? AND status != 'closed' ORDER BY created_at ASC",
            (agent_id,),
        )
        return [dict(r) for r in rows] if rows else []

    async def open_ticket_count(self, user_id: int) -> int:
        row = await self._db.fetchval(
            "SELECT COUNT(*) FROM support_tickets WHERE user_id = ? AND status != 'closed'",
            (user_id,),
        )
        return row or 0

    async def assign_ticket(self, ticket_id: str, agent_id: int):
        now = datetime.now(timezone.utc).isoformat()
        await self._db.execute(
            "UPDATE support_tickets SET assigned_to = ?, status = 'assigned', updated_at = ? WHERE id = ?",
            agent_id, now, ticket_id,
        )
        logger.info("Ticket %s assigned to agent %d", ticket_id, agent_id)

    async def reply_to_ticket(self, ticket_id: str, sender_id: int, is_agent: bool, body: str):
        now = datetime.now(timezone.utc).isoformat()
        new_status = "awaiting_user" if is_agent else "open"
        await self._db.execute(
            "UPDATE support_tickets SET status = ?, updated_at = ? WHERE id = ?",
            new_status, now, ticket_id,
        )
        await self._db.execute(
            """INSERT INTO support_messages (ticket_id, sender_id, is_agent, body, sent_at)
               VALUES (?, ?, ?, ?, ?)""",
            ticket_id, sender_id, 1 if is_agent else 0, body, now,
        )

    async def close_ticket(self, ticket_id: str, closed_by: int):
        now = datetime.now(timezone.utc).isoformat()
        await self._db.execute(
            "UPDATE support_tickets SET status = 'closed', closed_at = ?, closed_by = ?, updated_at = ? WHERE id = ?",
            now, closed_by, now, ticket_id,
        )
        logger.info("Ticket %s closed by %d", ticket_id, closed_by)

    async def get_messages(self, ticket_id: str) -> list[dict]:
        rows = await self._db.fetch(
            "SELECT * FROM support_messages WHERE ticket_id = ? ORDER BY sent_at ASC",
            (ticket_id,),
        )
        return [dict(r) for r in rows] if rows else []

    async def auto_close_stale(self):
        hours = Config.SUPPORT_AUTO_CLOSE_HOURS
        if hours <= 0:
            return
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
        stale = await self._db.fetch(
            "SELECT * FROM support_tickets WHERE status IN ('open','assigned','awaiting_user') AND updated_at < ?",
            (cutoff,),
        )
        now = datetime.now(timezone.utc).isoformat()
        for row in stale:
            tid = row["id"]
            await self._db.execute(
                "UPDATE support_tickets SET status = 'closed', closed_at = ?, updated_at = ? WHERE id = ?",
                now, now, tid,
            )
            logger.info("Ticket %s auto-closed after %d hours of inactivity", tid, hours)
        return stale
