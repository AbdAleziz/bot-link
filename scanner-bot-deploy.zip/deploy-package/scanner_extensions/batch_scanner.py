import asyncio
import csv
import io
import logging
import os
from datetime import datetime
from hashlib import sha256
from typing import Optional

from pyrogram import Client, filters
from pyrogram.enums import MessageMediaType
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from config import Config
from database import Database
from rbac import RBAC, Role
from queue_system import task_queue, QueueTask, TaskPriority

logger = logging.getLogger(__name__)


class BatchScanTask:
    def __init__(self, url: str, user_id: int, scan_id: str):
        self.url = url
        self.user_id = user_id
        self.scan_id = scan_id


PROGRESS = {}
BATCH_SCANS = {}


async def register_batch_scanner(app: Client, db: Database):
    @app.on_message(filters.command("batchscan") & filters.private)
    async def batchscan_cmd(client: Client, message: Message):
        uid = message.from_user.id
        role = RBAC.get_role(uid)
        if role not in (Role.OWNER, Role.SUB_DEV):
            await message.reply("❌ هذا الأمر خاص بالمشرفين وأعضاء VIP.")
            return

        vip = await _is_vip(db, uid)
        if not vip and role == Role.USER:
            await message.reply("❌ هذا الأمر خاص بأعضاء VIP.")
            return

        if not message.reply_to_message:
            await message.reply("❌ أرسل ملف .txt كمرفق مع الأمر /batchscan\n(كل رابط في سطر، حد أقصى 500 سطر)")
            return

        doc = message.reply_to_message
        if doc.media_type != MessageMediaType.DOCUMENT:
            await message.reply("❌ يرجى إرفاق ملف .txt مع الأمر.")
            return

        file_name = doc.document.file_name or ""
        if not file_name.endswith(".txt"):
            await message.reply("❌ يُقبل فقط ملفات .txt.")
            return

        sent = await message.reply("⬇️ جاري تحميل الملف...")
        try:
            file_path = await doc.download()
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                lines = [l.strip() for l in f.read().splitlines() if l.strip()]
            os.remove(file_path)
        except Exception as e:
            await sent.edit(f"❌ فشل قراءة الملف: {e}")
            return

        if not lines:
            await sent.edit("❌ الملف فارغ.")
            return

        if len(lines) > 500:
            await sent.edit(f"❌ تجاوز الحد الأقصى (500 سطر). الملف يحتوي على {len(lines)} سطرًا.")
            return

        if role == Role.OWNER:
            max_urls = len(lines)
        elif role in (Role.SUB_DEV,) or vip:
            max_urls = 500
        else:
            max_urls = 10

        urls = lines[:max_urls]
        scan_id = sha256(f"{uid}:{datetime.utcnow().isoformat()}".encode()).hexdigest()[:12]
        BATCH_SCANS[scan_id] = {
            "user_id": uid,
            "total": len(urls),
            "completed": 0,
            "results": [],
            "scan_id": scan_id,
            "status": "running",
        }

        await sent.edit(
            f"📦 <b>الفحص الجماعي</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"🔗 الروابط: {len(urls)}\n"
            f"📋 المعرف: <code>{scan_id}</code>\n"
            f"⏳ جاري التحميل في قائمة الانتظار..."
        )

        for url in urls:
            task = QueueTask(
                priority=TaskPriority.NORMAL,
                name="batch_scan",
                data={"url": url, "user_id": uid, "scan_id": scan_id},
            )
            await task_queue.push(task)

        progress_msg = await client.send_message(
            uid,
            f"📊 <b>تقدم الفحص</b> ({scan_id})\n━━━━━━━━━━━━━━\n"
            f"✅ 0 / {len(urls)} (0%)\n"
            f"━━━━━━━━━━━━━━",
        )
        PROGRESS[scan_id] = {"total": len(urls), "msg_id": progress_msg.id, "last_pct": 0}

    @app.on_message(filters.command("batchstatus") & filters.private)
    async def batchstatus_cmd(client: Client, message: Message):
        uid = message.from_user.id
        parts = message.text.split(maxsplit=1)
        scan_id = parts[1].strip() if len(parts) > 1 else None
        if not scan_id:
            active = [s for s in BATCH_SCANS.values() if s["user_id"] == uid]
            if not active:
                await message.reply("📭 لا توجد فحوصات جماعية نشطة.")
                return
            text = "📋 <b>الفحوصات الجماعية النشطة:</b>\n━━━━━━━━━━━━━━\n"
            for s in active:
                text += f"• <code>{s['scan_id']}</code>: {s['completed']}/{s['total']} ({s['status']})\n"
            await message.reply(text)
            return

        scan = BATCH_SCANS.get(scan_id)
        if not scan or scan["user_id"] != uid:
            await message.reply("❌ لم يتم العثور على الفحص.")
            return

        text = (
            f"📊 <b>حالة الفحص الجماعي</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"📋 المعرف: <code>{scan_id}</code>\n"
            f"✅ المكتمل: {scan['completed']}/{scan['total']}\n"
            f"📌 الحالة: {scan['status']}\n"
            f"━━━━━━━━━━━━━━"
        )
        await message.reply(text)


async def _is_vip(db: Database, uid: int) -> bool:
    row = await db.fetchrow("SELECT expires_at FROM vip_users WHERE user_id = ?", (uid,))
    if not row:
        return False
    try:
        expires = datetime.fromisoformat(row["expires_at"])
        return expires > datetime.utcnow()
    except Exception:
        return False


async def handle_batch_scan_task(task: QueueTask):
    data = task.data
    url = data["url"]
    user_id = data["user_id"]
    scan_id = data["scan_id"]

    try:
        from scanner import Scanner
        scanner = Scanner(await _get_db())
        result = await asyncio.wait_for(
            scanner.scan_url(url, user_id),
            timeout=Config.SCAN_TIMEOUT + 2,
        )
    except Exception as e:
        result = {"url": url, "error": str(e)[:200], "is_threat": False, "trust_score": 0}

    scan = BATCH_SCANS.get(scan_id)
    if scan:
        scan["completed"] += 1
        scan["results"].append(result)
        await _update_progress(scan_id, scan)


async def _get_db():
    from database import Database
    return Database()


async def _update_progress(scan_id: str, scan: dict):
    p = PROGRESS.get(scan_id)
    if not p:
        return
    total = p["total"]
    done = scan["completed"]
    pct = int((done / total) * 100) if total > 0 else 100
    if pct >= p["last_pct"] + 5 or done == total:
        p["last_pct"] = pct
        await _edit_progress(scan_id, done, total, pct)

    if done >= total:
        scan["status"] = "completed"
        await _finalize_batch(scan_id, scan)


async def _edit_progress(scan_id: str, done: int, total: int, pct: int):
    try:
        from main import app
        msg_id = PROGRESS[scan_id]["msg_id"]
        await app.edit_message_text(
            PROGRESS[scan_id]["user_id"] if "user_id" in PROGRESS.get(scan_id, {}) else scan_id,
            msg_id,
            f"📊 <b>تقدم الفحص</b> ({scan_id})\n━━━━━━━━━━━━━━\n"
            f"✅ {done} / {total} ({pct}%)\n"
            f"{'█' * (pct // 10)}{'░' * (10 - pct // 10)}\n"
            f"━━━━━━━━━━━━━━",
        )
    except Exception:
        pass


async def _finalize_batch(scan_id: str, scan: dict):
    try:
        uid = scan["user_id"]
        results = scan["results"]
        safe = sum(1 for r in results if not r.get("error") and not r.get("is_threat"))
        threats = sum(1 for r in results if not r.get("error") and r.get("is_threat"))
        errors = sum(1 for r in results if r.get("error"))

        pdf_path = await _generate_pdf_report(scan_id, results, safe, threats, errors)
        csv_buf = _generate_csv_report(results)

        from main import app
        if pdf_path:
            await app.send_document(
                uid,
                document=pdf_path,
                caption=f"📄 <b>تقرير PDF</b> — الفحص الجماعي {scan_id}",
            )
            os.remove(pdf_path)

        csv_buf.name = f"batchscan_{scan_id}.csv"
        await app.send_document(
            uid,
            document=csv_buf,
            caption=f"📊 <b>تقرير CSV</b> — الفحص الجماعي {scan_id}",
        )

        summary = (
            f"✅ <b>اكتمل الفحص الجماعي</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"📋 المعرف: <code>{scan_id}</code>\n"
            f"🔗 الإجمالي: {len(results)}\n"
            f"✅ آمن: {safe}\n"
            f"🚫 خطر: {threats}\n"
            f"⚠️ أخطاء: {errors}\n"
            f"━━━━━━━━━━━━━━"
        )
        await app.send_message(uid, summary)

        p = PROGRESS.get(scan_id)
        if p:
            try:
                await app.delete_messages(uid, p["msg_id"])
            except Exception:
                pass
            PROGRESS.pop(scan_id, None)
    except Exception as e:
        logger.error(f"Batch finalize error: {e}")


async def _generate_pdf_report(scan_id: str, results: list, safe: int, threats: int, errors: int) -> Optional[str]:
    try:
        from fpdf import FPDF

        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", "B", 16)
        pdf.cell(0, 10, f"Batch Scan Report - {scan_id}", ln=True, align="C")
        pdf.ln(5)
        pdf.set_font("Arial", "", 12)
        pdf.cell(0, 8, f"Date: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC", ln=True)
        pdf.cell(0, 8, f"Total: {len(results)} | Safe: {safe} | Threats: {threats} | Errors: {errors}", ln=True)
        pdf.ln(5)

        pdf.set_font("Arial", "B", 10)
        col_w = [60, 30, 30, 70]
        headers = ["URL", "Status", "Score", "Details"]
        for i, h in enumerate(headers):
            pdf.cell(col_w[i], 8, h, border=1)
        pdf.ln()

        pdf.set_font("Arial", "", 8)
        for r in results:
            url = (r.get("url", "") or "")[:55]
            if r.get("error"):
                status = "Error"
                score = "-"
                details = r["error"][:65]
            else:
                status = "Threat" if r.get("is_threat") else "Safe"
                score = f"{r.get('trust_score', 0):.0f}%"
                details = r.get("threat_type", "") or ""
            pdf.cell(col_w[0], 6, url, border=1)
            pdf.cell(col_w[1], 6, status, border=1)
            pdf.cell(col_w[2], 6, score, border=1)
            pdf.cell(col_w[3], 6, details[:65], border=1)
            pdf.ln()

        pdf_path = f"data/batchscan_{scan_id}.pdf"
        pdf.output(pdf_path)
        return pdf_path
    except ImportError:
        logger.warning("fpdf2 not available, skipping PDF report")
        return None
    except Exception as e:
        logger.error(f"PDF generation error: {e}")
        return None


def _generate_csv_report(results: list) -> io.BytesIO:
    buf = io.BytesIO()
    fieldnames = ["url", "status", "trust_score", "threat_type", "error"]
    writer = csv.DictWriter(buf, fieldnames=fieldnames)
    writer.writeheader()
    for r in results:
        if r.get("error"):
            writer.writerow({"url": r.get("url", ""), "status": "error", "trust_score": 0, "threat_type": "", "error": r["error"]})
        else:
            writer.writerow({
                "url": r.get("url", ""),
                "status": "threat" if r.get("is_threat") else "safe",
                "trust_score": r.get("trust_score", 0),
                "threat_type": r.get("threat_type", ""),
                "error": "",
            })
    buf.seek(0)
    return buf
