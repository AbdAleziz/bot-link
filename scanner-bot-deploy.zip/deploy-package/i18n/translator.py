import json
import logging
import os
from pathlib import Path

logger = logging.getLogger("i18n")


_translations: dict[str, dict[str, str]] = {}
_user_lang_cache: dict[int, str] = {}
_missing_keys_logged: set[str] = set()

_LOCALE_DIR = Path(__file__).parent


def _load_locale(lang: str) -> dict[str, str]:
    path = _LOCALE_DIR / f"{lang}.json"
    if not path.exists():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logger.warning(f"Failed to load locale {lang}: {e}")
        return {}


def _ensure_loaded(lang: str):
    if lang not in _translations:
        _translations[lang] = _load_locale(lang)


def t(key: str, lang: str = "en", **kwargs) -> str:
    _ensure_loaded(lang)
    val = _translations.get(lang, {}).get(key)
    if val is None:
        if lang != "en":
            _ensure_loaded("en")
            val = _translations.get("en", {}).get(key)
        if val is None:
            log_key = f"{lang}:{key}"
            if log_key not in _missing_keys_logged:
                _missing_keys_logged.add(log_key)
                logger.warning(f"MissingTranslation: {key} for lang={lang}")
            return key
    if kwargs:
        try:
            val = val.format(**kwargs)
        except KeyError:
            pass
    return val


def get_user_lang(user_id: int) -> str:
    return _user_lang_cache.get(user_id, "ar")


def set_user_lang(user_id: int, lang: str):
    _user_lang_cache[user_id] = lang


def detect_language_from_code(code: str | None) -> str:
    if not code:
        return "ar"
    code = code.lower()
    if code.startswith("ar"):
        return "ar"
    return "en"


def missing_keys(lang: str) -> set[str]:
    _ensure_loaded(lang)
    return set()


def get_available_languages() -> list[str]:
    return ["ar", "en"]
