import asyncio
import logging
import ssl
from datetime import datetime, timedelta, timezone

from config import Config

logger = logging.getLogger(__name__)

EXPIRY_WARN_DAYS = [14, 7, 1]


async def inspect(host: str, port: int = 443) -> dict:
    from cryptography import x509
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import hashes

    result = {
        "host": host,
        "port": port,
        "valid": False,
        "risks": [],
        "issuer": {},
        "san": [],
        "signature_algorithm": "",
        "key_size": 0,
        "not_before": "",
        "not_after": "",
        "days_remaining": 0,
    }

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = True
        ctx.verify_mode = ssl.CERT_REQUIRED

        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port, ssl=ctx, server_hostname=host),
            timeout=10,
        )

        sock = writer.get_extra_info("ssl_object")
        der_cert = sock.getpeercert(binary_form=True)
        writer.close()

        if not der_cert:
            result["risks"].append("no certificate returned")
            return result

        cert = x509.load_der_x509_certificate(der_cert, default_backend())

        result["valid"] = True

        issuer = cert.issuer
        for attr in issuer:
            if attr.oid._name == "commonName":
                result["issuer"]["CN"] = attr.value
            elif attr.oid._name == "organizationName":
                result["issuer"]["O"] = attr.value
            elif attr.oid._name == "organizationalUnitName":
                result["issuer"]["OU"] = attr.value

        try:
            ext = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName)
            result["san"] = ext.value.get_values_for_type(x509.DNSName)
        except x509.ExtensionNotFound:
            pass

        sig = cert.signature_algorithm_oid
        result["signature_algorithm"] = sig._name if hasattr(sig, "_name") else str(sig)

        pub_key = cert.public_key()
        try:
            result["key_size"] = pub_key.key_size
        except Exception:
            result["key_size"] = 0

        result["not_before"] = cert.not_valid_before_utc.isoformat() if hasattr(cert, "not_valid_before_utc") else cert.not_valid_before.isoformat()
        result["not_after"] = cert.not_valid_after_utc.isoformat() if hasattr(cert, "not_valid_after_utc") else cert.not_valid_after.isoformat()

        now = datetime.now(timezone.utc)
        nb = cert.not_valid_before_utc if hasattr(cert, "not_valid_before_utc") else cert.not_valid_before.replace(tzinfo=timezone.utc)
        na = cert.not_valid_after_utc if hasattr(cert, "not_valid_after_utc") else cert.not_valid_after.replace(tzinfo=timezone.utc)

        if now < nb:
            result["risks"].append("certificate not yet valid")
        if now > na:
            result["risks"].append("certificate expired")
        else:
            remaining = (na - now).days
            result["days_remaining"] = remaining
            if remaining < 30:
                result["risks"].append(f"expires in {remaining} days")

        if result["signature_algorithm"] and "SHA1" in result["signature_algorithm"].upper():
            result["risks"].append("SHA-1 signature algorithm")

        if result["key_size"] and result["key_size"] < 2048:
            result["risks"].append(f"RSA key size {result['key_size']} < 2048")

        subject = cert.subject
        subject_cn = ""
        for attr in subject:
            if attr.oid._name == "commonName":
                subject_cn = attr.value
                break

        if subject_cn == host:
            result["risks"].append("self-signed certificate (subject CN matches hostname without trusted chain verification — edge case)")

    except asyncio.TimeoutError:
        result["risks"].append("connection timeout")
    except Exception as e:
        result["risks"].append(str(e))

    return result


async def _send_expiry_reminder(host: str, days_left: int):
    import httpx
    from logging_setup import log_audit
    log_audit("ssl_expiry_warning", extra={
        "host": host,
        "days_left": days_left,
    })

    if Config.ALERT_SLACK_WEBHOOK:
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                await client.post(
                    Config.ALERT_SLACK_WEBHOOK,
                    json={"text": f"⚠️ SSL certificate for {host} expires in {days_left} day{'s' if days_left != 1 else ''}."},
                )
        except Exception as e:
            logger.warning("Slack alert failed for %s: %s", host, e)

    if Config.ALERT_DISCORD_WEBHOOK:
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                await client.post(
                    Config.ALERT_DISCORD_WEBHOOK,
                    json={"content": f"⚠️ SSL certificate for {host} expires in {days_left} day{'s' if days_left != 1 else ''}."},
                )
        except Exception as e:
            logger.warning("Discord alert failed for %s: %s", host, e)


async def expiry_monitor():
    domains = [d.strip() for d in Config.MONITORED_DOMAINS.split(",") if d.strip()]
    if not domains:
        logger.info("No MONITORED_DOMAINS configured, expiry monitor idle")
        return

    checked = {}

    while True:
        for domain in domains:
            try:
                info = await inspect(domain)
                days = info.get("days_remaining", 0)
                last = checked.get(domain)

                if days in EXPIRY_WARN_DAYS and last != days:
                    await _send_expiry_reminder(domain, days)
                    checked[domain] = days

                if days == 0 and last != 0:
                    await _send_expiry_reminder(domain, 0)
                    checked[domain] = 0

            except Exception as e:
                logger.error("Expiry check failed for %s: %s", domain, e)

        await asyncio.sleep(86400)
