# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import logging
import os
import time

from config import Config

logger = logging.getLogger(__name__)


class HealthCheck:
    def __init__(self):
        self._start_time = time.time()
        self._redis_status = "unknown"
        self._db_status = "unknown"
        self._queue_depth = 0
        self._ram_mb = 0
        self._ping_task: asyncio.Task | None = None
        self._running = False
        self._down_since: dict[str, float] = {}

    async def _ping_redis(self) -> bool:
        if not Config.REDIS_URL:
            self._redis_status = "unknown"
            return True
        try:
            import redis.asyncio as aioredis
            r = aioredis.from_url(Config.REDIS_URL, socket_connect_timeout=5)
            await r.ping()
            await r.close()
            self._redis_status = "up"
            self._down_since.pop("redis", None)
            return True
        except Exception as e:
            logger.warning("Redis health check failed: %s", e)
            self._redis_status = "down"
            return False

    async def _ping_db(self) -> bool:
        try:
            from database import Database
            await Database.fetchval("SELECT 1")
            self._db_status = "up"
            self._down_since.pop("db", None)
            return True
        except Exception as e:
            logger.warning("DB health check failed: %s", e)
            self._db_status = "down"
            return False

    async def _check_loop(self):
        self._running = True
        interval = getattr(Config, "HEALTH_CHECK_INTERVAL", 30)
        while self._running:
            try:
                await self._ping_redis()
                await self._ping_db()
                self._ram_mb = await self._get_rss_mb()

                if self._redis_status == "down":
                    self._track_down("redis")
                if self._db_status == "down":
                    self._track_down("db")
            except Exception as e:
                logger.error("Health check loop error: %s", e)
            await asyncio.sleep(interval)

    def _track_down(self, component: str):
        now = time.monotonic()
        if component not in self._down_since:
            self._down_since[component] = now
        down_for = now - self._down_since[component]
        if down_for > 60:
            logger.error("Component '%s' down for >60s, firing alert", component)
            self._fire_alert(component)

    def _fire_alert(self, component: str):
        alert_channel = getattr(Config, "ALERT_LOG_CHANNEL", 0)
        if not alert_channel:
            return
        try:
            from main import app
            asyncio.ensure_future(
                app.send_message(
                    alert_channel,
                    f"🚨 Health check: <b>{component}</b> has been DOWN for over 60 seconds!",
                )
            )
        except Exception as e:
            logger.error("Health alert error: %s", e)

    async def _get_rss_mb(self) -> int:
        try:
            import psutil
            proc = psutil.Process(os.getpid())
            return int(proc.memory_info().rss / (1024 * 1024))
        except ImportError:
            return 0

    def get_uptime_s(self) -> int:
        return int(time.time() - self._start_time)

    async def get_status(self) -> dict:
        return {
            "status": "ok",
            "redis": self._redis_status,
            "db": self._db_status,
            "queue_depth": self._queue_depth,
            "ram_mb": self._ram_mb,
            "uptime_s": self.get_uptime_s(),
        }

    def start(self):
        if self._ping_task is None or self._ping_task.done():
            self._ping_task = asyncio.create_task(self._check_loop())

    async def stop(self):
        self._running = False
        if self._ping_task:
            self._ping_task.cancel()
            try:
                await self._ping_task
            except asyncio.CancelledError:
                pass
            self._ping_task = None


health = HealthCheck()


async def json_health_response():
    return await health.get_status()
