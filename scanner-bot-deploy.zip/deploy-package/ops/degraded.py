# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import logging
import time

from config import Config

logger = logging.getLogger(__name__)


class DegradationManager:
    def __init__(self):
        self._status: dict[str, bool] = {}
        self._down_since: dict[str, float] = {}
        self._previous_status: dict[str, bool] = {}

    def mark_down(self, subsystem: str):
        now = time.monotonic()
        was_up = self._status.get(subsystem, True)
        self._status[subsystem] = False
        if subsystem not in self._down_since:
            self._down_since[subsystem] = now

        if was_up:
            self._previous_status[subsystem] = True
            logger.warning("Subsystem '%s' marked DOWN", subsystem)
            self._alert(f"⚠️ Subsystem <b>{subsystem}</b> is DOWN.")

        degraded_delay = getattr(Config, "DEGRADED_AUTO_RECOVER", True)
        if isinstance(degraded_delay, (int, float)):
            degraded_delay = degraded_delay
        else:
            degraded_delay = 60

        if now - self._down_since.get(subsystem, now) > degraded_delay:
            if self._previous_status.get(subsystem, True) is not False:
                self._previous_status[subsystem] = False
                logger.warning("Subsystem '%s' entering DEGRADED mode", subsystem)
                self._alert(f"⚠️ <b>{subsystem}</b> degraded for >{degraded_delay}s.")

    def mark_up(self, subsystem: str):
        was_down = not self._status.get(subsystem, True)
        self._status[subsystem] = True
        self._down_since.pop(subsystem, None)

        if was_down:
            self._previous_status[subsystem] = True
            logger.info("Subsystem '%s' marked UP", subsystem)
            self._alert(f"✅ Subsystem <b>{subsystem}</b> is back UP.")

    def is_degraded(self, subsystem: str) -> bool:
        if not getattr(Config, "DEGRADED_AUTO_RECOVER", True):
            return not self._status.get(subsystem, True)

        if not self._status.get(subsystem, True):
            down_for = time.monotonic() - self._down_since.get(subsystem, time.monotonic())
            degraded_delay = getattr(Config, "DEGRADED_AUTO_RECOVER", 60)
            if isinstance(degraded_delay, bool):
                degraded_delay = 60
            return down_for > degraded_delay
        return False

    def get_status(self) -> dict[str, str]:
        result = {}
        for subsystem, up in self._status.items():
            result[subsystem] = "up" if up else "down"
        return result

    def _alert(self, message: str):
        alert_channel = getattr(Config, "ALERT_LOG_CHANNEL", 0)
        if not alert_channel:
            return
        try:
            from main import app
            import asyncio
            asyncio.ensure_future(app.send_message(alert_channel, message))
        except Exception as e:
            logger.error("Degradation alert error: %s", e)


degradation = DegradationManager()
