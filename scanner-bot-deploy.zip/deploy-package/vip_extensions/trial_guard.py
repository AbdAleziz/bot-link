import hashlib
import logging
from datetime import datetime, timedelta

from pyrogram import Client, filters
from pyrogram.types import Message

from config import Config
from database import Database
from rbac import RBAC

logger = logging.getLogger(__name__)

VIP_TRIAL_DAYS = getattr(Config, "VIP_TRIAL_DAYS", 3)


async def register_trial_guard(app: Client, db: Database):

    @app.on_message(filters.command("trial") & filters.private)
    async def trial_cmd(client: Client, message: Message):
        uid = message.from_user.id
        ip = _detect_ip(message)
        ua = _detect_ua(message)
        ua_hash_val = hashlib.sha256((ua or "").encode()).hexdigest()[:16] if ua else ""
        ip_first = ".".join((ip or "").split(".")[:2]) if ip else ""

        existing_user = await db.fetchrow(
            "SELECT used_at FROM trial_attempts WHERE user_id = ?", (uid,)
        )
        if existing_user:
            await message.reply(
                f"❌ لقد استخدمت النسخة التجريبية مسبقاً.\n"
                f"🕐 تاريخ الاستخدام: {existing_user['used_at'][:19]}"
            )
            return

        existing_ip = await db.fetchrow(
            "SELECT used_at FROM trial_attempts WHERE ip_first_octets = ? OR ua_hash = ?",
            (ip_first, ua_hash_val),
        ) if ip_first or ua_hash_val else None

        if existing_ip:
            await message.reply(
                "❌ تم استخدام النسخة التجريبية من هذا الجهاز/العنوان مسبقاً."
            )
            return

        vip_check = await db.fetchrow(
            "SELECT expires_at FROM vip_users WHERE user_id = ?", (uid,)
        )
        if vip_check:
            try:
                expires = datetime.fromisoformat(vip_check["expires_at"])
                if expires > datetime.utcnow():
                    await message.reply("⭐ أنت بالفعل مشترك VIP!")
                    return
            except Exception:
                pass

        expires_at = (datetime.utcnow() + timedelta(days=VIP_TRIAL_DAYS)).isoformat()
        await db.execute(
            "INSERT OR REPLACE INTO vip_users (user_id, expires_at, plan) VALUES (?, ?, ?)",
            (uid, expires_at, "trial"),
        )
        await db.execute(
            "INSERT INTO trial_attempts (user_id, ip, ip_first_octets, ua_hash, used_at) VALUES (?, ?, ?, ?, ?)",
            (uid, ip or "", ip_first, ua_hash_val, datetime.utcnow().isoformat()),
        )
        logger.info(f"Trial VIP granted to {uid} for {VIP_TRIAL_DAYS} days")
        await message.reply(
            f"🎉 <b>تم تفعيل النسخة التجريبية!</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"⭐ مدة الاشتراك: {VIP_TRIAL_DAYS} أيام\n"
            f"📅 ينتهي: {expires_at[:19]}\n"
            f"━━━━━━━━━━━━━━\n"
            f"استمتع بالميزات الحصرية!"
        )

    @app.on_message(filters.command("trial_reset") & filters.private)
    async def trial_reset_cmd(client: Client, message: Message):
        uid = message.from_user.id
        if not RBAC.is_owner(uid):
            await message.reply("❌ هذا الأمر خاص بالمالك فقط.")
            return

        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            await message.reply("❌ استخدام: /trial_reset <user_id>")
            return

        try:
            target_id = int(parts[1].strip())
        except ValueError:
            await message.reply("❌ معرّف مستخدم غير صالح.")
            return

        await db.execute("DELETE FROM trial_attempts WHERE user_id = ?", (target_id,))
        await message.reply(f"✅ تم إعادة تعيين النسخة التجريبية للمستخدم <code>{target_id}</code>.")
        logger.info(f"Trial reset for user {target_id} by admin {uid}")


def _detect_ip(message: Message) -> str:
    try:
        if message.from_user and message.from_user.dc_id:
            return f"dc{message.from_user.dc_id}"
        if message.from_user and message.from_user.language_code:
            return f"lang_{message.from_user.language_code}"
    except Exception:
        pass
    return ""


def _detect_ua(message: Message) -> str:
    try:
        if message.from_user and message.from_user.language_code:
            return message.from_user.language_code or ""
    except Exception:
        pass
    return ""
