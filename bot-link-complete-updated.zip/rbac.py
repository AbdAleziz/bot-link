# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import logging
from enum import IntEnum
from typing import List

from config import Config

logger = logging.getLogger("rbac")


class Role(IntEnum):
    BANNED = -1
    USER = 0
    SUB_DEV = 10
    OWNER = 100


class RBAC:
    @staticmethod
    def get_role(user_id: int) -> Role:
        if user_id in Config.SUDO_USERS:
            return Role.OWNER
        if user_id in Config.SUB_DEVS:
            return Role.SUB_DEV
        return Role.USER

    @staticmethod
    def has_permission(user_id: int, required_role: Role) -> bool:
        return RBAC.get_role(user_id) >= required_role

    @staticmethod
    def is_owner(user_id: int) -> bool:
        return user_id in Config.SUDO_USERS

    @staticmethod
    def is_sub_dev(user_id: int) -> bool:
        return user_id in Config.SUB_DEVS

    @staticmethod
    def is_admin(user_id: int) -> bool:
        return RBAC.is_owner(user_id) or RBAC.is_sub_dev(user_id)

    @staticmethod
    def get_all_admins() -> List[int]:
        return list(set(Config.SUDO_USERS + Config.SUB_DEVS))

    @staticmethod
    def owner_only(func):
        async def wrapper(client, message, *args, **kwargs):
            uid = message.from_user.id
            if not RBAC.is_owner(uid):
                await message.reply("❌ هذا الأمر خاص بالمالك فقط.")
                return
            return await func(client, message, *args, **kwargs)

        return wrapper

    @staticmethod
    def admin_only(func):
        async def wrapper(client, message, *args, **kwargs):
            uid = message.from_user.id
            if not RBAC.is_admin(uid):
                await message.reply("❌ هذا الأمر خاص بالمشرفين فقط.")
                return
            return await func(client, message, *args, **kwargs)

        return wrapper
