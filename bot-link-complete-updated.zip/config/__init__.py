# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import os
from typing import List


class Config:
    BOT_TOKEN = os.getenv("BOT_TOKEN", "")
    API_ID = int(os.getenv("API_ID", "0"))
    API_HASH = os.getenv("API_HASH", "")

    STAGING_BOT_TOKEN = os.getenv("STAGING_BOT_TOKEN", "")
    STAGING_ENABLED = os.getenv("STAGING_ENABLED", "false").lower() == "true"

    PRIMARY_ADMIN_ID = int(os.getenv("PRIMARY_ADMIN_ID", "0"))

    SUDO_USERS: List[int] = [
        int(x) for x in os.getenv("SUDO_USERS", "").split(",") if x
    ]
    if PRIMARY_ADMIN_ID and PRIMARY_ADMIN_ID not in SUDO_USERS:
        SUDO_USERS.append(PRIMARY_ADMIN_ID)

    SUB_DEVS: List[int] = [
        int(x) for x in os.getenv("SUB_DEVS", "").split(",") if x
    ]

    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///data/bot.db")
    REDIS_URL = os.getenv("REDIS_URL", "")
    USE_POSTGRES = os.getenv("USE_POSTGRES", "false").lower() == "true"
    DB_POOL_SIZE = int(os.getenv("DB_POOL_SIZE", "5"))

    VIRUSTOTAL_API_KEY = os.getenv("VIRUSTOTAL_API_KEY", "")
    URLSCAN_API_KEY = os.getenv("URLSCAN_API_KEY", "")
    SCAN_TIMEOUT = int(os.getenv("SCAN_TIMEOUT", "7"))
    MAX_REDIRECTS = int(os.getenv("MAX_REDIRECTS", "5"))

    VIP_PRICE_CENTS = int(os.getenv("VIP_PRICE_CENTS", "500"))
    VIP_CURRENCY = os.getenv("VIP_CURRENCY", "USD")
    VIP_DURATION_DAYS = int(os.getenv("VIP_DURATION_DAYS", "30"))
    VIP_SCAN_LIMIT = int(os.getenv("VIP_SCAN_LIMIT", "999999"))
    FREE_DAILY_LIMIT = int(os.getenv("FREE_DAILY_LIMIT", "5"))
    PROVIDER_TOKEN = os.getenv("PROVIDER_TOKEN", "")

    STAR_PRICE_WEEK = int(os.getenv("STAR_PRICE_WEEK", "100"))
    STAR_PRICE_MONTH = int(os.getenv("STAR_PRICE_MONTH", "300"))
    STAR_PRICE_LIFETIME = int(os.getenv("STAR_PRICE_LIFETIME", "1000"))
    CURRENCY = os.getenv("CURRENCY", "XTR")

    MAX_MESSAGES = int(os.getenv("MAX_MESSAGES", "5"))
    TIME_WINDOW = int(os.getenv("TIME_WINDOW", "3"))
    BAN_DURATION = int(os.getenv("BAN_DURATION", "300"))
    QUARANTINE_CHANNEL = int(os.getenv("QUARANTINE_CHANNEL", "0"))
    MIN_ACCOUNT_AGE = int(os.getenv("MIN_ACCOUNT_AGE", "259200"))

    RATE_LIMIT_MESSAGES = int(os.getenv("RATE_LIMIT_MESSAGES", "10"))
    RATE_LIMIT_WINDOW = int(os.getenv("RATE_LIMIT_WINDOW", "60"))
    RATE_LIMIT_BAN_DURATION = int(os.getenv("RATE_LIMIT_BAN_DURATION", "3600"))

    QUEUE_MAX_SIZE = int(os.getenv("QUEUE_MAX_SIZE", "1000"))
    QUEUE_WORKERS = int(os.getenv("QUEUE_WORKERS", "2"))

    WEB_HOST = os.getenv("WEB_HOST", "0.0.0.0")
    WEB_PORT = int(os.getenv("WEB_PORT", "8080"))
    WEB_URL = os.getenv("WEB_URL", "http://localhost:8080")
    WEB_SECRET = os.getenv("WEB_SECRET", "changeme")
    ENABLE_DASHBOARD = os.getenv("ENABLE_DASHBOARD", "true").lower() == "true"
    DASHBOARD_USER = os.getenv("DASHBOARD_USER", "admin")
    DASHBOARD_PASS = os.getenv("DASHBOARD_PASS", "admin123")

    WEBHOOK_MODE = os.getenv("WEBHOOK_MODE", "false").lower() == "true"
    WEBHOOK_URL = os.getenv("WEBHOOK_URL", "")
    WEBHOOK_PATH = os.getenv("WEBHOOK_PATH", "/webhook")
    WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "")

    SHORT_URL_LENGTH = int(os.getenv("SHORT_URL_LENGTH", "6"))
    SHORT_URL_ALPHABET = os.getenv(
        "SHORT_URL_ALPHABET",
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
    )

    ENABLE_MCP = os.getenv("ENABLE_MCP", "false").lower() == "true"
    MCP_PORT = int(os.getenv("MCP_PORT", "9090"))

    ENABLE_THREAT_API = os.getenv("ENABLE_THREAT_API", "true").lower() == "true"
    THREAT_API_KEY = os.getenv("THREAT_API_KEY", "")

    CACHE_TTL = int(os.getenv("CACHE_TTL", "300"))
    SCAN_CACHE_TTL = int(os.getenv("SCAN_CACHE_TTL", "3600"))

    MAX_BATCH_SIZE = int(os.getenv("MAX_BATCH_SIZE", "100"))
    ALLOWED_EXTENSIONS = {"txt", "csv"}
    HEALTH_CHECK_INTERVAL = int(os.getenv("HEALTH_CHECK_INTERVAL", "30"))

    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE = os.getenv("LOG_FILE", "data/bot.log")
    LOG_JSON = os.getenv("LOG_JSON", "false").lower() == "true"
    ALERT_LOG_CHANNEL = int(os.getenv("ALERT_LOG_CHANNEL", "0"))

    QR_DEFAULT_FG_COLOR = os.getenv("QR_DEFAULT_FG_COLOR", "#000000")
    QR_DEFAULT_BG_COLOR = os.getenv("QR_DEFAULT_BG_COLOR", "#FFFFFF")
    QR_DEFAULT_SIZE = int(os.getenv("QR_DEFAULT_SIZE", "10"))
    QR_LOGO_PATH = os.getenv("QR_LOGO_PATH", "static/qr_logo.png")

    # Copyright
    BOT_OWNER = os.getenv("BOT_OWNER", "@AbdAleziz_1")
    BOT_OWNER_NAME = os.getenv("BOT_OWNER_NAME", "AbdAleziz")
    BOT_VERSION = os.getenv("BOT_VERSION", "3.0.0")

    # Multi-cloud backup
    BACKUP_CLOUD_S3_ENABLED = os.getenv("BACKUP_CLOUD_S3_ENABLED", "false").lower() == "true"
    BACKUP_CLOUD_S3_BUCKET = os.getenv("BACKUP_CLOUD_S3_BUCKET", "")
    BACKUP_CLOUD_S3_REGION = os.getenv("BACKUP_CLOUD_S3_REGION", "us-east-1")
    BACKUP_CLOUD_S3_KEY = os.getenv("BACKUP_CLOUD_S3_KEY", "")
    BACKUP_CLOUD_S3_SECRET = os.getenv("BACKUP_CLOUD_S3_SECRET", "")
    BACKUP_CLOUD_B2_ENABLED = os.getenv("BACKUP_CLOUD_B2_ENABLED", "false").lower() == "true"
    BACKUP_CLOUD_B2_BUCKET = os.getenv("BACKUP_CLOUD_B2_BUCKET", "")
    BACKUP_CLOUD_B2_KEY = os.getenv("BACKUP_CLOUD_B2_KEY", "")
    BACKUP_CLOUD_B2_SECRET = os.getenv("BACKUP_CLOUD_B2_SECRET", "")
    BACKUP_ENCRYPT = os.getenv("BACKUP_ENCRYPT", "true").lower() == "true"
    BACKUP_ENCRYPTION_KEY = os.getenv("BACKUP_ENCRYPTION_KEY", "")
    BACKUP_KEY_ROTATION_DAYS = int(os.getenv("BACKUP_KEY_ROTATION_DAYS", "30"))

    # Audit
    AUDIT_LOG_ENABLED = os.getenv("AUDIT_LOG_ENABLED", "true").lower() == "true"

    # Alerts
    ALERT_EMAIL_ENABLED = os.getenv("ALERT_EMAIL_ENABLED", "false").lower() == "true"
    ALERT_EMAIL_SMTP = os.getenv("ALERT_EMAIL_SMTP", "")
    ALERT_EMAIL_PORT = int(os.getenv("ALERT_EMAIL_PORT", "587"))
    ALERT_EMAIL_USER = os.getenv("ALERT_EMAIL_USER", "")
    ALERT_EMAIL_PASS = os.getenv("ALERT_EMAIL_PASS", "")
    ALERT_EMAIL_TO = os.getenv("ALERT_EMAIL_TO", "")
    ALERT_SLACK_WEBHOOK = os.getenv("ALERT_SLACK_WEBHOOK", "")
    ALERT_DISCORD_WEBHOOK = os.getenv("ALERT_DISCORD_WEBHOOK", "")

    # Performance monitor
    PERF_MONITOR_INTERVAL = int(os.getenv("PERF_MONITOR_INTERVAL", "60"))

    BACKUP_DIR = os.getenv("BACKUP_DIR", "backups")
    BACKUP_KEEP_LAST = int(os.getenv("BACKUP_KEEP_LAST", "7"))
    BACKUP_AUTO_ENABLED = os.getenv("BACKUP_AUTO_ENABLED", "true").lower() == "true"
    BACKUP_AUTO_HOUR = int(os.getenv("BACKUP_AUTO_HOUR", "3"))
    BACKUP_AUTO_SEND_TO = int(os.getenv("BACKUP_AUTO_SEND_TO", "0"))
    BACKUP_RESTART_CMD = os.getenv("BACKUP_RESTART_CMD", "python main.py")
