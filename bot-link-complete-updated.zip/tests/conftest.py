# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import os
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

os.environ["BACKUP_DIR"] = "test_backups"
os.environ["BACKUP_KEEP_LAST"] = "3"
os.environ["BACKUP_ENCRYPT"] = "false"
os.environ["BACKUP_AUTO_ENABLED"] = "false"
os.environ["DATABASE_URL"] = "sqlite+aiosqlite:///data/test_bot.db"
os.environ["BOT_TOKEN"] = "test:token"
os.environ["API_ID"] = "12345"
os.environ["API_HASH"] = "test_hash"
os.environ["PRIMARY_ADMIN_ID"] = "999999999"
os.environ["SUDO_USERS"] = "999999999"
os.environ["LOG_LEVEL"] = "ERROR"

from config import Config


@pytest.fixture
def sample_files(tmp_path):
    files = {}
    for name, content in [
        ("file1.txt", b"hello world"),
        ("file2.txt", b"backup test data"),
        ("sub/file3.txt", b"nested data"),
    ]:
        p = tmp_path / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(content)
        files[name] = p
    return files, tmp_path


@pytest.fixture
def backup_mgr():
    from backup_system import BackupManager
    mgr = BackupManager()
    mgr.backup_dir = Path("test_backups")
    mgr.backup_dir.mkdir(parents=True, exist_ok=True)
    return mgr


@pytest.fixture(autouse=True)
def cleanup_backups():
    yield
    import shutil
    for p in Path("test_backups").glob("*"):
        if p.is_file():
            p.unlink()
