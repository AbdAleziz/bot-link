# scanner_bot - Telegram URL Scanner & QR Generator
# Copyright (c) 2026 AbdAleziz | @AbdAleziz_1

import asyncio
import os
import tarfile
from pathlib import Path

import pytest

os.environ.setdefault("BACKUP_DIR", "test_backups")
os.environ.setdefault("BACKUP_KEEP_LAST", "3")
os.environ.setdefault("BACKUP_ENCRYPT", "false")
os.environ.setdefault("BACKUP_AUTO_ENABLED", "false")


@pytest.mark.asyncio
async def test_create_backup(backup_mgr):
    path = await backup_mgr.create_backup(label="test")
    assert path.exists()
    assert path.name.startswith("backup_")
    assert path.name.endswith(".tar.gz")
    assert "test" in path.name
    assert tarfile.is_tarfile(str(path))
    path.unlink()


@pytest.mark.asyncio
async def test_list_backups(backup_mgr):
    backups = backup_mgr.list_backups()
    assert isinstance(backups, list)
    await backup_mgr.create_backup(label="list_test")
    backups = backup_mgr.list_backups()
    assert len(backups) >= 1
    assert backups[0]["label"] == "list_test"
    assert "filename" in backups[0]
    assert "size_bytes" in backups[0]


@pytest.mark.asyncio
async def test_delete_backup(backup_mgr):
    path = await backup_mgr.create_backup(label="delete_test")
    assert path.exists()
    result = backup_mgr.delete_backup(path.name)
    assert result is True
    assert not path.exists()


@pytest.mark.asyncio
async def test_delete_backup_path_traversal(backup_mgr):
    result = backup_mgr.delete_backup("../../etc/passwd")
    assert result is False


@pytest.mark.asyncio
async def test_cleanup_old_backups(backup_mgr):
    for i in range(5):
        p = backup_mgr.backup_dir / f"backup_20260705_{i:06d}_test.tar.gz"
        p.touch()
    backup_mgr.keep_last = 3
    await backup_mgr._cleanup_old()
    remaining = list(backup_mgr.backup_dir.glob("backup_*.tar.gz"))
    assert len(remaining) <= 3


@pytest.mark.asyncio
async def test_next_run_time(backup_mgr):
    from datetime import datetime, timedelta
    backup_mgr.auto_hour = 3
    nrt = backup_mgr._next_run_time()
    assert nrt.minute == 0
    assert nrt.second == 0
    now = datetime.utcnow()
    diff = (nrt - now).total_seconds()
    assert diff > 0
    if now.hour < 3:
        assert nrt.hour == 3
        assert nrt.day == now.day
    else:
        assert nrt.day == now.day + 1 or (nrt.day == 1 and now.month != nrt.month)


@pytest.mark.asyncio
async def test_verify_backup_valid(backup_mgr):
    path = await backup_mgr.create_backup(label="verify_test")
    result = await backup_mgr.verify_backup(path)
    assert result["valid"] is True
    assert result["sha256"]
    assert result["file_count"] >= 0


@pytest.mark.asyncio
async def test_verify_backup_not_found(backup_mgr):
    result = await backup_mgr.verify_backup(Path("nonexistent.tar.gz"))
    assert result["valid"] is False
    assert "File not found" in result["errors"]


@pytest.mark.asyncio
async def test_backup_diff(backup_mgr):
    path_a = await backup_mgr.create_backup(label="diff_a")
    path_b = await backup_mgr.create_backup(label="diff_b")
    diff = await backup_mgr.backup_diff(path_a.name, path_b.name)
    assert "same" in diff
    assert "only_in_a" in diff
    assert "only_in_b" in diff
    assert "different" in diff
