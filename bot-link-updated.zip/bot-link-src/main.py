import asyncio
import logging
import os
import sys
from datetime import datetime

_PORT = os.getenv("PORT")
if _PORT:
    os.environ["WEB_PORT"] = _PORT
    os.environ["MCP_PORT"] = str(int(_PORT) + 1)

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQuery,
    InlineQueryResultArticle,
    InputTextMessageContent,
    LabeledPrice,
    Message,
)

from admin_panel import AdminPanel
from config import Config
from database import Database
from logging_setup import LoggerSetup
from qr_system import QRSystem
from queue_system import task_queue, QueueTask, TaskPriority
from rate_limiter import rate_limiter
from rbac import RBAC, Role
from scanner import Scanner
from vip_system import VipSystem
from web_dashboard import WebDashboard
from click_tracker import ClickTracker
from mcp_server import MCPServer
from config.payment_config import ENABLE_STARS_PAYMENT
from services.payment_flow import PaymentFlow, build_duration_keyboard

LoggerSetup.setup(json_format=Config.LOG_JSON)
logger = LoggerSetup.get_logger("main")

app = Client(
    "scanner_bot",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN,
    workers=16,
)

db = Database()
scanner = Scanner(db)
qr_system = QRSystem(db)
vip_system = VipSystem(db)
click_tracker = ClickTracker(db)
admin_panel = AdminPanel(db)
dashboard = None
mcp = None

QR_WIZARD = {}
VCARD_WIZARD = {}

STAGING_APP: Client | None = None

def main_menu_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔍 Scan Link", callback_data="nav_scan")],
        [InlineKeyboardButton("📱 QR Tools", callback_data="nav_qrmenu")],
        [InlineKeyboardButton("👤 My Account", callback_data="nav_account")],
        [InlineKeyboardButton("⭐ Upgrade to VIP", callback_data="nav_vip")],
        [InlineKeyboardButton("🛠️ Support", callback_data="nav_support")],
    ])

def back_home_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
    ])

def qr_menu_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔗 URL → QR Code", callback_data="qr_url")],
        [InlineKeyboardButton("🖼️ Decode QR Image", callback_data="qr_decode")],
        [InlineKeyboardButton("📇 vCard → QR", callback_data="qr_vcard")],
        [InlineKeyboardButton("📊 QR Analytics", callback_data="qr_analytics")],
        [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
    ])

def qr_color_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⚫ Black", callback_data="qrcolor_000000"),
         InlineKeyboardButton("🔴 Red", callback_data="qrcolor_FF0000")],
        [InlineKeyboardButton("🔵 Blue", callback_data="qrcolor_0000FF"),
         InlineKeyboardButton("🟢 Green", callback_data="qrcolor_00FF00")],
        [InlineKeyboardButton("🟣 Purple", callback_data="qrcolor_800080"),
         InlineKeyboardButton("🟠 Orange", callback_data="qrcolor_FFA500")],
        [InlineKeyboardButton("Custom Color", callback_data="qrcolor_custom")],
        [InlineKeyboardButton("⬅️ Back", callback_data="nav_qrmenu")],
    ])

def qr_logo_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Yes, add logo", callback_data="qrlogo_yes")],
        [InlineKeyboardButton("❌ No logo", callback_data="qrlogo_no")],
        [InlineKeyboardButton("⬅️ Back", callback_data="nav_qrmenu")],
    ])

def scan_again_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔍 Scan Another", callback_data="nav_scan"),
         InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
    ])

def vip_pay_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💳 Pay via Google Pay", callback_data="vip_pay")],
        [InlineKeyboardButton("🔙 Back", callback_data="nav_home")],
    ])

def upgrade_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⭐ Upgrade to VIP", callback_data="nav_vip")],
        [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
    ])

async def is_admin(uid: int) -> bool:
    return RBAC.is_admin(uid)

async def daily_scan_count(uid: int) -> int:
    today = datetime.utcnow().date().isoformat()
    row = await db.fetchval(
        "SELECT COUNT(*) FROM scan_history WHERE user_id = ? AND date(scanned_at) = ?",
        (uid, today),
    )
    return row or 0

async def is_vip(uid: int) -> bool:
    return await vip_system.is_vip(uid)

def format_scan_result(result: dict) -> str:
    emoji = "✅" if not result.get("is_threat") else "🚫"
    status_text = "✅ Safe" if not result.get("is_threat") else f"🚫 Threat ({result.get('threat_type', 'Unknown')})"
    text = (
        f"{emoji} <b>Scan Result</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"🔗 URL: <code>{result.get('url', '')[:100]}</code>\n"
        f"🌐 Domain: {result.get('domain', '')}\n"
        f"📊 Status: {status_text}\n"
        f"⭐ Trust: {result.get('trust_score', 0):.1f}%\n"
    )
    checks = result.get("checks", {})
    vt = checks.get("virustotal", {})
    if isinstance(vt, dict) and vt.get("positives") is not None:
        text += f"🦠 VirusTotal: {vt.get('positives', 0)} positives\n"
    ssl_check = checks.get("ssl", {})
    if isinstance(ssl_check, dict):
        ssl_status = "✅ Valid" if ssl_check.get("valid") else "❌ Invalid"
        text += f"🔐 SSL: {ssl_status}\n"
    whois = checks.get("whois", {})
    if isinstance(whois, dict) and whois.get("registrar"):
        text += f"📅 WHOIS: {whois.get('registrar', '')[:50]}\n"
        if whois.get("age_days"):
            text += f"📆 Domain age: {whois['age_days']} days\n"
    text += f"\n🕐 {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC"
    return text

@app.on_message(filters.command("start"))
async def start_cmd(client: Client, message: Message):
    user = message.from_user
    await db.execute(
        "INSERT OR IGNORE INTO users (user_id, username, first_name, last_name, joined_at) VALUES (?, ?, ?, ?, ?)",
        (user.id, user.username or "", user.first_name or "", user.last_name or "",
         datetime.utcnow().isoformat()),
    )
    banned = await db.fetchrow("SELECT * FROM banned_users WHERE user_id = ?", (user.id,))
    if banned:
        await message.reply("🚫 You are banned from using this bot.")
        return

    args = message.text.split(maxsplit=1)
    if len(args) > 1:
        arg = args[1].strip()
        try:
            qr_code = arg
            link = await click_tracker.resolve_short_url(qr_code)
            if link:
                result = await scanner.scan_url(link, user.id)
                await message.reply(format_scan_result(result), reply_markup=scan_again_kb())
                return
        except Exception:
            pass

    await message.reply(
        "🤖 <b>Welcome to QR & Link Scanner Bot</b>\n\n"
        "Choose from the menu below:",
        reply_markup=main_menu_kb(),
    )

@app.on_callback_query(filters.regex(r"^nav_"))
async def nav_callback(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    action = cb.data[4:]

    if action in ("home", "back_main"):
        await cb.message.edit(
            "🤖 <b>Welcome to QR & Link Scanner Bot</b>\n\n"
            "Choose from the menu below:",
            reply_markup=main_menu_kb(),
        )

    elif action == "scan":
        await cb.message.edit(
            "🔗 <b>Scan a Link</b>\n\n"
            "Send me a URL and I will scan it with VirusTotal and other security checks.",
            reply_markup=back_home_kb(),
        )

    elif action == "qrmenu":
        await cb.message.edit(
            "📱 <b>QR Code Tools</b>\n\n"
            "• Generate QR codes from URLs\n"
            "• Decode QR images\n"
            "• Create vCard QR codes\n"
            "• Track QR analytics",
            reply_markup=qr_menu_kb(),
        )

    elif action == "account":
        daily = await daily_scan_count(uid)
        vip = await is_vip(uid)
        if vip:
            row = await db.fetchrow("SELECT expires_at, plan FROM vip_users WHERE user_id = ?", (uid,))
            expires = row["expires_at"][:10] if row else "—"
            plan = row["plan"] if row else "—"
            atype = "⭐ VIP"
            limit_txt = "Unlimited"
        else:
            atype = "👤 Free"
            limit_txt = f"{daily}/{Config.FREE_DAILY_LIMIT}"
            expires = "—"
            plan = "—"
        await cb.message.edit(
            f"👤 <b>My Account</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"🆔 ID: <code>{uid}</code>\n"
            f"📋 Type: {atype}\n"
            f"🔍 Today's scans: {limit_txt}\n"
            f"📅 VIP expires: {expires}\n"
            f"📋 Plan: {plan}\n"
            f"━━━━━━━━━━━━━━",
            reply_markup=back_home_kb(),
        )

    elif action == "vip":
        if ENABLE_STARS_PAYMENT:
            if await is_vip(uid):
                row = await db.fetchrow("SELECT expires_at FROM vip_users WHERE user_id = ?", (uid,))
                await cb.message.edit(
                    f"⭐ <b>You are already VIP!</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"✅ Active until {row['expires_at'][:10]}\n"
                    f"Enjoy exclusive features!",
                    reply_markup=back_home_kb(),
                )
            else:
                price_display = Config.VIP_PRICE_CENTS / 100
                await cb.message.edit(
                    f"⭐ <b>Upgrade to VIP</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"📌 Monthly: {Config.VIP_DURATION_DAYS} days\n"
                    f"💵 Price: {price_display:.2f} {Config.VIP_CURRENCY}\n\n"
                    f"✨ <b>Features:</b>\n"
                    f"• Unlimited link scanning\n"
                    f"• QR code generation\n"
                    f"• Bulk scanning\n"
                    f"• Personal API key\n"
                    f"• Priority support\n\n"
                    f"Click below to pay securely:",
                    reply_markup=vip_pay_kb(),
                )
        else:
            if await is_vip(uid):
                row = await db.fetchrow("SELECT expires_at FROM vip_users WHERE user_id = ?", (uid,))
                await cb.message.edit(
                    f"⭐ <b>You are already VIP!</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"✅ Active until {row['expires_at'][:10]}",
                    reply_markup=back_home_kb(),
                )
            else:
                await cb.message.edit(
                    "⭐ <b>Upgrade to VIP</b>\n"
                    "━━━━━━━━━━━━━━\n"
                    "Choose your subscription plan:",
                    reply_markup=build_duration_keyboard(),
                )

    elif action == "support":
        await cb.message.edit(
            "🛠️ <b>Support & Help</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"For support, contact the developer:\n\n"
            f"👤 <a href=\"tg://user?id={Config.PRIMARY_ADMIN_ID}\">Click here</a>\n\n"
            f"Or send your message and we will get back to you.",
            reply_markup=back_home_kb(),
        )

    await cb.answer()

@app.on_message(filters.text & filters.private & ~filters.command(["start", "help", "r", "myapi", "grantvip", "panel", "stats", "ban", "unban", "broadcast", "export", "import", "logs", "restart", "clearcache", "addadmin", "deladmin", "vip", "bulkscan", "domainwatch", "whitelist"]))
async def handle_text(client: Client, message: Message):
    uid = message.from_user.id

    ok = await rate_limiter.check(uid)
    if not ok:
        ban_remaining = await rate_limiter.get_ban_remaining(uid)
        await message.reply(
            f"⏳ You are rate limited. Try again in {ban_remaining} seconds.",
        )
        return

    banned = await db.fetchrow("SELECT * FROM banned_users WHERE user_id = ?", (uid,))
    if banned:
        await message.reply("🚫 You are banned.")
        return

    text = message.text.strip()

    if uid in QR_WIZARD:
        step = QR_WIZARD[uid]
        if step == "awaiting_url":
            QR_WIZARD[uid] = {"url": text, "step": "awaiting_color"}
            await message.reply(
                "🎨 Choose QR code color:",
                reply_markup=qr_color_kb(),
            )
            return
        elif step == "awaiting_custom_color":
            try:
                if len(text) == 6 or (len(text) == 7 and text.startswith("#")):
                    color = text.lstrip("#")
                    int(color, 16)
                    QR_WIZARD[uid]["color"] = color
                    QR_WIZARD[uid]["step"] = "awaiting_logo"
                    await message.reply(
                        "📎 Add logo to QR code?",
                        reply_markup=qr_logo_kb(),
                    )
                    return
                else:
                    await message.reply("❌ Invalid color. Use hex format (e.g., FF0000 for red).")
                    return
            except ValueError:
                await message.reply("❌ Invalid hex color. Use format like FF0000.")
                return
        else:
            QR_WIZARD.pop(uid, None)

    if uid in VCARD_WIZARD:
        step = VCARD_WIZARD[uid].get("step")
        if step == "awaiting_name":
            VCARD_WIZARD[uid]["name"] = text
            VCARD_WIZARD[uid]["step"] = "awaiting_phone"
            await message.reply("📞 Enter phone number (or /skip):")
            return
        elif step == "awaiting_phone":
            if text != "/skip":
                VCARD_WIZARD[uid]["phone"] = text
            VCARD_WIZARD[uid]["step"] = "awaiting_email"
            await message.reply("📧 Enter email (or /skip):")
            return
        elif step == "awaiting_email":
            if text != "/skip":
                VCARD_WIZARD[uid]["email"] = text
            VCARD_WIZARD[uid]["step"] = "awaiting_org"
            await message.reply("🏢 Enter organization (or /skip):")
            return
        elif step == "awaiting_org":
            if text != "/skip":
                VCARD_WIZARD[uid]["org"] = text
            VCARD_WIZARD[uid]["step"] = "done"
            await message.reply(
                "📇 Add logo to vCard QR?",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("✅ Yes, with logo", callback_data="vcard_logoyes")],
                    [InlineKeyboardButton("❌ No logo", callback_data="vcard_logono")],
                    [InlineKeyboardButton("⬅️ Back", callback_data="nav_qrmenu")],
                ]),
            )
            return
        elif step == "done":
            await message.reply(
                "📇 Use the buttons above to finish creating your vCard QR.",
            )
            return

    if not (text.startswith("http://") or text.startswith("https://") or "." in text):
        await message.reply(
            "❌ That doesn't look like a valid URL.\n"
            "Please send a valid URL or use the menu below:",
            reply_markup=main_menu_kb(),
        )
        return

    if not await is_vip(uid):
        daily = await daily_scan_count(uid)
        if daily >= Config.FREE_DAILY_LIMIT:
            await message.reply(
                f"❌ <b>Daily free limit reached</b>\n\n"
                f"📊 Today: {daily}/{Config.FREE_DAILY_LIMIT}\n\n"
                f"⭐ Upgrade to VIP for unlimited scans:",
                reply_markup=upgrade_kb(),
            )
            return

    sent = await message.reply("🔍 Scanning link...")
    try:
        result = await asyncio.wait_for(
            scanner.scan_url(text, uid, priority=await is_vip(uid)),
            timeout=Config.SCAN_TIMEOUT + 2,
        )
        await sent.edit(format_scan_result(result), reply_markup=scan_again_kb())
    except asyncio.TimeoutError:
        await sent.edit(
            "⏰ Scan timeout. The URL is too slow to respond.",
            reply_markup=scan_again_kb(),
        )
    except Exception as e:
        logger.error(f"Scan error for {text}: {e}")
        await sent.edit(
            f"❌ Scan error: {str(e)[:200]}",
            reply_markup=scan_again_kb(),
        )

@app.on_message(filters.photo & filters.private)
async def handle_photo(client: Client, message: Message):
    uid = message.from_user.id

    banned = await db.fetchrow("SELECT * FROM banned_users WHERE user_id = ?", (uid,))
    if banned:
        await message.reply("🚫 You are banned.")
        return

    sent = await message.reply("🖼️ Decoding QR code...")
    try:
        path = await message.download()
        with open(path, "rb") as f:
            img_bytes = f.read()
        os.remove(path)

        decoded = await qr_system.decode_qr(img_bytes)
        if decoded:
            text = f"✅ <b>QR Code Content:</b>\n<code>{decoded}</code>\n"

            if decoded.startswith("http://") or decoded.startswith("https://"):
                result = await scanner.scan_url(decoded, uid)
                text += f"\n━━━━━━━━━━━━━━\n"
                text += format_scan_result(result)
                await sent.edit(text, reply_markup=scan_again_kb())
            else:
                await sent.edit(text, reply_markup=back_home_kb())

            await qr_system.track_qr_scan(hash(decoded) % 1000000, uid)
        else:
            await sent.edit(
                "❌ Could not decode QR code from this image.",
                reply_markup=back_home_kb(),
            )
    except Exception as e:
        logger.error(f"QR decode error: {e}")
        await sent.edit(
            f"❌ Error decoding QR: {str(e)[:200]}",
            reply_markup=back_home_kb(),
        )

@app.on_inline_query()
async def inline_query(client: Client, query: InlineQuery):
    input_str = query.query.strip()
    if not input_str:
        await query.answer(
            results=[],
            switch_pm_text="Send a URL to generate QR code",
            switch_pm_parameter="start",
        )
        return

    results = []
    if input_str.startswith(("http://", "https://")):
        results.append(
            InlineQueryResultArticle(
                title="Generate QR Code",
                description=f"Create QR for: {input_str[:50]}",
                input_message_content=InputTextMessageContent(
                    f"🔗 <b>QR Code for:</b>\n<code>{input_str}</code>\n\n"
                    f"⏳ Generating..."
                ),
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")]
                ]),
            )
        )

        qr_bytes = await qr_system.generate_qr(input_str)
        if qr_bytes:
            import io
            result = InlineQueryResultArticle(
                title="Generate QR Code",
                description=f"QR for: {input_str[:50]}",
                input_message_content=InputTextMessageContent(
                    f"🔗 <b>QR Code for:</b>\n<code>{input_str}</code>"
                ),
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔍 Scan Link", callback_data=f"scan_{input_str[:100]}")],
                    [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")]
                ]),
            )
            results[0] = result

    await query.answer(results, cache_time=1, is_personal=True)

@app.on_callback_query(filters.regex(r"^qr_"))
async def qr_callbacks(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    action = cb.data[3:]

    if action == "url":
        QR_WIZARD[uid] = {"step": "awaiting_url"}
        await cb.message.edit(
            "🔗 <b>URL → QR Code</b>\n\n"
            "Send me the URL you want to convert to QR code.\n"
            "It will also be shortened automatically.",
            reply_markup=back_home_kb(),
        )

    elif action == "decode":
        await cb.message.edit(
            "🖼️ <b>Decode QR Image</b>\n\n"
            "Send me any QR code image and I will:\n"
            "1. Decode the QR code\n"
            "2. Scan the link via VirusTotal\n"
            "3. Return the result",
            reply_markup=back_home_kb(),
        )

    elif action == "vcard":
        VCARD_WIZARD[uid] = {"step": "awaiting_name"}
        await cb.message.edit(
            "📇 <b>vCard → QR Code</b>\n\n"
            "Let's create a vCard QR code step by step.\n\n"
            "Enter the contact's full name:",
            reply_markup=back_home_kb(),
        )

    elif action == "analytics":
        links = await click_tracker.get_all_links(limit=10)
        if not links:
            await cb.message.edit(
                "📊 <b>QR Analytics</b>\n\n"
                "No QR codes generated yet.\n"
                "Generate a QR code with URL → QR option first.",
                reply_markup=back_home_kb(),
            )
            await cb.answer()
            return

        text = "📊 <b>Recent QR Codes</b>\n━━━━━━━━━━━━━━\n"
        for link in links:
            clicks = link.get("clicks", 0)
            short = link.get("short_code", "")
            url = (link.get("original_url", "") or "")[:40]
            text += f"• <code>{short}</code> — {clicks} clicks\n  {url}\n"

        await cb.message.edit(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")]
            ]),
        )

    await cb.answer()

@app.on_callback_query(filters.regex(r"^qrcolor_"))
async def qr_color_callback(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    color = cb.data[8:]

    if color == "custom":
        QR_WIZARD[uid]["step"] = "awaiting_custom_color"
        await cb.message.edit(
            "🎨 Send your custom hex color (e.g., FF5722):",
            reply_markup=back_home_kb(),
        )
        await cb.answer()
        return

    QR_WIZARD[uid]["color"] = color
    QR_WIZARD[uid]["step"] = "awaiting_logo"
    await cb.message.edit(
        "📎 Add logo to QR code?",
        reply_markup=qr_logo_kb(),
    )
    await cb.answer()

@app.on_callback_query(filters.regex(r"^qrlogo_"))
async def qr_logo_callback(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    action = cb.data[7:]
    wizard = QR_WIZARD.get(uid)
    if not wizard or not isinstance(wizard, dict):
        await cb.answer("❌ Session expired. Start again.")
        return

    add_logo = action == "yes"
    url = wizard.get("url", "")
    color = wizard.get("color", Config.QR_DEFAULT_FG_COLOR)

    if not url:
        await cb.answer("❌ No URL found. Start again.")
        QR_WIZARD.pop(uid, None)
        return

    await cb.message.edit("⏳ Generating QR code...")
    try:
        qr_bytes, short_url = await qr_system.generate_short_url_qr(
            original_url=url,
            created_by=uid,
            fg_color=f"#{color}",
            add_logo=add_logo,
        )

        await cb.message.delete()
        import io
        await client.send_photo(
            uid,
            io.BytesIO(qr_bytes),
            caption=(
                f"✅ <b>QR Code Generated!</b>\n"
                f"━━━━━━━━━━━━━━\n"
                f"🔗 Short URL: <code>{short_url}</code>\n"
                f"🔗 Original: <code>{url[:80]}</code>\n"
                f"━━━━━━━━━━━━━━\n"
                f"Scan the QR code to visit the link."
            ),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📊 Track This QR", callback_data=f"qr_track_{short_url.split('/')[-1]}")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
            ]),
        )
    except Exception as e:
        logger.error(f"QR generation error: {e}")
        await client.send_message(
            uid, f"❌ Error generating QR: {str(e)[:200]}"
        )

    QR_WIZARD.pop(uid, None)
    await cb.answer()

@app.on_callback_query(filters.regex(r"^qr_track_"))
async def qr_track_callback(client: Client, cb: CallbackQuery):
    short_code = cb.data[9:]
    stats = await qr_system.get_qr_stats(short_code)
    if not stats:
        await cb.answer("❌ QR code not found.")
        return

    text = (
        f"📊 <b>QR Analytics</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"🔗 Destination: {stats.get('original_url', '')[:50]}\n"
        f"👁️ Total scans: {stats.get('total_clicks', 0)}\n"
        f"🌐 Unique IPs: {stats.get('unique_ips', 0)}\n"
        f"📅 Created: {stats.get('created_at', '')[:10]}\n"
        f"━━━━━━━━━━━━━━"
    )
    await cb.message.edit(text, reply_markup=back_home_kb())
    await cb.answer()

@app.on_callback_query(filters.regex(r"^vcard_"))
async def vcard_callback(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    action = cb.data[6:]

    if action == "generate":
        wizard = VCARD_WIZARD.get(uid)
        if not wizard:
            await cb.answer("❌ Session expired.")
            return

        await cb.message.edit("⏳ Generating vCard QR code...")
        try:
            qr_bytes = await qr_system.generate_vcard_qr(
                name=wizard.get("name", "Contact"),
                phone=wizard.get("phone", ""),
                email=wizard.get("email", ""),
                org=wizard.get("org", ""),
                add_logo=wizard.get("add_logo", False),
            )

            await cb.message.delete()
            if qr_bytes:
                import io
                vcard_text = (
                    f"📇 <b>vCard QR Code</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"👤 Name: {wizard.get('name', '')}\n"
                )
                if wizard.get("phone"):
                    vcard_text += f"📞 Phone: {wizard['phone']}\n"
                if wizard.get("email"):
                    vcard_text += f"📧 Email: {wizard['email']}\n"
                if wizard.get("org"):
                    vcard_text += f"🏢 Org: {wizard['org']}\n"
                vcard_text += "━━━━━━━━━━━━━━\nScan to save contact!"

                await client.send_photo(
                    uid,
                    io.BytesIO(qr_bytes),
                    caption=vcard_text,
                    reply_markup=back_home_kb(),
                )
            else:
                await client.send_message(
                    uid, "❌ Failed to generate vCard QR."
                )
        except Exception as e:
            logger.error(f"vCard QR error: {e}")
            await client.send_message(uid, f"❌ Error: {str(e)[:200]}")

        VCARD_WIZARD.pop(uid, None)

    elif action == "logoyes":
        if uid in VCARD_WIZARD:
            VCARD_WIZARD[uid]["add_logo"] = True
        await cb.message.edit(
            "📇 Ready to generate vCard QR with logo!",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ Generate vCard QR", callback_data="vcard_generate")],
                [InlineKeyboardButton("⬅️ Back", callback_data="nav_qrmenu")],
            ]),
        )

    elif action == "logono":
        if uid in VCARD_WIZARD:
            VCARD_WIZARD[uid]["add_logo"] = False
        await cb.message.edit(
            "📇 Ready to generate vCard QR!",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ Generate vCard QR", callback_data="vcard_generate")],
                [InlineKeyboardButton("⬅️ Back", callback_data="nav_qrmenu")],
            ]),
        )

    await cb.answer()

@app.on_callback_query(filters.regex(r"^vip_pay$"))
async def vip_pay_cb(client: Client, cb: CallbackQuery):
    uid = cb.from_user.id
    if await is_vip(uid):
        await cb.answer("You are already VIP!", show_alert=True)
        return
    if not Config.PROVIDER_TOKEN:
        await cb.answer("Payment not available. Contact support.", show_alert=True)
        return
    prices = [LabeledPrice(label="VIP Monthly", amount=Config.VIP_PRICE_CENTS)]
    try:
        await client.send_invoice(
            chat_id=uid,
            title="VIP Subscription - Link Scanner",
            description=f"Subscription for {Config.VIP_DURATION_DAYS} days with unlimited features",
            payload=f"vip_{uid}_{int(datetime.utcnow().timestamp())}",
            provider_token=Config.PROVIDER_TOKEN,
            currency=Config.VIP_CURRENCY,
            prices=prices,
            start_parameter="vip_subscription",
        )
    except Exception as e:
        logger.error(f"sendInvoice error: {e}")
        await cb.answer(f"Error: {str(e)[:50]}", show_alert=True)
    await cb.answer()

@app.on_pre_checkout_query()
async def pre_checkout_handler(client: Client, query):
    await query.answer(ok=True)

@app.on_message(filters.successful_payment)
async def payment_success(client: Client, message: Message):
    uid = message.from_user.id
    pay = message.successful_payment
    total = pay.total_amount / 100
    currency = pay.currency
    pid = f"INV-{uid}-{int(datetime.utcnow().timestamp())}"

    await vip_system.grant_vip(uid, "month")

    await message.reply(
        "✅ <b>Payment successful!</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"⭐ VIP activated for {Config.VIP_DURATION_DAYS} days\n"
        f"💰 {total:.2f} {currency}\n"
        f"🆔 {pid}\n"
        f"━━━━━━━━━━━━━━\n"
        f"Enjoy the exclusive features!"
    )

@app.on_message(filters.command("help"))
async def help_cmd(client: Client, message: Message):
    await message.reply(
        "📚 <b>Bot Help</b>\n\n"
        "This bot works entirely through interactive buttons.\n"
        "Send /start to open the main menu.\n\n"
        "You can send a URL directly to scan it.\n"
        "Send a QR image to decode it.\n\n"
        "<b>Commands:</b>\n"
        "/start - Main menu\n"
        "/help - This message\n"
        "/panel - Admin panel (admins only)\n"
        "/r <code> - Resolve a short URL",
        reply_markup=back_home_kb(),
    )

@app.on_message(filters.command("r"))
async def resolve_short(client: Client, message: Message):
    text = message.text.split(maxsplit=1)
    if len(text) < 2:
        await message.reply("❌ Use: /r <short_code>")
        return
    code = text[1].strip()
    original = await click_tracker.resolve_short_url(code)
    if original:
        await message.reply(f"🔗 Original URL: {original}")
    else:
        await message.reply("❌ URL not found or expired")

@app.on_message(filters.command("myapi") & filters.private)
async def myapi_cmd(client: Client, message: Message):
    uid = message.from_user.id
    if not await is_vip(uid):
        await message.reply("❌ VIP only feature.\nUse /vip to subscribe.")
        return
    key = await db.fetchrow("SELECT * FROM api_keys WHERE user_id = ?", (uid,))
    if not key:
        import secrets
        new_key = f"sb_{secrets.token_hex(16)}"
        await db.execute(
            "INSERT INTO api_keys (key, user_id, permissions, created_at) VALUES (?, ?, ?, ?)",
            (new_key, uid, "read", datetime.utcnow().isoformat()),
        )
        key = {"key": new_key}
    endpoint = f"{Config.WEB_URL}/api/scan"
    await message.reply(
        f"🔑 <b>Your API Key</b>\n\n"
        f"Key: <code>{key['key']}</code>\n"
        f"Endpoint: {endpoint}\n\n"
        f"<b>Usage:</b>\n"
        f"<pre>curl -X POST {endpoint} \\\n"
        f"  -H \"Authorization: Bearer {key['key']}\" \\\n"
        f"  -H \"Content-Type: application/json\" \\\n"
        f"  -d '{{\"url\":\"https://example.com\"}}'</pre>"
    )

async def webhook_handler(request):
    from aiohttp import web
    try:
        data = await request.json()
        secret = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
        if Config.WEBHOOK_SECRET and secret != Config.WEBHOOK_SECRET:
            return web.Response(status=403)
        await app.process_update(data)
        return web.Response(status=200)
    except Exception as e:
        logger.error(f"Webhook error: {e}")
        return web.Response(status=500)

async def start_webhook():
    try:
        webhook_url = Config.WEBHOOK_URL
        if not webhook_url:
            public_url = os.getenv("PUBLIC_URL", "").rstrip("/")
            if public_url:
                webhook_url = public_url + Config.WEBHOOK_PATH
            else:
                logger.warning("No WEBHOOK_URL or PUBLIC_URL set, webhook disabled")
                return
        await app.set_webhook(
            url=webhook_url,
            secret_token=Config.WEBHOOK_SECRET or None,
            max_connections=40,
        )
        logger.info(f"Webhook set to {webhook_url}")
    except Exception as e:
        logger.error(f"Webhook setup failed: {e}")

async def start_dashboard():
    global dashboard
    try:
        dashboard = WebDashboard(db, bot=app)
        await dashboard.start()
        logger.info("Web dashboard started")
    except Exception as e:
        logger.error(f"Dashboard start failed: {e}")

async def start_mcp():
    global mcp
    try:
        mcp = MCPServer(bot=app, db=db, dashboard=dashboard, scanner=scanner)
        from aiohttp import web
        mcp_app = web.Application()
        async def mcp_handler(request):
            data = await request.json()
            result = await mcp.handle_request(data)
            return web.json_response(result)
        mcp_app.router.add_post("/mcp", mcp_handler)
        runner = web.AppRunner(mcp_app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", Config.MCP_PORT)
        await site.start()
        logger.info(f"MCP server on port {Config.MCP_PORT}")
    except Exception as e:
        logger.error(f"MCP server start failed: {e}")

async def notify_admins(client: Client, text: str, reply_markup=None):
    for admin_id in list(set(Config.SUDO_USERS + Config.SUB_DEVS)):
        try:
            await client.send_message(admin_id, text, reply_markup=reply_markup)
        except Exception as e:
            logger.error(f"Failed to notify admin {admin_id}: {e}")

async def start_staging_bot():
    global STAGING_APP
    if not Config.STAGING_ENABLED or not Config.STAGING_BOT_TOKEN:
        logger.info("Staging bot not configured, skipping")
        return

    try:
        STAGING_APP = Client(
            "staging_bot",
            api_id=Config.API_ID,
            api_hash=Config.API_HASH,
            bot_token=Config.STAGING_BOT_TOKEN,
            workers=4,
        )
        await STAGING_APP.start()
        bot_info = await STAGING_APP.get_me()
        logger.info(f"Staging bot started: @{bot_info.username}")

        @STAGING_APP.on_message(filters.command("start"))
        async def staging_start(client: Client, message: Message):
            await message.reply(
                "🧪 <b>Staging Bot</b>\n\n"
                "This is a testing environment for new features.\n"
                "Changes here may not reflect the production bot.",
            )

        @STAGING_APP.on_message(filters.command("panel"))
        async def staging_panel(client: Client, message: Message):
            uid = message.from_user.id
            if RBAC.is_admin(uid):
                await message.reply(
                    "🧪 <b>Staging Admin Panel</b>\n\n"
                    "Use this bot to test new features before release.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("📊 Stats", callback_data="adm_stats")],
                        [InlineKeyboardButton("🏠 Main", callback_data="nav_home")],
                    ]),
                )
    except Exception as e:
        logger.error(f"Staging bot failed: {e}")

async def cleanup_expired_links():
    while True:
        try:
            await click_tracker.cleanup_expired()
        except Exception as e:
            logger.error(f"Cleanup error: {e}")
        await asyncio.sleep(3600)

async def main():
    logger.info("Starting bot...")
    await db.init()

    rate_limiter.start_cleanup()

    await task_queue.init_redis()

    async def task_handler(task: QueueTask):
        logger.info(f"Processing task: {task.name} ({task.id})")

    asyncio.create_task(task_queue.process_tasks(task_handler))

    await app.start()

    admin_panel.register(app)
    AdminPanel.register_admin_commands(app, db)

    from flood_captcha import FloodCaptcha
    flood = FloodCaptcha(db)
    flood.register(app)

    if ENABLE_STARS_PAYMENT:
        from vip_handlers import VipHandler
        VipHandler(db).register(app)
        logger.info("VIP: Telegram Stars payment mode")
    else:
        payment_flow = PaymentFlow(db, vip_system)
        payment_flow.register(app)
        logger.info("VIP: Iraqi manual payment mode")

    bot_info = await app.get_me()
    logger.info(f"Bot started: @{bot_info.username}")

    if Config.ENABLE_DASHBOARD:
        asyncio.create_task(start_dashboard())
        await asyncio.sleep(1)

    if Config.STAGING_ENABLED:
        asyncio.create_task(start_staging_bot())

    from aiohttp import web

    if Config.WEBHOOK_MODE:
        webhook_app = web.Application()
        webhook_app.router.add_post(Config.WEBHOOK_PATH, webhook_handler)
        webhook_app.router.add_get("/health", lambda r: web.json_response({
            "status": "healthy",
            "mode": "webhook",
            "timestamp": datetime.utcnow().isoformat(),
        }))
        if dashboard:
            webhook_app.router.add_routes(dashboard.app.router.routes())
        runner = web.AppRunner(webhook_app)
        await runner.setup()
        site = web.TCPSite(runner, Config.WEB_HOST, Config.WEB_PORT)
        await site.start()
        logger.info(f"Webhook+dashboard on {Config.WEB_HOST}:{Config.WEB_PORT}")
        if Config.WEBHOOK_URL:
            await start_webhook()
        if dashboard and hasattr(dashboard, "runner") and dashboard.runner:
            await dashboard.runner.cleanup()
            dashboard.runner = None
    else:
        logger.info("Running in polling mode")

    if Config.ENABLE_MCP:
        asyncio.create_task(start_mcp())

    asyncio.create_task(cleanup_expired_links())

    if not ENABLE_STARS_PAYMENT:
        async def payment_cleanup_loop():
            while True:
                from services.payment_flow import PaymentFlow
                pf = PaymentFlow(db, vip_system)
                await pf.cleanup_expired_requests()
                await asyncio.sleep(300)
        asyncio.create_task(payment_cleanup_loop())

    LoggerSetup.set_alert_bot(app, Config.ALERT_LOG_CHANNEL)

    logger.info("Bot is ready!")
    await idle()

    logger.info("Shutting down...")
    rate_limiter.stop()
    await task_queue.stop()
    if dashboard:
        await dashboard.stop()
    if STAGING_APP:
        await STAGING_APP.stop()
    await scanner.close()
    await db.close()
    await app.stop()

if __name__ == "__main__":
    try:
        os.makedirs("data", exist_ok=True)
        os.makedirs("uploads", exist_ok=True)
        os.makedirs("static", exist_ok=True)
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except ImportError as e:
        logger.error(f"Missing module: {e}")
        logger.error("Run: pip install -r requirements.txt")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)
