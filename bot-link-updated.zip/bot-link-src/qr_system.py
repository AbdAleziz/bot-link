import asyncio
import io
import logging
import os
import tempfile
from datetime import datetime
from typing import Optional, Tuple
from urllib.parse import urlparse

from config import Config
from database import Database

logger = logging.getLogger("qr_system")


class QRSystem:
    def __init__(self, db: Database):
        self.db = db

    async def generate_qr(
        self,
        data: str,
        fg_color: str = Config.QR_DEFAULT_FG_COLOR,
        bg_color: str = Config.QR_DEFAULT_BG_COLOR,
        size: int = Config.QR_DEFAULT_SIZE,
        add_logo: bool = False,
        logo_path: Optional[str] = None,
    ) -> Optional[bytes]:
        def _generate():
            import qrcode
            from qrcode.image.styledpil import StyledPilImage
            from qrcode.image.styles.moduledrawers import (
                RoundedModuleDrawer,
                SquareModuleDrawer,
            )
            from PIL import Image, ImageDraw

            qr = qrcode.QRCode(
                version=None,
                error_correction=qrcode.constants.ERROR_CORRECT_H,
                box_size=size,
                border=2,
            )
            qr.add_data(data)
            qr.make(fit=True)

            try:
                fg_rgb = self._hex_to_rgb(fg_color)
                bg_rgb = self._hex_to_rgb(bg_color)
            except ValueError:
                fg_rgb = (0, 0, 0)
                bg_rgb = (255, 255, 255)

            img = qr.make_image(
                image_factory=StyledPilImage,
                module_drawer=RoundedModuleDrawer(),
                fill_color=fg_rgb,
                back_color=bg_rgb,
            )

            if add_logo:
                logo_src = logo_path or Config.QR_LOGO_PATH
                if os.path.exists(logo_src):
                    try:
                        logo = Image.open(logo_src).convert("RGBA")
                        qr_width, qr_height = img.size
                        logo_size = qr_width // 4
                        logo.thumbnail((logo_size, logo_size), Image.LANCZOS)
                        logo_pos = (
                            (qr_width - logo.size[0]) // 2,
                            (qr_height - logo.size[1]) // 2,
                        )
                        img = img.convert("RGBA")
                        img.paste(logo, logo_pos, logo)
                    except Exception as e:
                        logger.error(f"Failed to add logo to QR: {e}")

            buf = io.BytesIO()
            img.save(buf, format="PNG", optimize=True)
            return buf.getvalue()

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _generate)

    async def decode_qr(self, image_bytes: bytes) -> Optional[str]:
        def _decode():
            from PIL import Image
            try:
                from pyzbar.pyzbar import decode as pyzbar_decode
            except ImportError:
                logger.warning("pyzbar not installed, QR decoding unavailable")
                return None

            try:
                img = Image.open(io.BytesIO(image_bytes))
                decoded = pyzbar_decode(img)
                if decoded:
                    return decoded[0].data.decode("utf-8", errors="replace")
                return None
            except Exception as e:
                logger.error(f"QR decode error: {e}")
                return None

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _decode)

    async def generate_vcard_qr(
        self,
        name: str,
        phone: str = "",
        email: str = "",
        org: str = "",
        title: str = "",
        address: str = "",
        website: str = "",
        fg_color: str = Config.QR_DEFAULT_FG_COLOR,
        bg_color: str = Config.QR_DEFAULT_BG_COLOR,
        add_logo: bool = False,
    ) -> Optional[bytes]:
        vcard_lines = [
            "BEGIN:VCARD",
            "VERSION:3.0",
            f"FN:{name}",
            f"N:{name};;;",
        ]
        if phone:
            vcard_lines.append(f"TEL;TYPE=CELL:{phone}")
        if email:
            vcard_lines.append(f"EMAIL:{email}")
        if org:
            vcard_lines.append(f"ORG:{org}")
        if title:
            vcard_lines.append(f"TITLE:{title}")
        if address:
            vcard_lines.append(f"ADR;TYPE=WORK:{address}")
        if website:
            vcard_lines.append(f"URL:{website}")
        vcard_lines.append("END:VCARD")
        vcard_data = "\n".join(vcard_lines)

        return await self.generate_qr(
            data=vcard_data,
            fg_color=fg_color,
            bg_color=bg_color,
            add_logo=add_logo,
        )

    async def generate_short_url_qr(
        self,
        original_url: str,
        created_by: int = None,
        expires_in_days: int = 30,
        fg_color: str = Config.QR_DEFAULT_FG_COLOR,
        bg_color: str = Config.QR_DEFAULT_BG_COLOR,
        add_logo: bool = False,
    ) -> Tuple[Optional[bytes], str]:
        parsed = urlparse(original_url)
        if not parsed.scheme:
            original_url = "https://" + original_url

        from click_tracker import ClickTracker
        click_tracker = ClickTracker(self.db)

        short = await click_tracker.create_short_url(
            original_url=original_url,
            created_by=created_by,
            expires_in_days=expires_in_days,
        )
        short_url = short["short_url"]

        qr_bytes = await self.generate_qr(
            data=short_url,
            fg_color=fg_color,
            bg_color=bg_color,
            add_logo=add_logo,
        )

        return qr_bytes, short_url

    async def track_qr_scan(
        self, short_code: str, user_id: int = None
    ) -> bool:
        link = await self.db.fetchrow(
            "SELECT id FROM short_links WHERE short_code = ?",
            (short_code,),
        )
        if not link:
            return False

        await self.db.execute(
            "INSERT INTO click_logs (link_id, ip, user_agent, referer, clicked_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (
                link["id"],
                f"tg_user_{user_id}" if user_id else "qr_scan",
                "qr_scan",
                "qr_code",
                datetime.utcnow().isoformat(),
            ),
        )
        return True

    async def get_qr_stats(self, short_code: str) -> Optional[dict]:
        from click_tracker import ClickTracker
        click_tracker = ClickTracker(self.db)
        return await click_tracker.get_click_stats(short_code)

    @staticmethod
    def _hex_to_rgb(hex_color: str) -> Tuple[int, int, int]:
        hex_color = hex_color.lstrip("#")
        if len(hex_color) != 6:
            raise ValueError(f"Invalid hex color: {hex_color}")
        return tuple(int(hex_color[i : i + 2], 16) for i in (0, 2, 4))
