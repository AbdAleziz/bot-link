import asyncio
import io
import logging
import os
from datetime import datetime

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from config import Config
from database import Database
from rbac import RBAC, Role

logger = logging.getLogger("admin_panel")


class AdminPanel:
    def __init__(self, db: Database):
        self.db = db

    def _owner_kb(self) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("📊 Stats", callback_data="adm_stats"),
             InlineKeyboardButton("📢 Broadcast", callback_data="adm_broadcast")],
            [InlineKeyboardButton("🚫 Ban", callback_data="adm_ban"),
             InlineKeyboardButton("✅ Unban", callback_data="adm_unban")],
            [InlineKeyboardButton("🗑️ Clear Cache", callback_data="adm_clearcache"),
             InlineKeyboardButton("📦 Export DB", callback_data="adm_export")],
            [InlineKeyboardButton("⭐ Grant VIP", callback_data="adm_grantvip"),
             InlineKeyboardButton("📋 Logs", callback_data="adm_logs")],
            [InlineKeyboardButton("👥 Sub-Devs", callback_data="adm_subdevs"),
             InlineKeyboardButton("♻️ Restart", callback_data="adm_restart")],
            [InlineKeyboardButton("🌐 Web Dashboard", url=Config.WEB_URL)],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
        ])

    def _subdev_kb(self) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("📊 Stats", callback_data="adm_stats"),
             InlineKeyboardButton("📢 Broadcast", callback_data="adm_broadcast")],
            [InlineKeyboardButton("🚫 Ban User", callback_data="adm_ban"),
             InlineKeyboardButton("✅ Unban User", callback_data="adm_unban")],
            [InlineKeyboardButton("🗑️ Clear Cache", callback_data="adm_clearcache"),
             InlineKeyboardButton("📋 Logs", callback_data="adm_logs")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="nav_home")],
        ])

    def register(self, app: Client):
        @app.on_message(filters.command("panel") & filters.private)
        async def panel_cmd(client: Client, message: Message):
            uid = message.from_user.id
            if not RBAC.is_admin(uid):
                await message.reply("❌ Unauthorized.")
                return
            role = RBAC.get_role(uid)
            kb = self._owner_kb() if role == Role.OWNER else self._subdev_kb()
            role_name = "👑 Owner" if role == Role.OWNER else "🛠️ Sub-Developer"
            await message.reply(
                f"{role_name} <b>Admin Panel</b>\n"
                f"━━━━━━━━━━━━━━\n"
                f"ID: <code>{uid}</code>\n"
                f"━━━━━━━━━━━━━━",
                reply_markup=kb,
            )

        @app.on_callback_query(filters.regex(r"^adm_"))
        async def admin_cb(client: Client, cb: CallbackQuery):
            uid = cb.from_user.id
            if not RBAC.is_admin(uid):
                await cb.answer("❌ Unauthorized", show_alert=True)
                return

            action = cb.data.replace("adm_", "")

            if action == "stats":
                await self._stats(client, cb)
            elif action == "broadcast":
                await cb.message.reply(
                    "📢 Reply to a message with /broadcast to send it to all users.\n"
                    f"Or forward a message and reply with /broadcast."
                )
                await cb.answer()
            elif action == "ban":
                await cb.message.reply(
                    "🚫 Use: /ban <user_id> <reason>\n"
                    "Or reply to a user's message with /ban <reason>"
                )
                await cb.answer()
            elif action == "unban":
                await cb.message.reply("✅ Use: /unban <user_id>")
                await cb.answer()
            elif action == "clearcache":
                await self._clear_cache(client, cb)
            elif action == "export":
                await self._export(client, cb)
            elif action == "grantvip":
                await cb.message.reply(
                    "⭐ Use: /grantvip <user_id> <months>"
                )
                await cb.answer()
            elif action == "logs":
                await self._logs(client, cb)
            elif action == "subdevs":
                await self._subdevs(client, cb, uid)
            elif action == "restart":
                if not RBAC.is_owner(uid):
                    await cb.answer("❌ Owner only", show_alert=True)
                    return
                await cb.message.reply("♻️ Restarting...")
                os._exit(0)

    async def _stats(self, client: Client, cb: CallbackQuery):
        users = await self.db.fetchval("SELECT COUNT(*) FROM users") or 0
        vips = (
            await self.db.fetchval(
                "SELECT COUNT(*) FROM vip_users WHERE expires_at > datetime('now')"
            )
            or 0
        )
        scans_today = (
            await self.db.fetchval(
                "SELECT COUNT(*) FROM scan_history WHERE date(scanned_at) = date('now')"
            )
            or 0
        )
        total_scans = (
            await self.db.fetchval("SELECT COUNT(*) FROM scan_history") or 0
        )
        threats = (
            await self.db.fetchval(
                "SELECT COUNT(*) FROM scan_history WHERE is_threat = 1"
            )
            or 0
        )
        banned = (
            await self.db.fetchval("SELECT COUNT(*) FROM banned_users") or 0
        )
        short_links = (
            await self.db.fetchval("SELECT COUNT(*) FROM short_links") or 0
        )

        text = (
            f"📊 <b>Bot Statistics</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"👥 Users: {users}\n"
            f"⭐ VIP: {vips}\n"
            f"🔍 Today's scans: {scans_today}\n"
            f"📈 Total scans: {total_scans}\n"
            f"🛡️ Threats: {threats}\n"
            f"🚫 Banned: {banned}\n"
            f"🔗 Short links: {short_links}\n"
            f"━━━━━━━━━━━━━━"
        )
        await cb.message.edit(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
            ]),
        )
        await cb.answer()

    async def _clear_cache(self, client: Client, cb: CallbackQuery):
        keys = [k for k in list(self.db.cache._memory.keys()) if k.startswith("scan:")]
        for k in keys:
            await self.db.cache.delete(k)
        await cb.message.edit(
            "✅ Cache cleared.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
            ]),
        )
        await cb.answer()

    async def _export(self, client: Client, cb: CallbackQuery):
        await cb.message.edit("📦 Exporting data...")
        try:
            data = await self.db.export_to_json()
            f = io.BytesIO(data.encode())
            f.name = f"bot_backup_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
            await client.send_document(cb.from_user.id, f, caption="✅ DB Export")
        except Exception as e:
            await client.send_message(cb.from_user.id, f"❌ Export error: {e}")
        await cb.answer()

    async def _logs(self, client: Client, cb: CallbackQuery):
        try:
            if os.path.exists(Config.LOG_FILE):
                with open(Config.LOG_FILE, "r", encoding="utf-8") as f:
                    content = f.read()
                if len(content) > 3500:
                    content = content[-3500:]
                await cb.message.edit(
                    f"📋 <b>Recent Logs:</b>\n<pre>{content}</pre>",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
                    ]),
                )
            else:
                await cb.message.edit(
                    "❌ Log file not found.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
                    ]),
                )
        except Exception as e:
            await cb.message.edit(f"❌ Error: {e}")
        await cb.answer()

    async def _subdevs(self, client: Client, cb: CallbackQuery, uid: int):
        if not RBAC.is_owner(uid):
            await cb.answer("❌ Owner only", show_alert=True)
            return

        sub_devs = Config.SUB_DEVS
        text = "👥 <b>Sub-Developers:</b>\n━━━━━━━━━━━━━━\n"
        if sub_devs:
            for sd in sub_devs:
                text += f"• <code>{sd}</code>\n"
        else:
            text += "No sub-developers configured.\n"
        text += "\nSet SUB_DEVS env var to add more."
        await cb.message.edit(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="adm_back")]
            ]),
        )
        await cb.answer()

    @staticmethod
    def register_admin_commands(app: Client, db: Database):
        @app.on_message(filters.command("broadcast") & filters.private)
        async def broadcast_cmd(client: Client, message: Message):
            uid = message.from_user.id
            if not RBAC.is_admin(uid):
                return

            if not message.reply_to_message:
                await message.reply("❌ Reply to a message to broadcast.")
                return

            msg_text = (
                message.reply_to_message.text
                or message.reply_to_message.caption
                or ""
            )
            if not msg_text:
                await message.reply("❌ Message is empty.")
                return

            sent_msg = await message.reply("📢 Broadcasting...")
            users = await db.fetch("SELECT user_id FROM users")
            sent = 0
            failed = 0
            for u in users:
                try:
                    await client.send_message(u["user_id"], msg_text)
                    sent += 1
                    await asyncio.sleep(0.05)
                except Exception:
                    failed += 1
            await sent_msg.edit(
                f"✅ Sent to {sent} users\n❌ Failed: {failed}"
            )

        @app.on_message(filters.command("ban") & filters.private)
        async def ban_cmd(client: Client, message: Message):
            uid = message.from_user.id
            if not RBAC.is_admin(uid):
                return

            target_id = None
            reason = "No reason"

            if message.reply_to_message:
                target_id = message.reply_to_message.from_user.id
                parts = message.text.split(maxsplit=1)
                if len(parts) > 1:
                    reason = parts[1]
            else:
                parts = message.text.split()
                if len(parts) >= 2:
                    try:
                        target_id = int(parts[1])
                    except ValueError:
                        await message.reply("❌ Invalid user ID.")
                        return
                    if len(parts) >= 3:
                        reason = " ".join(parts[2:])

            if not target_id:
                await message.reply("❌ Reply to a user or provide user ID.")
                return

            await db.execute(
                "INSERT OR REPLACE INTO banned_users (user_id, reason, banned_at) VALUES (?, ?, ?)",
                (target_id, reason, datetime.utcnow().isoformat()),
            )
            await message.reply(f"✅ Banned <code>{target_id}</code>\nReason: {reason}")

        @app.on_message(filters.command("unban") & filters.private)
        async def unban_cmd(client: Client, message: Message):
            uid = message.from_user.id
            if not RBAC.is_admin(uid):
                return

            if message.reply_to_message:
                target_id = message.reply_to_message.from_user.id
            else:
                parts = message.text.split()
                if len(parts) >= 2:
                    try:
                        target_id = int(parts[1])
                    except ValueError:
                        await message.reply("❌ Invalid user ID.")
                        return
                else:
                    await message.reply("❌ Reply to a user or provide /unban <user_id>.")
                    return

            await db.execute(
                "DELETE FROM banned_users WHERE user_id = ?", (target_id,)
            )
            await message.reply(f"✅ Unbanned <code>{target_id}</code>")
