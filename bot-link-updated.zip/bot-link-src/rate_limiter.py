import asyncio
import logging
import time
from collections import defaultdict
from typing import Dict, List, Optional

from config import Config

logger = logging.getLogger("rate_limiter")


class RateLimiter:
    def __init__(self):
        self._user_counts: Dict[int, List[float]] = defaultdict(list)
        self._banned_until: Dict[int, float] = {}
        self._cleanup_task: Optional[asyncio.Task] = None

    def _is_banned(self, user_id: int) -> bool:
        ban_expiry = self._banned_until.get(user_id, 0)
        if ban_expiry > time.time():
            return True
        if ban_expiry > 0:
            self._banned_until.pop(user_id, None)
        return False

    async def check(self, user_id: int) -> bool:
        if self._is_banned(user_id):
            return False

        now = time.time()
        counts = self._user_counts[user_id]

        counts[:] = [t for t in counts if now - t < Config.RATE_LIMIT_WINDOW]
        counts.append(now)

        if len(counts) > Config.RATE_LIMIT_MESSAGES:
            self._banned_until[user_id] = (
                now + Config.RATE_LIMIT_BAN_DURATION
            )
            logger.warning(
                f"Rate limit exceeded for user {user_id}: "
                f"{len(counts)} msgs in {Config.RATE_LIMIT_WINDOW}s "
                f"- banned for {Config.RATE_LIMIT_BAN_DURATION}s"
            )
            self._user_counts[user_id] = []
            return False

        return True

    async def get_remaining(self, user_id: int) -> int:
        if self._is_banned(user_id):
            return 0
        now = time.time()
        counts = self._user_counts.get(user_id, [])
        counts[:] = [t for t in counts if now - t < Config.RATE_LIMIT_WINDOW]
        return max(0, Config.RATE_LIMIT_MESSAGES - len(counts))

    async def get_ban_remaining(self, user_id: int) -> int:
        ban_expiry = self._banned_until.get(user_id, 0)
        if ban_expiry > time.time():
            return int(ban_expiry - time.time())
        return 0

    async def reset(self, user_id: int):
        self._user_counts[user_id] = []
        self._banned_until.pop(user_id, None)

    def start_cleanup(self, interval: int = 300):
        async def _cleanup():
            while True:
                await asyncio.sleep(interval)
                now = time.time()
                for uid in list(self._user_counts.keys()):
                    self._user_counts[uid] = [
                        t
                        for t in self._user_counts[uid]
                        if now - t < Config.RATE_LIMIT_WINDOW
                    ]
                    if not self._user_counts[uid]:
                        del self._user_counts[uid]
                for uid in list(self._banned_until.keys()):
                    if self._banned_until[uid] < now:
                        del self._banned_until[uid]

        self._cleanup_task = asyncio.create_task(_cleanup())
        logger.info("Rate limiter cleanup started")

    def stop(self):
        if self._cleanup_task:
            self._cleanup_task.cancel()


rate_limiter = RateLimiter()
